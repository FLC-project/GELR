/*
 * @(#)ParserEngine.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>ParserEngine</code> class provides a general purpose interpreting
 * parsing algorithm.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

abstract class ParserEngine implements Cloneable {

    /** The version. */
    static String version = "V1.7";

    /** Whether it should retain the item lists, used for testing. */
    static final int RETAIN_LISTS = 1 << 0;

    /** Whether it should retain the grammar. */
    static final int RETAIN_GRAM = 1 << 1;

    /** Whether it should retain all arrays. */
    static final int RETAIN_ARR = 1 << 2;

    /** Whether it should retain the tokens, used for testing. */
    static final int RETAIN_TOKENS = 1 << 3;

    /** Whether it should use retained tokens, used for testing. */
    static final int USE_RETAINED_TOKENS = 1 << 4;

    /** The mode. */
    int mode;

    /** The reference to the parsing tables. */
    ParserTables tab;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    m   combi details
     *    n   memory
     *    p   parsing
     *    q   parsing details
     *    r   even more details
     *    s   parse tree construction details
     *    t   parse tree construction
     * </pre></blockquote><p>
     */

    static final int FL_M = 1 << ('m'-0x60);
    static final int FL_N = 1 << ('n'-0x60);
    static final int FL_P = 1 << ('p'-0x60);
    static final int FL_Q = 1 << ('q'-0x60);
    static final int FL_R = 1 << ('r'-0x60);
    static final int FL_S = 1 << ('s'-0x60);
    static final int FL_T = 1 << ('t'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
        this.lex.trc = this.trc;
        this.tab.trc = this.trc;
    }

    /**
     * Set the trace flags which are specified in the argument.
     *
     * @param      s set of flags
     */

    public void settrc(int s){
        this.trc = s;
        this.lex.trc = this.trc;
        this.tab.trc = this.trc;
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        ParserEngine t = null;
        try {
            t = (ParserEngine)super.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /** 
     * Set the specified parser data.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    protected void setParserData(ParserTables tab, Object inp, String flags, String algo){
        this.tab = tab;
        this.lex = new ParserLex(tab,inp);
        settrc(flags);
    }

    /**
     * Copy the tree data into the specified object.
     *
     * @param    eng object
     */

    void copyTree(ParserEngine dst){
        dst.tab = this.tab;
        dst.pool = this.pool;
        dst.tokListDir = this.tokListDir;
        dst.tree = this.tree;
        dst.treeLen = this.treeLen;
        dst.treeStart = this.treeStart;
    }

    // the stream for ParserTest
    PrintWriter traceStream;

    /** The number of bits of the block offset (for parse tree). */
    static final int NSHF = 10;

    /** The block length and amount of directory increase. */
    static final int QUANTUM = 1 << NSHF;

    /** The mask to extract the block offset from an index. */
    static final int MSK = QUANTUM - 1;

    /**
     * Deliver a string representing an item.
     *
     * @param      i index of the item
     */

    String itemToString(int itm){
        return null;
    }

    /**
     * Trace the current items list.
     */

    void traceItems(){
    }

    /**
     * Trace the item lists.
     */

    void traceLists(){
    }

    /**
     * Trace the item lists.
     *
     * @param      trc trace stream
     * @param      set <code>true</code> to mark safe lists
     */

    void traceLists(PrintWriter trc, boolean safe){
    }

    /** The number of items, for statistics. */
    int items;

    /**
     * Parse the text.
     *
     * @return     <code>true</code> if successful, <code>false</code> otherwise
     */

    boolean parse(){
        return false;
    }

    /** The reference to the lexer. */
    ParserLex lex;

    /** The number of the delimiter token (whitespaces and comments). */
    int delim = -1;

    /**
     * Deliver the next unexpended token.
     *
     * @return     number of the token (from 0)
     */

    int tokenizer(){

        if (this.delim < 0){
            this.delim = this.tab.symNr('n',"delimiter");
        }
        // MEASURE(tokens++);
        ParserTables tab = this.tab;
        int res = -1;
        doit: do {
            int set = this.lex.lex();
            if (this.lex.eof()){
                res = tab.numOfToks;
                break doit;
            } else {
                if (set == 0){
                    // there is a need to define a way for emitting here a message if
                    // the user wants to do so
                    break doit;
                }
                // this does not work when TOKENS_MAP is selected in lexer
                res = tab.tokLists[set][0];   // earliest preferred
            }
        } while (res == delim);
        this.numOfTokens++;
        return res;
    }

    /** The number of tokens in the source. */
    int numOfTokens;

    /** The pool in which the lexemes are stored. */
    ParserPool pool;

    /** The index in the pool of the last lexeme stored in it. */
    int lexIndex;

    /* The tokens list
     *
     * The tokens list is block structured with no gaps and with holes between
     * blocks. Elements (packets representing tokens) cannot cross blocks.
     * It is homogeneous, but it need not be.
     * A call to the method to enlarge it is done only when there is no
     * sufficient space. This is done by testing the amount required with
     * the free space available.
     * Keeping the free space spares also to allocate a block at beginning or
     * to test each time that there is at least a block.
     * The max block number is ~MSK >>> NSHF, and it is used to deny allocation
     * of a block whose indexes are beyond the allowed range.
     * Note that there is a bit of a difference between pools in which the
     * start index of elements must be within a range and pools in which all
     * the indexes must be in a range. For the latter ones, (loc + n - 1) >= 0
     * is the condition, while loc >= 0 is that of the former ones.
     * However, having elements that go beyond such a range makes impossible
     * to address them with indexes, which should be avoided.
     *
     * The number of the next block never overflows (unless the size of blocks
     * is 1 or 2, which never occurs) because the limit of the number of
     * blocks is encountered earlier.
     *
     * Implementation notes:
     *
     *   - it is not possible to use the pool as tokens list since it must be
     *     homogeneous (rehashing scans it and needs to find only strings).
     *   - it is not possible to store the tokNr in the pool close to the
     *     string since there could exist different tokens which happen to
     *     have the same string.
     *   - the methods to manage the token lists would be misplaced in
     *     ParserPool: they depend on ParserTables. Even if the relevant data
     *     could be copied into some fields of ParserPool, the former are a
     *     usage of the latter.
     *   - a subclass of ParserPool cold be written to use its allocation method
     *     for the token list, but this introduces another class and slows down
     *     the engine.
     *   - it is possible to put the code to enlarge and resize in a unique
     *     class which is inherited by ParserPool, ParserEngine, and another for
     *     the tokens list. However, in the engine there is a need to have two
     *     such pools: the tree and the tokens list. It is difficult to share
     *     code since the parse tree is an int[][], while the tokens list is a
     *     char[][].
     */

    /** The number of the next block. */
    int nextBlock;

    /** The free space in the last block. */
    int freeSpace;

    /** The directory of blocks. */
    char[][] tokListDir;

    /**
     * Enlarge the tokens list by one block.
     */

    void enlargeTokList(){
        // MEASURE_ACTIONS_GETTIME();
        int bn = this.nextBlock++;             // next block number
        if (bn > (~MSK >>> (NSHF+1))){
            throw new OutOfMemoryError();
        }
        int curlen = (this.tokListDir == null) ?
            0 : this.tokListDir.length;
        if (bn >= curlen){                     // resize directory
            int newlen = curlen == 0 ?
                QUANTUM : (int)(this.tokListDir.length * 1.5F); 
            if (newlen < 0){
                throw new OutOfMemoryError();
            }
            if (newlen < bn+1) newlen = bn + 1;
            char[][] np = new char[newlen][];
            if (this.tokListDir != null){
                System.arraycopy(this.tokListDir,0,
                    np,0,this.tokListDir.length);
            }
            this.tokListDir = np;
        }
        char[] blk = new char[QUANTUM];      // allocate a block
        this.tokListDir[bn] = blk;
        this.freeSpace = QUANTUM;
        // MEASURE_ACTIONS_SPOT(allocCycles);
    }

    /**
     * Reduce the token list if the directory or the last block have
     * an unused space higher than 20% of the total one to the strictly
     * needed size.
     */

    void reduceTokList(){
        int free = this.tokListDir.length - this.nextBlock;
        if (((free * 100) / this.tokListDir.length) > 20){  // resize it
            char[][] np = new char[this.nextBlock][];
            System.arraycopy(this.tokListDir,0,
                np,0,np.length);
            this.tokListDir = np;
        }
        if (((this.freeSpace * 100) / QUANTUM) > 20){       // resize it
            int len = QUANTUM - this.freeSpace;
            char[] np = new char[len];
            System.arraycopy(this.tokListDir[this.nextBlock-1],0,
                np,0,len);
            this.tokListDir[this.nextBlock-1] = np;
        }
    }

    /** The flag denoting the presence of the lexeme string. */
    static int TOK_LEXNR = 0x40000000;

    /** The flag denoting the presence of the point. */
    static int TOK_POINT = 0x20000000;

    /** The flag denoting the value as a token. */
    static int TOK_ELEM  = 0x80000000;

    /** The number of elements in the tokens list. */
    int tokListNr;

    /**
     * Add a token to the tokens list.
     *
     * @param      lexNr index of the lexeme in the pool (-1 if not present)
     * @param      tokNr token number
     * @param      point index in the text (-1 if not to be stored)
     * @return     index of the stored element
     */

    int addToken(int lexNr, int tokNr, long point){
        tokListNr++;
        int eLen = 1;
        if (lexNr >= 0){                  // string to be stored
            eLen++;
            if (lexNr >= 0x8000) eLen++;  // long lexNr
        }
        if (point >= 0){                  // point to be stored
            eLen++;
            if (point >= 1L << 60) throw new OutOfMemoryError();
            else if (point >= 1L << 45) eLen += 3;
            else if (point >= 1L << 30) eLen += 2;
            else if (point >= 1L << 15) eLen++;
        }

        if (this.freeSpace < eLen){       // not enough free space
            enlargeTokList();             // enlarge it
        }
        int bn = this.nextBlock - 1;
        int off = QUANTUM - this.freeSpace;
        this.freeSpace -= eLen;
        int e = (bn << NSHF) | off;
        char[] blk = this.tokListDir[bn];
        int start = off;
        blk[off++] = (char)tokNr;         // store token number
        if (lexNr >= 0){                  // string to be stored
            blk[off++] = (char)lexNr;     // lexeme number
            if (lexNr >= 0x8000){         // on 2 chars
                blk[off-1] |= 0x8000;
                blk[off++] = (char)(lexNr >>> 15);
            }
            e |= TOK_LEXNR;
        }
        if (point >= 0){                  // point to be stored
            blk[off++] = (char)point;     // store point
            for (int i = 0; i < 3; i++){  // store its pieces
                if (point >= 1 << 15){
                    blk[off-1] |= 0x8000;
                    point >>>= 15;
                    blk[off++] = (char)point;
                }
            }
            e |= TOK_POINT;
        }
        return e;
    }

    // this serves to the hardcoded only
    int addToken(char[] buf, int ofs, int len,
        int tokNr, long point){
        int lexNr = 0;
        if (buf != null){                 // string to be stored
            if (this.pool == null){       // allocate string pool
                this.pool = new ParserPool();
            }
            lexNr = this.pool.addUnique(buf,ofs,len);
        }
        if (point < 0){                   // point not stored
            long tk = lexNr * this.tab.numOfToks + tokNr + 1;
            if ((tk & 0xe0000000) == 0){  // packing possible
                return (int)(tk);
            }
        }
        if (buf == null) lexNr = -1;
        return addToken(lexNr,tokNr,point);
    }

    /**
     * Trace the tokens list.
     */

    /* Note that the tokens list is not selfexplanatory, i.e. there is a
     * need to know what to look for. This is why there is a need to scan
     * the parse tree to determine where elements start in the tokens list
     * and whether they contain the lexeme and/or the point in them.
     *
     * The total unused space is measured.
     */

    void traceTokList(){
        int[] toks = new int[this.treeLen];
        int len = 0;
        if (this.pool != null){
            len = (int)this.pool.size();
        }
        boolean[] lexs = new boolean[len];
        int tokens = 0;
        for (int i = 0; i < this.treeLen; i++){
            int el = this.tree[i>>>NSHF][i&MSK];
            if (el < 0){
                if ((el & (TOK_LEXNR | TOK_POINT)) != 0){
                    int idx = el & ~(TOK_ELEM | TOK_LEXNR | TOK_POINT);
                    toks[idx] = el;
                    tokens++;
                }
            }
        }
        int unused = 0;
        int last = ((this.nextBlock - 1) << NSHF) |
            (this.tokListDir[this.nextBlock-1].length - 1);
        for (int i = 0; i < last+1;){
            int off = i & MSK;
            int bn = i >>> NSHF;
            char[] blk = this.tokListDir[bn];
            int e = toks[i];
            if (e == 0){
                Trc.out.println("unused: " + i);
                if (blk[off] != 0){
                    Trc.out.println("toklist inconsistent: " + i);
                }
                i++;
                unused++;
                continue;
            }
            int start = off;
            int tn = blk[off++];                      // tokNr
            int ln = -1;
            if ((e & TOK_LEXNR) != 0){                // in-pool, lexNr
                ln = blk[off++];                      // lexNr
                if (ln >= 0x8000){
                    ln &= ~0x8000;
                    ln |= blk[off++] << 15;
                }
            }
            long pt = -1L;
            if ((e & TOK_POINT) != 0){                // inline, or in-pool no point
                pt = blk[off++];                      // rebuild it
                if (pt >= (1L << 15)){
                    pt &= ~(1L << 15);
                    pt |= (long)blk[off++] << 15;
                    if (pt >= (1L << 30)){
                        pt &= ~(1L << 30);
                        pt |= (long)blk[off++] << 30;
                        if (pt >= (1L << 45)){
                            pt &= ~(1L << 45);
                            pt |= (long)blk[off++] << 45;
                        }
                    }
                }
            }
            Trc.out.print(i + ": " + ln + " " + pt + " " +
                tab.tokLitName(tn) + ",");
            if (ln >= 0) Trc.out.print(this.pool.toString(ln));
            if (pt >= 0) Trc.out.print("," + pt);
            Trc.out.println();
            lexs[ln] = true;
            i += off - start;
        }
        int lexused = 0;
        for (int i = 0; i < lexs.length; i++){
            if (lexs[i]) lexused++;
        }
        Trc.out.println("tree tokens in list: " + tokens);
        Trc.out.println("toklist unused space: " + (unused * 2) +
            " size: " + tokListSize() + " tokens in list: " + tokListNr);
        Trc.out.println("lexemes used: " + lexused);
    }

    /*
     * The parse tree and forest
     *
     * The description below refers to an Earley parser. However, it applies also
     * to the other parsers when the appropriate equivaleces are done.
     * When the text has been parsed successfully, it is possible to traverse
     * the item lists to build a left and a right parse.
     * This can be done also during parsing depending on the algorithm.
     * A left (right) parse is a sequence of derivations in which the symbol
     * which is replaced is always the leftmost (rightmost) nonterminal.
     * Let's see how a right parse can be built. The goal item is one which
     * has a starting rule with the dot at the end:
     *
     *      <S> ::= alpha beta ... gamma ., 0
     *
     * Its backpointer is zero, indicating that it matches a string at position 0.
     * If there are several such items, then the sentence is ambiguous, and any
     * of them can be used to build a different derivation. Proceed as follows:
     *
     *    1. take that item. Note that the item has in it the rule, not simply
     *       the name of the nonterminal. At position 0 other items for a starting
     *       rules could be present, but not ending in an item like that in the last
     *       item list.
     *    2. scan it from the end: all tokens have a straightforward derivation,
     *       and thus skip them and go back one item list for each of them.
     *       We are then at a nonterminal:
     *
     *              <S> ::= alpha beta ... <A> . gamma, 0
     *
     *       and thus must find a final item for A in the list in which we have:
     *
     *              <A> ::= delta ., r
     *
     *       which completed in item list r the item for <S> with the dot before the
     *       A in it:
     *
     *              <S> ::= alpha beta ... . <A> gamma, 0
     *
     *       Again, if there are several items for <A>, any one can be taken and
     *       several parses built.
     *       Apply this algorithm to that final item for <A> at the current list.
     *       It will create the right derivations for that <A>.
     *       Then proceed scanning <S>, making the list at which <A> started (r)
     *       the current one: we must skip all items lists which are relative to
     *       the terminals generated by that <A>.
     *
     * This algorithm enters an endless loop when there are cyclic rules. E.g.,
     * suppose that the final item for A is <A> ::= <A> .
     * This makes the algorithm try to find a derivation for A again, at the same
     * items lists. Note that there must be another final item for <A>, which it
     * not cyclic. Therefore, to treat cyclic grammars, final cyclic items must be
     * skipped when looking for a final one.
     *
     * These algorithms are slow because of the search in the current items list
     * for a final item. To speed this up, the subpointer is introduced, which
     * allows to retrieve that item immediately. An ambiguous grammar can have
     * several final items completing a same one, and thus would need several such
     * subpointers (actually, several pedigrees, being each one a pair leftpointer,
     * subpointer). If only one parse is needed, then only one can be kept (by choosing
     * one using some disambiguation rules).
     * The simplest way to introduce subpointers is to attach them to items,
     * i.e. attach them to the item of <S> which has recognised <A> (i.e. which has
     * the dot at the right of the <A>. This means that when scanning the terms
     * of a rule, to find the subpointers for each one there is a need to
     * visit the items which represent subsequent steps on the matching of a rule
     * (i.e. the items which have the dot at the right of each term in a rule).
     * To do it in a fast way, a leftpointer is also introduced, which makes
     * an item refer to the item for the same rule which has the dot one term
     * before it.
     * A parser that delivers all parses is simpler since it is freed from resolving
     * ambiguity. It keeps all the items that belong to different parses.
     * It delivers a forest. There is a need for several pedigrees, and links in the
     * parse tree.
     * Note that visiting recursively all pedigrees produces a parse forest in which no
     * nodes are shared. E.Scott wrote a paper in which the technique to share them is shown.
     *
     * The items lists are able to produce all the parses of an ambiguous sentence.
     * This is obtained by starting from all the items in the last list which
     * have the starting nonterminal as LHS, the dot at the end, and the first
     * item list as backpointer and walking up the lists. Note that at any step,
     * when scanning the rule of an item and processing a nonterminal, there can
     * be several rules which have that nonterminal as LHS and the dot at the end.
     * Following all of them, all the parses can be obtained.
     * If instead of visiting the lists following backpointers, leftpointers and
     * subpointers are kept, then there is a need to keep all couples attached
     * to items to maintain all the derivations.
     *
     * By scanning the terms from the left, a left parse can be built. However,
     * when a nonterminal <A> is encountered, the items lists must be scanned to
     * find the one at which its recognizion ends, which means finding an items list
     * in which <S> ::= alpha beta ... <A> . gamma is present (i.e. with the dot at
     * the left of <A>. In that list, a final item for <A> is present, and a
     * derivation for it can be built. Alternatively, the symbols can be scanned
     * from the right, a recursive call made for all symbols by following the
     * leftpointer, followed by one for the subitem.
     * This creates a stack with a call for all symbols in a rule, which reverses
     * the ordering of visiting of the subpointed items in a rule, thus obtaining a
     * left parse. To do it, each call needs to know the index of the symbol it
     * is processing in the rule (to get to its subpointer) and the items list in
     * which the processing of it begun, i.e. the same information which is
     * available when making the right parse. The items list is either the
     * previous one if the current symbol is a terminal, or the backpointed one
     * of the subpointed one otherwise.
     * It can also be implemented by making a loop on the left pointers and
     * collecting items until the last one is found, and then by visiting them
     * in the reverse ordering. This allows to decrease the amount of stack used.
     * It may not be implemented by reversing the leftpointers since there can be
     * chains of items which share some items.
     * In most cases I have seen, sharing is done only for the last element.
     * This could be treated, for example by creating a new item. However,
     * more complex cases exist.
     *
     * Building the parse tree for the Earley engine
     *
     * The parse tree can be built by using the recursive algorithm above.
     * A faster technique is to build it by walking the items, see the section
     * dedicated to it.
     *
     *
     * Parse trees
     *
     * Symbolic representation of parse trees
     *
     * Parse trees can be represented by parenthesised expressions in which
     * each node is represented as nonterminal[e0 e1 ... en].
     *
     * Extracting information from the parse tree
     *
     * Most parsers basically generate a walker in which user code is inserted.
     * That code can access the data returned by the lexer, but not the derivations:
     * it is the mere fact to be executed that allows the application to become
     * aware of what has been derived. It is the place in the grammar in which that
     * code is placed that makes it executed when the rule at that place is matched.
     * It is then up to that code to do whatever is peculiar for the derivations
     * of the rule to which it is attached. The lexer makes available the text
     * of the matched lexeme to the code, which computes an attribute that is
     * made available to the code in rules that contain that token. The code in
     * rules can in turn compute an attribute which is passed to other rules.
     * E.g.:
     *
     *       factor<n> : factor<x> '*' primary<y> {*n = x * y};
     *       primary<n> : NUMBER<n>
     *
     * NUMBER stores in n the number, which is passed to primary, and made
     * available to the code in factor as y. The code computes the result and
     * stores it in n.
     * In rules, the code can access the data of nonterminals by using the name
     * of attributes. It is basically an access by name.
     * To get the data of a repetition group, the code must be put inside it.
     * This mechanism is rather straightforward since it attaches names to the
     * terms of rules. It solves the problem of distinguishing occurrences of
     * a same nonterminal by attaching different attribute names.
     * E.g. a: b<b1> b <b2>. Its drwaback is that grammars become cluttered by
     * attributes.
     * The parser generator yacc identifies them by numbers: $i is the i-th
     * term in the rule.
     * The passing of attributes becomes the main mechanism for an application
     * to pass data between the pieces of code which process the different parts
     * of the grammar. This is also a problem since it forces application to
     * use only this mechanism which can be restrictive or innatural in many
     * cases.
     * Notably, the HTML parser analyzes instead all the input and then delivers
     * a parse tree (DOM).
     *
     * In applications, there is a need to determine which rules have been matched
     * and to get information on the elements in the matched rules.
     * Let's see how the elements in rules are accessed by applications.
     * Some access the elements in random mode, e.g. the last, then the first, etc.
     * Since the nonterminals which appear in rules denote sub-phrases, they are
     * the best candidates to be used to denote the elements to access.
     * E.g., in: <A> ::= a <B> c the most natural way to know what string has
     * been matched by <B> is to call a method passing (some representations of)
     * <B> as argument. This applies also when there is a need to get the derivation
     * of <B> and then get some information about it.
     *
     * There are these alternatives for an API to access the derivations:
     *
     *      1.  a method which returns an array containing the indexes of the
     *          symbols of the derivation specified as argument. On each of its
     *          elements a method that delivers the matched string and another
     *          that delivers the rule applied can be called.
     *          To avoid to allocate an array each time, the first method can
     *          fill an array passed as argument.
     *          They operate directly on the items lists.
     *          The elements can be collected into a reused array, and then
     *          copied into one built on the fly. This spares the visit of
     *          the items list to determine the length of the array. The length
     *          of the longest can not be computed when the grammar is encoded
     *          because with groups the length is unknown.
     *      2.  a method with a derivation, a symbol argument and an occurrence
     *          index to return what that occurrence of that symbol matched in
     *          that derivation. This spares to build the array of the derivation.
     *          However, it cannot be implemented efficiently since it must
     *          walk back the left links (possibly entering groups).
     *          Since the length of the phrase is not known, there is a need
     *          to measure it first, and then to count that number minus the
     *          specified one.
     *          There is a need to get the length of the derivation also, which
     *          is needed only when there are groups.
     *          A isEmpty() could be useful to test if a derivation is empty.
     *          It might tests also if it is made of nonterminals which eventually
     *          produce the empty string.
     *      3.  a set of methods which operate on a parse tree.
     *
     * Building the parse tree requires some time, but then allows to free
     * the space used for the items lists, which is considerably larger.
     * Moreover, since it is normal for applications to access several items
     * on a same derivation, it is appropriate to make available derivations
     * as an array of elements, directly accessible with the number of the
     * terms in the associated rule.
     * The last solution is then chosen.
     *
     * The basic idea concerning what gets into the parse tree is that the BNF
     * structure of rules is embodied in derivations. E.g. scanning the elements
     * of a derivation and asking what each is, terminal, nonterminal and group
     * is the reply according to what is present in rules.
     *
     * Terminology
     *
     * The parse tree of a sentence is made of nodes which represents
     * application of rules, and of leaves which represents tokens. Any
     * such application is a derivation which transforms a frontier of
     * the tree in another.
     * A derivation takes a string (made of nonterminal and terminal symbols),
     * and replaces a nonterminal in it.
     * The sequence of nodes of a subtree represents a phrase.
     * For the sake of completeness, remember that a "sentential form" is
     * a string derived from the starting symbol and possibly made of
     * nonterminals and terminals, and a "sentence" is a sentential form
     * made only of terminals.
     * Derivations (more precisely, derived phrases) are made of terminal
     * symbols and of nonterminal symbols referring to other derivations.
     * The number of symbols which are derived from a node in the tree is
     * called the length of the phrase of the derivation.
     *
     *     - nonterminals in a grammar are numbered. Rules are also numbered.
     *       They are made of sequences of terms, which are (applied occurrences
     *       of) nonterminals, tokens and groups.
     *       Each term in a rule has an ordinal number.
     *
     *         nont. rule                               relative rule
     *          nr    nr                                (alternative) nr
     *           0     0  <A> ::=  alpha beta gamma ...  alt. 0 of <A>
     *                               0     1    2   ...  term numbers
     *                 1          | delta ...            alt. 1 of <A>
     *           1     2  <B> ::=  eta ...               alt. 0 of <B>
     *
     *       All terminals and nonterminals have also distinct numbers.
     *
     *     - derivations (or better, subtrees in a derivation tree) are made of
     *       a sequence of elements (direct descendants), which are occurrences
     *       of terminals or other derivations (other subtrees). Each derivation
     *       has an index and also each element in it has an index.
     *
     *       index
     *         1     <A> ::=  alpha beta  <B> ...    derivation of <A>
     *                          2     3    4  ...    indexes of elements
     *         i     <B> ::=  gamma delta            derivation of <B>
     *                         i+1   i+2  ...        indexes of elements
     *
     *       Derivations have:
     *
     *       - an index in the tree, which denotes them much the same as
     *         an object is by its reference
     *       - a phrase made of the sequence of derived elements, which are
     *         terminals or other derivations (of nonterminals and groups).
     *         They rewrite the nonterminal of the derivation.
     *           - terminal elements have a token number and string (or a value
     *             denoting a string (in the text or in some container))
     *       - derivation elements have a string attached, and all the data
     *         described above.
     *       - a length of the phrase, which is the number or elements (symbols)
     *         in the phrase.
     *       - a rule number denoting the rule which has been applied.
     *         From it, the nonterminal (number and name) can be retrieved.
     *         The rule can be denoted by a nonterminal number and a relative
     *         alternative (rule) number.
     *
     * A parse tree is represented with an array of integers: terminal symbols
     * are represented as negative values (see below), derivations are represented
     * as the indexes of the place where they are stored in the tree.
     * At the beginning of a derivation, the length of the phrase or the rule
     * number is inserted. Note that the length of the phrase is one thing and
     * the length of a derivation is another. The latter is the number of
     * elementary derivations made to transform a string into another.
     * For sake of simplicity, since only elementary derivations are used here,
     * the length of the phrase of a derivation is sometimes abbreviated into
     * the length of the derivation.
     *
     * Derivations have the following form:
     *
     *    header  el0 ... eln  [backlink]
     *
     * where:
     *
     *    header:    < numOfRules  number of the rule, if no repetition group
     *               else          length of phrase + numOfRules
     *    element:   < 0           token: token number, lexeme index, point
     *               > 0           derivation: its index
     *    backlink:  > 0           group: index in the derivation tree of
     *                             the symbol after the group (including
     *                             tree.length). Not present if not group
     *
     * The encoding of values is:
     *
     *    tokens      | derivations | rules     | repetitions
     *                | backlinks   |           |
     *      -2^31..-1.0.1............2^30........numOfRules
     *
     * Note that there are no elements whose value is zero. This allows to
     * visit derivations entering groups.
     * For rules which are not repetition groups, the array ruleLen tells
     * the length.
     * This allows to spare to keep a stack or to create arrays to pass the
     * derivations to applications.
     * Since derivations need a number of entries to be stored which is
     * comparable to the number of items in item lists (in which there are
     * also many useless items), one of the arrays of the items lists could
     * be used to store the tree. However, the arrays are needed to visit the
     * item lists, and thus a new one need be created.
     *
     * Derivations are mostly ordered as a right parse. The exact property
     * is that a derivation references only derivations of lower indexes.
     *
     * Achronyms
     *
     *     acronym  meaning                              values
     *
     *     ntNr     nonterminal number                   numOfToks..numOfSyms-1
     *     ruleNr   rule number                          0..numOfRules-1
     *     altNr    relative rule (alternative) number   0..max for each rule
     *     tokNr    token number                         0..numOfToks-1
     *     symNr    nonterminal number or token number   0..numOfSyms-1
     *     termNr   term number in some rule             0..max for exch rule
     *     symOcc   number of the occurrence of a        0..max for each symbol
     *              symbol in a same rule
     *     der      derivation (index in parse tree)     1..*
     *     ele      element of derivation: token or      -*..-1, 0..*
     *              derivation
     *     idx      index of element or derivation       1..tree.length-1
     *     symName  string of the name of the symbol     string
     *              (token or nonterminal)
     *     lexNr    lexeme number (in the lexemes pool)  1..*
     *
     * Methods
     *                                             group
     *     symNr symNr(kind,symName)               n.a.
     *     symNr symNr(symName)                    n.a.
     *     symNr symNr(ruleNr)                     -1
     *     symNr symNr(ruleNr,ternNr)              -1
     *     ruleNr(symName,altNr)                   n.a.
     *     ruleNr(symNr,altNr)                     n.a.
     *     ruleNr(ruleNr,termNr,altNr)
     *     termNr(ruleNr,symNr,symOcc)             n.a.
     *     symName symName(symNr)                  n.a.
     *     String symLitName(symNr)                n.a.
     *
     *     der getStart()
     *     traceTree()
     *     traceDer(der)
     *     int getLength(der)
     *     int getSize(der)
     *     boolean isGroup(der)
     *     boolean isRepGroup(der)
     *     ruleNr getRuleNr(der)                    -1 if repetition
     *     altNr getAltNr(der)                       0 if repetition
     *     boolean isAlt(der)
     *     int[] getAlts(der)
     *
     *     symNr getSymNr(ele)                      -1
     *     symName getSymName(ele)                  ""
     *     String getSymLitName(symNr)              ""
     *     boolean isDer(ele)                       true
     *
     *     idx getIndex(der,termNr)
     *     idx getIndex(der,symName)
     *     idx getIndex(der,symName,symOcc)
     *     idx getIndex(der,kind,symName,symOcc)
     *     int getIndex(der,symNr,symOcc)
     *     idx getNext(idx)
     *
     *     ele getElement(idx)
     *     ele getElement(der,termNr)
     *     ele getElement(der,symName)
     *     ele getElement(der,symName,symOcc)
     *     ele getElement(der,kind,symName,symOcc)
     *     ele getElement(der,symNr,symOcc)
     *
     *     String toString(der,termNr)
     *     String toString(ele)
     *     lexNr getLexNr(ele)
     *     String getLexeme(lexNr)
     *     long getPoint(ele)
     *
     *     IllegalArgumentException when arguments are invalid
     *
     *   Nonterminals numbers
     *
     *     They serve to get elements which correspond to nonterminals in rules,
     *     (e.g. with getIndex()) and to test what nonterminal has been applied
     *     in a derivation.
     *
     *     Tokens are delivered in bit sets by lex() as token numbers, but
     *     they are also delivered by getSymNr(). Thus either they are numbered
     *     separetely (i.e. independently from nonterminals), which requires
     *     to have dedicated methods (there should be a getSymNr() for tokens,
     *     getIndex(symNr...) would need to have another parameter to tell
     *     what symNr is, etc.), or they are numbered after nonterminals, which
     *     requires lex() to deliver them in another form, or they are numbered
     *     before nonterminals.
     *     Moreover, when symbolic constants for symbol numbers are generated, only
     *     one numbering is practicable: it is not possible to have token numbers
     *     for the lexer and different token numbers for the parser.
     *     Additionally, there is no evidence of the necessity to number
     *     nonterminals from 0.
     *     Therefore, nonterminals and tokens are numbered together, and tokens
     *     are numbered before nonterminals.
     *
     *     With respect to rule numbers, there are two alternatives:
     *
     *       1. number nonterminals and rules together (i.e. the number of a
     *          nonterminal becomes that of its first rule):
     *
     *          - nonterminal numbers would still be opaque, but larger.
     *            Rule numbers would be opaque too.
     *          - is allows to have a unique numbering of nonterminals and rules.
     *            Numbering together can reduce the methods needed.
     *          - it is possible to ask what nonterminal or what rule has been
     *            applied in an element. If not, two different methods should
     *            be used.
     *          - there is a need for a method which tells that two rules belong
     *            to a same nonterminal.
     *
     *       2. number nonterminals and rules independently
     *
     *          - numbering nonterminals after tokens makes them opaque
     *            for applications. I.e. applications would only know that each
     *            nonterminal has a unique number, and that is it not too large.
     *            However, numbering nonterminals independently from rules
     *            makes their numbers a range without holes.
     *            It would be useful for applications which do some actions
     *            that depend on the nonterminals used, and thus need to build
     *            tables of nonterminals.
     *          - there is a distinction between nonterminals and rules: two
     *            derivations can be applications of two distinct rules, but of
     *            a same nonterminal. There can be a need to test that they
     *            have the same nonterminal. Thus, there would anyway be distinct
     *            methods.
     *
     *       The second solution is taken because more terse.
     *
     *   Tokens
     *
     *     The numbering is the same for the lexer and the parser.
     *     Tokens are numbered from zero onwards. A lexer has more constraints
     *     than a parser to number tokens. Therefore this numbering is chosen,
     *     which is the one that optimizes the lexer.
     *
     *   Symbol names
     *
     *     Symbol names (i.e. nonterminals and terminals) can be used to get
     *     what corresponding terms matched in derivations, and can be obtained
     *     to show what derivations are.
     *     They occur in symNr() which delivers symbol numbers to be used to
     *     get elements with getIndex(), or to test what elements are.
     *
     *     When replacements are used, the origin names are stored in the
     *     engine tables (i.e. not the ones with the apex appended since is
     *     is only a mechanism to explain what is the effect of replacements).
     *
     *     There are two alternatives concerning the form of the names of the
     *     nonterminals, as seen from the API: to have them surrounded by
     *     angular brackets or not.
     *     From one side, they should not because that is a way to distinguish
     *     them in BNF grammars from terminals (which can also be done with
     *     other notations), and in an API there can be other means to
     *     distinguish them besides using in-band delimiters.
     *     From another side, the angular brackets are the way provided by this
     *     implementation to distinguish them, e.g. in all tracing.
     *     Another problem is that when calling methods it is not comfortable
     *     to quote names: there is already a need to use some quotation
     *     because strings need be written as string literals. E.g. a dot
     *     in a source grammar would be ".", which would need be passed as
     *     "\".\"" (cluttered): better pass it as ".", which is the Java
     *     literal for a dot.
     *     The best is to pass the net names, without changing them to make
     *     distinguisheable from other names.
     *     Moreover, the solution to let specify names in the API as they are
     *     written in source grammars is complex because the names could include
     *     quoting. E.g. in a source there can be a terminal "<a>". To spare
     *     symNr() to scan what is passed as argument so as to normalize it,
     *     a well defined form must be stored and used always. E.g. in a grammar
     *     there can be a terminal "aa" and a terminal aa, which are the same,
     *     but written in a different way. Either both forms are accepted as
     *     argument by symNr(), which means that it needs to scan the argument,
     *     or only one defined form is accepted. Scanning it to normalize the
     *     form is slow, and choosing one form only is uncomfortable.
     *     The point here is that from within a program it is always better to
     *     handle the objects which are denoted by the source constructs, and
     *     not the source constructs themselves.
     *     The drawback of storing the net names is that they need by converted
     *     when printing. This, however, occurs seldom.
     *     Therefore, the names, as seen from the API, are the net ones.
     *
     *     There cannot be clashes between redefined and non-redefined terminals.
     *     E.g.:
     *
     *         <S> ::= a b
     *         LEXIS
     *         b => a
     *
     *     There cannot be clashes because a getIndex() looks only at the
     *     nonterminal names and at the token names, and not at the lexemes.
     *     Even in a derivation "aa" getting the match of "b" gets the second "a".
     *     Note that only the terminals which occur in grammar rules are tokens,
     *     and not the ones which are in token rules.
     *
     *     The distinction in symNr() is between searching a nonterminal name
     *     (i.e. grammar nonterminals and nonterminal tokens) and a terminal
     *     name. E.g.:
     *
     *         <S> ::= <a> a
     *         <a> ::= b
     *         LEXIS <a>
     *
     *     in "ba", when searching for "a" there is a need to specify whether
     *     it is a nonterminal name or not otherwise it is not possible to tell
     *     what to get.
     *     The alternatives are to tell the kind of symbol (terminal, nonterminal)
     *     in method names, or to pass it as argument.
     *     E.g. getNtIndex(.."identifier",..) vs getIndex(..'t',"identifier",..).
     *     Moreover, since most of the usages are with nonterminals, this case
     *     is the default one, so that there is a need to specify the kind only
     *     when it is a terminal. The same applies to symNr() and symNr().
     *     The method symName(symNr) returns the string of the name of a symbol.
     *     It serves to convert a symbol number into its string. This allows to
     *     convert strings into numbers in both directions.
     *
     *     When a terminal is redefined, it becomes a nonterminal apart for the
     *     name. It is different to get what element corresponds to a nonterminal
     *     from getting what is behind a token.
     *     The latter, when applied to a non-constant token can deliver the
     *     lexeme, when applied to a constant one can just deliver itself.
     *     In both cases it can deliver the lexeme, but in the latter the lexeme
     *     is the same as the token number.
     *     It is also less frequent to call getIndex() on redefined terminals.
     *     Being there or not can only occur if it is in an optional group,
     *     which means that to test it there is a need to check the presence
     *     of the body. This can be done with a getIndex('t',symName) on the
     *     body, but it is less efficient than using getLength().
     *
     *     It could be possible to have a getIndex that can enter groups, but
     *     it is even less efficient, and of doubtful use.
     *
     *     A method is provided which converts symbol numbers in names whose form
     *     is similar to the one which was present in the source grammar (quoting
     *     them) so as to avoid to have nonprinting characters.
     *     The form of such names is similar to a source representation, or even
     *     better a representation in which the terminals are distinguished from
     *     the nonterminals (which is not necessarily a representation that can
     *     be used to build a grammar, but actually it is so). 
     *     This is mainly used for tracing. In traces it is cumbersome to flag each
     *     symbol as being a nonterminal or terminal; it is better to represent
     *     them differently, e.g. as they are in source grammars.
     *     Two methods are provided for internal use only: one for nonterminals
     *     and another one for tokens.
     *     The method symLitName() is provided for applications which like
     *     literalised names with angular brackets.
     *     To make literalization simple, all strings which are not made simply
     *     by alphanumerics are quoted.
     *     The same problem occurs with nonterminals: there is a method which is
     *     able to display they as they were written in the source (assuming that
     *     the Parser BNF conventions were used; applications using different
     *     conventions should provide dedicated methods).
     *     It is difficult to avoid to build strings all the times. However,
     *     literalization is ment to be used in contexts such as tracing, in which
     *     efficiency is less important than simplicity.
     *     Note that it is not convenient to store symbol names as char[] because
     *     it would optimize literalization, but slow down search, which is more
     *     frequent.
     *
     *     To support conversion from names to numbers, some kind of tables of
     *     names is needed. One solution is to have only one table, with some
     *     attributes telling whether they are token names or not, and
     *     nonterminal names or not (e.g. an <identifier> is a token and
     *     nonterminal name). An hashtable with perfect hashing can be used.
     *     It requires a table holding whatever numbers are the representation
     *     of symbols, a table to drive the hashing, and another with the
     *     references to the strings. However, extra-fast search is not needed
     *     here, and thus perfect hashing is not really necessary.
     *     An array can be kept with the references to the strings, with
     *     collisions solved by storing the element in the first free slot
     *     and keeping memory of the maximum number of slots to visit.
     *     However, there would then be a need for another table to convert
     *     the numbers into the strings then.
     *     Another solution is to have separate tables: one for grammar
     *     nonterminals, one for token nonterminals and one for token terminals.
     *     The latter is used because it requires less memory and because
     *     converting numbers into strings is more frequent,
     *     Therefore, arrays ordered by number and binary searched are instead
     *     kept.
     *
     *     Two tables are kept: one for tokens and another for nonterminals.
     *     There is a need to keep in separate tables the strings of token
     *     nonterminals and grammar nonterminals because they have different
     *     numberings: the former ones have numbers lower than the others (and
     *     thus could not be stored in a same table). There is also a need
     *     to distinguish the tokens which are terminals from the ones which
     *     are nonterminals. The metod symNr() to seek nonterminals searches
     *     both tables, and otherwise the first.
     *
     *     The grammar nonterminals are numbered from zero up to ntNrGroups.
     *     They are followed by the internal ones. In ntStrings there are
     *     first the names of the grammar nonterminals, without <> and ordered,
     *     followed by the names of the internal ones, ordered. The latter are
     *     there for debugging.
     *     This separation is useful for the literalization of names since
     *     the internal ones have special names which do not clash with the
     *     others because are handled in a special way.
     *     The internal names cannot be searched.
     *
     *     A table tokStrings for token names is kept, with the terminals first,
     *     and then the nonterminals, and a map which tells the token number
     *     corresponding to names.
     *     The terminals are ordered in their slot and also the nonterminals.
     *     The first slot has terNum entries.
     *     There is a tokNumbers table which maps tokStrings into token numbers,
     *     and a tokOrder tables which maps token numbers into the index in
     *     tokStrings where the string is. This is preferred to keep another
     *     table of strings (ordered by token numbers) because the latter does
     *     not allow to tell if a string is that of a terminal or a nonterminal,
     *     which can be told instead by testing that the index in tokStrings is
     *     lower than terNum.
     *     Tokens have an ordering which is defined on purpose to provide a-la
     *     lex disambiguation in the lexer among the possible matches.
     *     This is better than numbering the tokens according to the ordered
     *     table and having a priority map because the latter is more difficult
     *     to use: when lex() is called and an array of tokens returned (or a
     *     set), there would be a need to search for the most prioritary one,
     *     while by keeping the numbering defined in the lexemes list this
     *     problem does not occur since the most prioritary is the smallest one.
     *
     *     To speed up search, the table of nonterminal names is ordered.
     *     This constrains the numbering of them, but it is not a problem.
     *     The tables of tokens are also ordered. However, not to constrain the
     *     numbering (which must be kept), a couple of maps are created.
     *
     *     To support getIndex(), there is no need to order the tables of names:
     *     it scans the derivations, and tests each element if its name is equal
     *     to the specified one.
     *
     *     Tokens are numbered from 0 upwards. Accordingly, tokTable in ParserFA
     *     maps these numbers to their dictionary entries. Token sets in
     *     ParserState's are sets of these tokens numbers (0..n).
     *     The lists representing sets of tokens in ParserTables, tokLists,
     *     are arrays of token numbers.
     *     There is a difference in the purpose of tokTable and tokNames.
     *     This is the case since the token numbers do not reflect the ordering
     *     of the names of the tokens as needed by a binary search.
     *
     *   Alternatives
     *
     *     Delivering which alternative has been applied in a derivation allows
     *     applications to undertake specific actions.
     *     Applications can have one method for every nonterminal, which makes
     *     a switch at the beginning to address the applied alternative.
     *
     *   Rules
     *
     *     The rule which has been applied in a derivation is an important
     *     information.
     *     The rule number is stored in derivations so as to allow both to obtain
     *     the nonterminal number (and name) and the number of the alternative.
     *     This allows applications to detect which rule has been applied in case
     *     it needs to perform specific actions depending on the rule.
     *     Applications can obtain rule numbers from ruleNr(symName,altNr),
     *     and compare them with the ones delivered by getRuleNr().
     *     E.g. the translation skeme application can keep a table indexed by rule
     *     numbers which contains the translation for each rule.
     *     A translation of a nonterminal is recorded at rule ruleNr(symName,
     *     altNr). A two-level table, indexed by nonterminal numbers and alternative
     *     numbers can be used, but the one-level one is simpler.
     *
     *     The need for having rule number 0..n arises mainly in translation skemes.
     *     Since there are no places in which a ruleNr and a tokNr occur together,
     *     they are enumerated separetely.
     *
     *     Note that the indexes of the rules in the encoded grammar are not
     *     visible at the API.
     *
     *     Repetition groups have no visible rule and therefore have no rule
     *     numbers. Supporting rule numbers for repetition groups would mean
     *     storing the rule number in derivations. Since such rules are internal,
     *     they have little meaning for applications.
     *     Simple and optional groups have a rule number which identifies the
     *     applied (albeit nameless) rule of the body.
     *
     *   Elements
     *
     *     Elements have attached an attribute which tells whether they are tokens
     *     (and what lexemes) or derivations (and which one, for which nonterminal,
     *     or rule). This can be used in applications to scan the elements and find
     *     a given one.
     *     Nonterminals and tokens have a unique numbering which allows to
     *     distinguish them.
     *     Testing that an element is a given token is simple because all tokens
     *     have a unique code. The same holds to test that a derivation is that
     *     of a given nonterminal. The number of a nonterminal and the code of a
     *     token are returned by methods which accept their names.
     *     Another way is to generate these values as constants, and then to use
     *     them in the application.
     *     E.g. in a rule: <A> ::= <identifier> | <number> which are tokens, and
     *     a derivation <A> ::= a, it is possible to know what token that "a" is.
     *     To support this, the token number is recorded when it is a token,
     *     and the rule number when it is a derivation.
     *
     *     In parse trees, tokens are represented as negative integers since
     *     there are no other negative values in them.
     *     The method symNr(symName) delivers the symbol number.
     *     This allows to test if an element is a given token or nonterminal:
     *
     *         int kind = symNr("identifier");
     *         int eleKind = getSymNr(ele);
     *         if (kind == eleKind) ...
     *
     *     If it is a token, it tests that it is the specified one, otherwise it
     *     tests if the element derives from that rule. To test that it is a
     *     derivation of a specified nonterminal, a getSymNr() is used, which
     *     delivers the same code for all the alternatives of a same nonterminal.
     *
     *     Each element is able to tell what it is, even for the tokens. This is
     *     more flexible that having values which need to be interpreted on the
     *     basis of something else.
     *
     *   Terms
     *
     *     A method termNr(ruleNr,symNr,symOcc) is provided to get the term number
     *     of a symNr and symOcc in a rule. It needs the grammar stored in the
     *     parsing tables, and thus can only be used before parsing, or when the
     *     grammar is retained.
     *
     *   Submatch addressing (parse extraction)
     *
     *     The basic mechanism is to access derivations by walking down the tree.
     *     At each node (derivation), another one can be taken by knowing its index,
     *     ordinal number, name, etc. They can also be scanned by using their
     *     indexes, or by usind getNext() which enters groups.
     *     The following access methods to elements can be provided:
     *
     *        1.  by term number
     *        2.  by symbol name or number
     *        3.  by iterating to next element (flattened)
     *
     *     Different representation techniques of derivations have a different
     *     balance with respect to the access methods which makes faster or
     *     slower and with respect to the memory it takes (and the time it takes
     *     to be built). It is then important to know what are the most common
     *     ways to access elements.
     *
     *     1. access by term number
     *
     *     This is the most common way of accessing elements. It can be done
     *     by using numeric constants. The direct access is the most useful
     *     and efficient way of getting submatches.
     *
     *     The termNr() method is provided which returns the term number of a
     *     symbol in a rule. It is one of the most robust way of accessing,
     *     and this allows to use it in cases in which it is used heavily,
     *     e.g. in repetition groups, and at the same time there is a need
     *     to make it independent from the position of the symbol in the rule.
     *     It requires to keep the grammar.
     *
     *     2. access by symbol name or number
     *
     *     This is the getting of an element knowing the name or number of
     *     its symbol. The number of a symbol can be obtained by calling
     *     a symNr(symName) which has its name as argument. The number can then
     *     be stored in some field so as to avoid to call that method all
     *     the times. Alternatively, symbolic constants can be generated by
     *     the parser. If applications use manifest constants, they need be
     *     updated each time the grammar changes.
     *     Note that this kind of access requires to scan a derivation to seek
     *     the element which is an instance of the desired symbol.
     *     The method getIndex(der,symNr,symOcc) does it. It is viable because
     *     in derivations there are not many.
     *     Keeping a map for each rule that maps symbol numbers to term numbers
     *     would be too expensive considering that rules are usually short, and
     *     thus seek time is not long.
     *
     *     This allows applications to have methods that can be applied to several
     *     rules and perform some action on specific elements, like e.g. setting a
     *     flag when some clause is present in a derivation, no matter at which
     *     position in it.
     *
     *     Access by symbol number is more efficient than access by symbol name.
     *     They are appropriate for applications in which efficiency is not top
     *     priority.
     *
     *     3. access by iterating to next element (flattened)
     *
     *     Often groups are used to define sequences of element, like e.g.
     *     <id> {, <id>}*. With the other kind of accesses, the first <id>
     *     would be accessed in a way which is different from that of the others.
     *     The optimal way is to make a loop and access all of them by knowing
     *     how many they are.
     *
     *     The method getNext() is not as efficient as getIndex() to access by
     *     term number.
     *
     *   Groups
     *
     *     For a group there is a need to know:
     *
     *       - for a {}* and {}+, the number of bodies, i.e. how the tree below it
     *         is done, and possibly the indexes of the elements of each body
     *         (this is not strictly needed)
     *       - for a [] if any alternative has been chosen and which
     *       - for a {} and for any of the bodies of all groups, what alternative
     *         has been chosen
     *       - the index of the first body.
     *
     *     The structure of groups is kept (i.e. the parse tree shows what groups
     *     matched) for the reasons reported below. Moreover, there are also reasons
     *     to see groups as if they were flattened in derivations.
     *     E.g. in a rule <A> ::= a {<B> {<C>}*}* {<D>}* <E>, with a derivation
     *     "abbcccd" there can be a need to know the matching:
     *
     *            <A> ::= a  {<B> {<C>}*}*       {<D>}* <E>
     *                    | <B>{<C>}*<B>{<C>}* <D><D><D> |
     *                    a  |  <C>   | <C><C>  |  |  |  e
     *                       b   |    b  |  |   d  d  d
     *                           c       c  c
     *
     *     If there is no way to know that some elements belong to a group, an
     *     application has to scan elements until it finds some given one, like
     *     e.g. some delimiter, or one different from the ones contained in the
     *     group. This is not optimal since it does not work well when there are
     *     no elements that delimit the group, and anyway it makes applications
     *     depend on how groups are made.
     *     Moreover, it defeats the idea that parsing determines the structuring of
     *     data by rediscovering again that structuring.
     *     Parse extraction of groups is also very common in regular expression
     *     packages.
     *     To avoid to test the symbols of the elements to control the completion
     *     of visits, there is a need to know the length of groups.
     *     For simple groups this is known. For optional groups, it is interesting
     *     to know if they are there. They are mainly used for something which is
     *     optional, and then knowing that it has not be specified is useful.
     *     Otherwise there would be a need to store a token or nonterminal which
     *     is the empty string.
     *     However, groups do not necessarily impose a structuring in a derivation,
     *     and thus it must not be imposed to applications: some means should be
     *     provided to allow also some kind of flattened access.
     *
     *     Since groups can be viewed both as elements and as sequences of elements
     *     flattened into derivations, the representation chosen should be optimal
     *     for both, which is difficult. If groups are represented as derivations,
     *     the access by flattened element numbers is less efficient, and if they
     *     are represented inside derivations, the access by symbol ordinal number
     *     is not efficient. Note that it is the presence of repetitive groups
     *     which breaks the correspondence of the terms in a rule with the
     *     elements in a flattened derivation since derivations of rules with
     *     repetitive groups can have a varying number of elements, and therefore
     *     the corrispondence is no longer fixed.
     *
     *     Different solutions provide a different semantics to element indexes,
     *     e.g. if an element which is after another has an index which is one more
     *     than that of the other.
     *
     *     Solution 1: groups as derivations
     *
     *     This allows to know which elements are in a group. The group then would
     *     be accessed as an element with its index in the derivation (and possibly
     *     with some special name). However, this needs to be complemented with
     *     flattened access.
     *     The number of elements of a group is stored in the parse tree.
     *     The elements pair the terms, i.e. the indexes of elements in derivations
     *     correspond one-to-one to the term numbers in their rules.
     *     The flattened element indexes are instead not monotone.
     *     It is lengthy to compute the flattened element indexes: there is a need
     *     to add all the lengths of the ones which are groups. To get the i-th
     *     element, the nested derivations must be visited in preorder adding
     *     up the elements until the i-th one is found.
     *     The problem here is that if we consider a derivation containing groups as
     *     flat, then all its elemens (including the ones in groups) have an ordinal
     *     number, and we could want to access one by its ordinal number, or visit
     *     them incrementing an index. The former is not much practicable, though,
     *     because it can be applied only when there are simple groups or range
     *     groups with fixed repetitions because with repetition groups in general
     *     the element ordinal numbers are dynamic.
     *
     *     To get the index of a term which lays inside a group, the index of the
     *     derivation which represents the group is got and the termNr added to it.
     *     Derivations which represent simple groups are normal derivations apart
     *     for not having a name. The ones of repeatition groups are different.
     *
     *     A representation of groups as derivations, e.g. a repetition followed by
     *     the elements allows also to access sequentially the elements with no
     *     structuring (with getNext). It is then possible to detect the desired
     *     elements by testing their symbol number.
     *
     *     Representating groups as derivations does not allow to access in one step
     *     the elements knowing the symbol numbers and the index of the enclosing
     *     derivation. E.g.: in <A> ::= a {b c {<B>}} d, it is not possible to
     *     access in one step the data of <B> knowing the index of a derivation of
     *     <A>. There is a need to get the derivation of the group, and from it
     *     that of the inner group.
     *     However, this way of accessing is not much frequent because it is
     *     possible only with simple and optional groups since the others can have
     *     many bodies, and although walking down would be longer, it would mimic
     *     the structure of the rule, and thus be known at programming time.
     *     E.g. getElem(getElem(getElem(der,1),0),2).
     *
     *     The method getNext() either carries along the list of derivation numbers
     *     entered or the derivations for groups must be sewed (by having a last+1
     *     element that contains the number of the following one.
     *     The list of derivations serves to allow getNext() to go back to an
     *     enclosing group when called with an index which is the last of a group.
     *     Since it is costly to carry along the list of derivations entered, the
     *     derivations of groups are sewed.
     *     Moreover, either a sentinel is present in all derivations, or derivation
     *     heads are distinguisheable, or getNext() needs to have the derivation
     *     as argument. This is because if there is no sentinel, then getNext must
     *     determine if the index reached lies within the ones of the derivation
     *     so as to tell when it has ended.
     *
     *     Backlinks can be distinguished from elements (see below). When a
     *     backlink, or even an index, refers to an element in a group, then the
     *     next is either an element, or a backlink.
     *     When it refers to an element in a derivation which is not the one of
     *     a group, the next can be another element, or what is past the derivation.
     *     Either at the end of the derivation there is a sentinel, or elements
     *     should be distinguisheable from headers of derivations.
     *     This allows to spare to pass the derivation as argument to getNext().
     *     Note that the need to tell when the visit of the elements of a derivation
     *     ends occurs also when there are no groups: either the length of the
     *     phrase is known, or the element after the last must be distinguisheable.
     *     The range of integer values is split between elements and non-elements:
     *     group lengths and rule numbers.
     *     Tokens are negative, derivations (and backlinks) are from 0 to 2**30-1,
     *     and headers are from 2**30 onwards.
     *     This means 1 Giga values, which is considerably high.
     *     This encoding allows also to check that an index argument of an API
     *     method call is a derivation index.
     *     Storing a zero sentinel in non-groups derivations is possible, it
     *     requires more memory but is allows to double the size of parse trees.
     *     However, since 2**30-1 is quite a large value for parse trees, the
     *     former solution is preferred since it saves memory and allows also
     *     to check the correctness of derivations indexes in API calls.
     *
     *     In derivations which do not represent repetition groups, the rule number
     *     is stored. This allows to deliver the rule number and the symbol number
     *     and also to deliver the length of the phrase. These derivations have a
     *     fixed number of elements which is reported in a table indexed by rule
     *     numbers.
     *     Derivations in parse trees are allocated in postorder; backlinks are
     *     therefore values which are higher than the index of the element that
     *     contains them. This makes backlinks distinguisheable from derivations and
     *     tokens.
     *
     *     Derivations for repetition groups have a repetition, but do not have a
     *     rule (whis is useless: the rule of a group is an internal one which is
     *     a device to allow its body to occur several times). Bodies have a rule.
     *     It is quite difficult to factor out the rule of bodies (which can only
     *     be done when there is only one rule for the body).
     *     All groups which can have a number of bodies > 1 are recorded in
     *     derivations as repetition groups. Simple and optional groups are
     *     recorded as normal derivations (with a backlink, though).
     *     The non-group derivations have a rule attached so as to allow
     *     applications to know it (i.e. they are self explanatory). This because
     *     such rules are known objects, which usually have a well defined meaning
     *     for applications.
     *     Groups are internally represented as rules, but this is an internal
     *     matter. Simple groups are represented as a normal derivation, and also
     *     the optional groups.
     *     It is possible to know that a derivation is that of a repeat group
     *     because one expects it, and it is also the way to represent a sequence
     *     of a varying number of bodies.
     *
     *     Solution 2: groups inline
     *
     *     The bodies could be stored directly into the derivation in which they
     *     occur. There would then be a need for a map between term numbers and
     *     element indexes, which contains also the repetition numbers.
     *
     *     Alternatively, the number of elements of a group can be stored before
     *     them in flat derivations.
     *     The element indexes would no longer pair term numbers.
     *     The flattened element numbers would not be monotone since there is an
     *     extra element (the repetition) that need be skipped, which makes loops
     *     complex to implement.
     *     To access randomly what is past groups efficiently there is need for a
     *     representation of the derivation which can be accessed randomly with
     *     term numbers.
     *     To have it, a map can be stored which contains the element number (or
     *     index) of tokens and nonterminals as positive values and for groups the
     *     negated index of their map in the tree. Keeping it negative allows to
     *     distinguish it from non-groups.
     *     For derivations which do not have groups there is no need, for the others
     *     (which can be represented by a negative length) the map can be put at the
     *     end.
     *     For groups the map should map all the symbols in each body.
     *     E.g. consider the rule <A> ::= a {{b}* <B>}* and the derivation
     *     ab<B>bb<B>.
     *     The body b<B> has <B> at term number 1, while bb<B> has it at 2.
     *     Thus, there is a map for each body. Each map can also contain the length
     *     of the derivation of the body (and perhaps the length of the rule).
     *     Note that there is a map for all groups, which maps their flattened
     *     contents.
     *     As for normal rules, if a group does not contain (inner) groups, there is
     *     no need for a map of its own. This can be indicated by a negative length.
     *     Note that direct access to elements is not possible, or at least not easy
     *     since repetition numbers stored inline break the sequence of indexes.
     *     This means that there is a need for a getNext() which has the derivation
     *     as argument, that can recognise where the repetitions are and skip them.
     *
     *     The first alternative seems better than the second. Both require to store
     *     maps, and to access them to allow direct access. This solution makes
     *     faster the scanning of elements, and to make direct access by term number
     *     reasonably fast, it requires memory for maps.
     *
     *     Another alternative is to keep two representations for derivations with
     *     groups. When getting elements by element numbers the flattened
     *     represention would be used, and when getting elements by term numbers,
     *     the nested representation would be used.
     *
     *     In order to access the rule applied in a body (e.g. the number of the
     *     alternative) there is a need to store the rule numbers in maps.
     *
     *     Since the sequence of elements does not pair the terms in rules, to
     *     access the next term knowing the index of the previous requires a method
     *     that has the derivation and the term number as arguments.
     *
     *     The representation with groups inline is more complex and less terse
     *     than the other. Therefore the other one is chosen.
     *
     *     Case study
     *
     *     This is a summary of typical excerpts of accesses to groups by applications:
     *
     *     case a: process one or more specific elements in all bodies.
     *             I.e. all bodies are visited, and the desired elements of each
     *             body are obtained. Note that this is not the scanning of all
     *             elements.
     * 
     *             E.g.: <id> {, <id>}*
     *
     *     - since bodies are represented as derivations, there is a need to
     *       go inside them:
     *
     *       ele = getElement(der,id_termNr);          // get first id
     *       gro = getElement(der,id_termNr+1);        // index of the group
     *       rep = getLength(gro);                     // nr of bodies
     *       for (i = 0;; i++){                        // visit all bodies
     *           ... process id
     *           if (i == rep) break;
     *           int body = getElement(gro,i);         // body
     *           ele = getElement(body,1);             // get id
     *       }
     *
     *       N.B. if the element were a repetition group, it would be accessed as:
     *
     *          int len = getLength(ele);
     *          for (int j = 0; j < len; j++){
     *              ... access the inner group
     *          }
     *
     *       (If bodies were not represented as derivations, the length would
     *       contain all the elements, and there would be a need to make the
     *       loop counter step in such a way to stop on the desired ones).
     *
     *     - independently on how bodies are represented, and on whether they
     *       contain inner groups:
     *
     *       i = prs.getIndex(der,id_termNr);
     *       end = prs.getIndex(der,id_termNr + 2);    // index of element after the group
     *       do {
     *           int ele = prs.getElement(i);          // get id
     *           i = prs.getNext(i);
     *           if (i == end) break;
     *           i = prs.getNext(i);
     *       } while (true);
     *
     *       Note that to support this, getIndex delivers always the element
     *       which is after the group (which can be at the end of a derivation),
     *       returning 0 consistently with getNext() when there is no such element.
     *
     *       The method getNext() scans a derivation and all its groups, as if
     *       it were flattened, but it does not enter derivations for nonterminals.
     *       Derivation indexes refer to the header element, which allows to get
     *       any element, including the first by a call to getIndex().
     *
     *       This is useful when the user needs to use groups because it has
     *       to allow several alternatives in a place, like e.g. when it had
     *       a rule <A> ::= a b c, and later on needs to make that "b" be also
     *       a "d": <A> ::= a {b|d} c. However, it needs only to take what
     *       elements are there, with no structuring.
     *
     *       Another common case is, e.g. {<id>}+, which is even simpler.
     *
     *     case b: visit all the elements of a flattened derivation
     *
     *       In general, getNext() must be used. For groups which do not contain
     *       other groups, a loop can be done incrementing the index.
     *
     *     Structure of groups
     *
     *     This is the structure of groups as seen from the API:
     *
     *     - simple and optional groups
     *
     *          {a}      a            &0
     *                         or      |
     *                                 a
     *
     *       The possible solutions are to make the body visible or not. This is
     *       even more evident when these groups occur in other groups.
     *       Note that a simple group has one body only, and could also be handled
     *       differently from a range group which has more. 
     *
     *       Alternative 1: bodies not delimited
     *
     *       A simple group would have a body which is flattened in the derivation.
     *       It would no longer be possible to tell that an element was a group,
     *       or that the empty string was chosen in an optional group.
     *       Note that flattening bodies makes the elements no longer pair the
     *       terms in rules.
     *
     *       Alternative 2: bodies delimited
     *
     *       A simple group would have a body which is an element in the enclosing
     *       derivation. Most RE packages also delimit them.
     *       All optional groups and simple groups would have a rule number as
     *       normal derivations, albeit hidden. Consequently, the alternative
     *       number can be obtained. However, it is not possible to get the rule
     *       number. Optional groups would be represented with a normal derivation
     *       which has as a rule either the one for the empty string or the one
     *       for the body. This is simpler than representing them as repetition
     *       groups.
     *
     *       Alternative 3: some bodies delimited some not
     *
     *       A body could be used only when there are several alternatives.
     *       This also would make elements no longer pair terms since single
     *       alternatives can contain several elements. If the repetition groups
     *       do not delimit bodies too, using a simple group inside them would not
     *       help to make bodies delimited. Alternatively, a body could be kept
     *       when the rule contains just one term.
     *       This seems to simplify programming little, and prevents to use simple
     *       groups to delimit bodies in repetition groups.
     *
     *       Range groups with only one body defined (e.g. {a}(1)} must become a
     *       degenerated case. It would be cumbersome to access the group, and then
     *       access the body, and they what is inside it.
     *
     *       In conclusion, opening groups, i.e. placing their elements into the
     *       enclosing derivations has more drawbacks than benefits. Doing it only
     *       when their rule has only one element introduces some lack of uniformity
     *       for a case which occurs seldom, and cannot be applied to optional
     *       groups anyway. Therefore simple and optional groups are represented as
     *       derivations.
     *       For option groups, to distinguish the case when there is no body
     *       from the one in which the body is present (albeit empty, which is
     *       the case when the body contains an empty rule), a derivation for
     *       a repetition group with zero repetitions is generated. Consequently,
     *       it has no rule. If instead the body matches the empty string, a
     *       normal derivation is generated, with an empty body.
     *
     *     - repetition groups
     *
     *         {a}*         &0              &0
     *                     /  \     or     /  \
     *                     a   a          &1   &1
     *                                     |   |
     *                                     a   a
     *
     *       The possible solutions are to make the body visible or not, i.e. if it
     *       should be possible to see what belongs to a body.
     *
     *       Alternative 1: bodies not delimited
     *
     *       This alternative is based on the rationale that a group {a}* stands
     *       for "", a, aa, aaa, ... and not "", {a}, {a}{a}, {a}{a}{a}, ...
     *       and therefore bodies should not be delimited. When there is a need to
     *       delimit bodies, {{a}}* must be used.
     *       Note that the introduction of a <&1> for bodies is only because the
     *       body occurs in two places in the rule of a group. It has no relation
     *       to the visible structure.
     *       This solution makes derivations follow the structure the rules have:
     *       each group has just one derivation.
     *       In this solution it is not possible to know what elements made a body,
     *       and also what alternative in a body was applied. E.g. in {a|b}* with
     *       derivation "ba" it is not possible to know that the second alternative
     *       was applied and then the first.
     *       This is reasonable since in this solution bodies vanquishes and thus
     *       there is no point in knowing what alternatives had been applied.
     *       This solution gives basically flat repetition groups, and requires
     *       applications to enclose bodies in simple groups when they want to
     *       retain the structuring in bodies.
     *       This is flexible, apart from when the grammar is given and must not be
     *       changed (and there is a need to tell what bodies matched).
     *       To put in a same derivation the bodies without separating them, the
     *       item lists must be scanned by calling encodeTree() telling not to
     *       create the the header and terminator.
     *
     *       Alternative 2: bodies delimited
     *
     *       This allows to know what each body matched. Delimiting bodies is the
     *       solution that provides the maximum of information, perhaps with some
     *       loss of friendliness.
     *       In this solution it is possible to know what alternative a body
     *       applied. E.g. in {a|b}+ with derivation "ab" is would be possible to
     *       know that "a" is an occurrence of the first alternative, and "b" one
     *       of the second. However, there is a need to walk down those
     *       derivations to get them.
     *
     *       Alternative 3: some bodies delimited some not
     *
     *       There are some reasons to distinguish the case of a body with one
     *       alternative from the case of a body with several: when there are
     *       several, there is a piece of information which can be useful to keep:
     *       to know which alternative has been applied in each body.
     *       When there is a single alternative, the only one benefit of delimiting
     *       bodies it to know what matched a body. Flattening bodies, however,
     *       makes difficult to access directly elements, which should then be
     *       accessed sequentially.
     *       Another solution is to reduce bodies only when their rules contain one
     *       element only. This would eliminate the problem of telling what elements
     *       make up a body. E.g. a {<A>}* would be represented as a sequence of
     *       elements denoting <A>.
     *       This solution has the drawback that the programmer must take into
     *       account what is inside groups since the derivations would not always
     *       have the same structure.
     *
     *       The delimitation of bodies is chosen because it provides the most of
     *       information and is the simplest.
     *       The idea of flattening groups in the parse tree (or at least to
     *       provide a view of the parse tree with flattened groups) comes from
     *       the interpretation of groups as:  alpha {beta}* gamma  be the same
     *       as alpha gamma | alpha beta gamma | .. which is not the case.
     *
     *       Note that groups here do not contain usually bodies of one character,
     *       they are at the grammar level, and thus an extra operation to enter
     *       bodies is not so costly either in terms of performance and of
     *       programming.
     *       The idea also to support several alternatives and let application
     *       choose seems also not appealing.
     *
     *     Empty groups
     *
     *       []      is represented as {}
     *       {}      is represented as {}
     *       {}*     is represented as {}      repGroup
     *       {}+     is represented as {""}    repGroup
     *       {}(2:4) is represented as {"" ""} repGroup
     *       {}(2:)  is represented as {"" ""} repGroup
     *       {}(:4)  is represented as {}      repGroup
     *       {}(2)   is represented as {"" ""} repGroup
     *
     *       N.B. {a}(2:4) which matches "aaa" is not represented as aaa "".
     *
     *    Nested groups
     *
     *       Access to nested groups is done by walking down the nesting.
     *       In some RE package they are referred to by a number which is the
     *       ordinal number they occur in their rule. This access is less
     *       clean than the nested one.
     *
     *
     * Storing lexemes
     *
     * Tokens are characterised by:
     *
     *        token number, stream index (point), lexeme (string).
     *
     * The token number serves to know what a lexeme is. It could be useful
     * in actions.
     *
     * The point serves for error reporting, mainly for semantic errors detected
     * in actions.
     * Not all lexemes need to have a point in the input attached: there are
     * cases in which applications need them only for some lexemes.
     *
     * The lexeme serves in actions since it is primary information. Not all
     * lexemes are needed, though.
     *
     * The need for applications to have the point and/or string can also be
     * different for each occurrence of token in each rule. 
     * E.g. there can be a rule in which there is no need to store the point
     * of a keyword, and another in which there is for the same keyword.
     * This could be particularly useful in fuzzy parsing, when a parser is used
     * to seek some parts of a text while considering all the rest as noise,
     * which can contain also tokens that in such a place do not need to save
     * their string or point.
     *
     * By default, the string and the point of non-literal tokens are stored,
     * those of the literal ones are not, even if case insensitive.
     * This allows to save space since lexemes and points are of litte use for
     * literal tokens (which are the majority).
     * To specify point/string storing, the storage directive can be specified
     * on the lexemes in the LEXIS list. It applies to all occurrences of said
     * lexemes, unless otherwise specified by directives appended to terms.
     * These directives allow to specify the storing or otherwise (superseding
     * the default, or global setting.
     * When specified on terms, the enclosing rule must be a grammar rule, and
     * the term must be a lexeme.
     *
     * Storage directive are rejected when specified on rules that are not
     * grammar rules (or on terms which are not tokens) because confusing
     * (they could occur on singletons whose definition is a lexeme leading
     * to think that it supersedes its directive). This is done also on rules
     * which belong to both the grammar and the lexicon.
     *
     * To determine that a token is literal irrespectively of case spec, its
     * rule is analized.
     *
     * The directives attached to nodes (terms) are stored when they are parsed,
     * and after the whole grammar is done, they are taken into account.
     * Storage directives are processed as follow as the lexis list is analysed:
     *
     *    - the data of directives is copied from the lexis list (made of
     *      ParserNode) into the dictionary entries, which serve later when
     *      getting the global setting.
     *    - then the data are propagated from the shorthands in the lexis
     *      list to the elements defined by them recursively, and also to
     *      the elements defined by TERMINALS.
     *
     * The store attributes of lexemes and those of points are kept in two bit
     * arrays, indexed with the grammar index of terms: they represent the
     * composite result of the default for literal lexemes (attribute which
     * needs to be kept in dictionary entries), the directives on the lexis list
     * and those on terms.
     *
     * Occurrences of singletons in the encoded grammar carry along the storage
     * attributes of their targets. This is needed because there is a need to know
     * what to do when looking at the occurrences of singletons.
     * Note that there cannot be a directive on a term that is a nonterminal,
     * a singleton in this case, and therefore the occurrences of singletons
     * do not have attributes on their own.
     *
     * Lexemes are stored in a pool, which allows to save space, and to represent
     * them by a pool index.
     *
     * The percentage of literals over total tokens in common cases is 30%.
     * What is important here is to spare the introduction of strings in the pool,
     * which can be done when a token has a definition which is basically the same
     * as its string. This is what happens with all the tokens which are introduced
     * automatically since they are terminal strings, and with the ones whose rule
     * defines the same string.
     * The ones whose rule defines only one string have a lexeme which is of little
     * interest too, and also the ones which have only one string and also are
     * case-insensitive.
     *
     * There is not much space saving in avoiding to store literal lexemes in the
     * pool (expecially when compared with the parse tree space and the tokens
     * list). However, 2.5% parse time is saved. The percentage of tokens which
     * need be stored in the tokens list over the total number of tokens on average
     * is 30%. The tokens list occupies twice as much as the pool.
     * The pool and the token list size is comparable with that of the text.
     *
     * When the text is in memory, it is possible to represent lexemes directly
     * by the point and length without keeping a pool. However, a same string
     * would no longer be indentified by a unique value, unless the hash table
     * were build (by using special HashCharRow elements containing rows to
     * strings). The latter could be controlled with a mode.
     * If the HashCharRow hashtable was used, there would be no differences in
     * storing with respect to the case in which the text is not in memory.
     * Note also that the point would take at most two chars.
     * However, since the pool is normally not big and allows to discart the text
     * after parsing (which would otherwise be needed), this treatment of memory
     * text is not done.
     *
     * The methods which deliver the string or lexeme number, when applied
     * to lexemes whose string is not stored, deliver the token name or the token
     * number. To have a number which can be used as lexeme number, a unique
     * numbering is given: values < numOfToks represent literal tokens, and
     * getLexeme() on them delivers the string which is in tokNames; values which
     * are higher denote non-literal tokens, and getLexeme() on them subtracts
     * numOfToks before accessing the pool.
     * Note that string of literal lexemes is the token name (which is identical
     * to the lexeme for terminals).
     *
     *     getLexNr:  if no lexNr present: deliver tokNr, else deliver lexNr
     *     getLexeme: if no lexNr present: deliver tokNames, else lexeme
     *
     * There are three aspects here:
     *
     *     1. where to keep the data of tokens during recognizion
     *     2. how to represent them in the parse tree then
     *     3. how to indicate in the source grammar what to store
     *
     * Storing by the engine
     *
     * The engine stores the token representation in items (in the sub field of
     * the ones which scanned a token, being it unused for them).
     * The engine calls the lexer which returns the token numbers, which represent
     * the set of symbols found. This is compared with the tokens expected by the
     * items. Each item matches a specific token, and thus after matching there
     * are no tokens sets to remember.
     * Since there is one lexeme for each items list, the engine could store the
     * token number, pool index and point in it, e.g. the point and the pool in
     * the left and sub fields of the sentinel. Besides the difficulty of storing
     * the point, which is a long, this would make difficult to build derivations
     * since items lists need be scanned to find the sentinel.
     * N.B. the left of items is used when building the parse tree.
     * Moreover, points are long, and thus the items lists are not a viable place.
     * The tokenizer cannot deliver the value to be stored by the engine since
     * it does not know if it has to store the lexeme and the point, and also
     * what token has to be stored among the ones which match the same lexeme.
     * After recognizion, the engine moves the token data from the items lists
     * to the parse tree, and then terminates the items lists.
     *
     * First solution: variable length, inline
     *
     * In this solution, the data are stored directly in derivations. This,
     * however, would break the correspondence between term numbers and elements
     * in derivations. It saves memory, though, because storing each token as an
     * integer which refers to another place where the data are kept requires more
     * memory than storing directly the data.
     * It could be possible to know the element relative indexes for terms if
     * token elements were represented with a known number of entries in
     * derivations. This means 12 bytes, while for a medium text the tokens list
     * solution requires 8 + 4 for the element = 12. I.e. the same, but the
     * tokens lists do not cause indexing problems in derivations.
     * Moreover, tokens lists allow to store points selectively.
     * Note also that the progression of elements indexes is visible at the API.
     * E.g. the element which follows a given one has an index which is that of
     * the former + 1. This makes this solution not viable.
     *
     * Second solution: tokens list
     *
     * Tokens for which point storing is not required and whose token number and
     * lexeme index can be packed are stored inline, the others in the tokens
     * list, and the index stored in derivations.
     * Packing is convenient since it can be used often being the number of tokens
     * usually not high.
     * This is applicable when there is no need to store points.
     * Token numbers are packed by multiplying the pool index by numOfToks,
     * i.e. without taking into account EOF. This is correct since it is used
     * only internally during parsing, and never delivered in the parse tree.
     *
     * The tokens list is a sequence of elements, each one representing a token
     * (as defined above) with elements packed in blocks.
     * The recording of the indexes is done by compressing them in the same
     * way ParserPool does: by using less bits for the values which have less
     * bits. They are stored in chars. It is too cumbersome to go down to bytes.
     * This allows to use longer indexes only for huge texts, which need long
     * indexes anyway, and occurs seldom.
     * For small texts it amounts to: token nr: 2, point: 2, pool: 2 = 6 bytes,
     * for medium 8, and for large 12.
     * The tokens list is accessed through the parse tree by the methods which
     * get the data of the derivations.
     * The list of tokens takes memory too, even worse if lexemes were stored
     * directly in it. Since a same lexeme commonly occurs several times in a
     * text, it is stored only once in a ParserPool. Moreover, storing in
     * ParserPool takes less memory even when lexemes occur only once since
     * it compresses lengths, etc.
     * There are at most Integer.MAX_VALUE tokens.
     * A tokens list could be useful to hold references to comments too.
     *
     * To stay on the safe side, the parse tree is kept self explanatory for
     * what concerns the decoding of the representation of tokens.
     * I.e. there is no need to have the grammar to tell how a token is stored.
     * This allows to support storing on per-occurrence basis.
     * The cases are:
     *
     *     - inline                       00
     *     - in-pool, string              01
     *     - in-pool, point               10
     *     - in-pool, string and point    11
     *
     * In the inline case, the presence of the lexeme is told by its value, which
     * is always > 0.
     * This means 0.5 Giga tokens. When they are inline, lexNr could be zero,
     * denoting no string.
     * When the point is stored, and/or the tokNr and lexNr are too large to be
     * packed, the in-pool representation is used.
     * Compressing lexNr in pool does not reduce the number of representable
     * values; compressing the point reduces it by 2 bits, which is not much.
     * Since there are only 4 cases, they can be represented by 2 bits in the
     * encoding of tokens in derivations.
     * There is no need to test that lexNr is in a range that can be compressed
     * because with two chars it is possible to store 31 bits.
     *
     * There is a need to make the representation of tokens, be either inline
     * or referring to the token list different from zero, including the case
     * of the EOF. Zero values cause problems in encodeTree() because is negates
     * the sub fields to mark the visited items (and thus needs values > 0).
     * Note that this can occur with the token whose number is zero if its storing
     * attributes allow an inline representation. Moreover, when there are no
     * tokens, the only one which is stored is the EOF, which would have 0 as token
     * number, and being not stored in the pool, zero as well as lexeme number.
     * Note that the token number of the EOF is numOfToks, which is zero here.
     * To do it, 1 is always added to inline representations (inline is the only
     * one case in which 0 can occur: it does for tokens which have tokNr = 0 and
     * are not store in the pool). There is no need to make a special case for EOF
     * since the only one place in which the token for the EOF need be processed
     * is in itemToString(), and there it is detected and represented properly.
     *
     * Unfortunately, most of the times lexemes storing and point storing come
     * together, which makes the inline representations used mainly for literal
     * tokens. However, it is difficult to avoid it.
     * What is a pity is that the inline representation cannot be used because
     * of the storing of the point, which is used seldom by apps (mainly to
     * report errors). The problem is that it is difficult to store it
     * somewhere else (and retain a reasonable access time). An ordered array
     * would help little because it would require to store the index as well.
     * Here the problems is the anchoring of the elements into the text.
     * It could be possible to keep a list of the points of the lexemes for
     * which points are required, ordered as they occur in the text, compressed,
     * or represented as offsets with respect to some harder points which are
     * stored periodically. E.g. the points of the first elements in derivations
     * and the offset of the others, to be accessed with a binary seach (which
     * implies that the vector has been ordered).
     * There would be a need to keep the grammar to find the first term which
     * has point storing specified. Moreover, there would be a need to determine
     * the derivation containing an element from the element.
     * This is too much complex compared with the memory required for the
     * tokens list.
     *
     * When the lookahead is got, the data of the previous lexeme would be
     * lost. They need either be used or saved before that. This is not a
     * problem for the point, but it is for the string (the lexeme) and the
     * set of token numbers. There are these alternatives:
     *
     *   - when running the scanner, the lookahead is not used: the candidate
     *     items to be advanced are inserted in the potter (it becomes a bit
     *     bigger, but it is not much long anyway, some dozens of elements).
     *     During this, the presence of at least one candidate item that requires
     *     storing in pool is noted, and the item stored in the pool. That item
     *     could later turn out not to be inserted in the kernel, and the lexeme
     *     inserted in the pool for nothing. However, this is no problem since
     *     the spurious lexemes in the pool are not many (none in common grammars).
     *     There is no need to save the set of token numbers since it has been
     *     used when putting the items in the potter, before reading the next
     *     token.
     *     Then, the next token is got, and the kernel build out of the potter,
     *     discarting the elements which do not match the lookahead.
     *     However, a lot of (spurious) tokens would be introduced in the tokens
     *     list for items that later on turn out to be dead. They are generated
     *     when the point need be stored. In common cases, they are as many as
     *     the others.
     *     In most of the cases, identical tokens are inserted. This is overcome
     *     by refraining to insert a token in the list when it is identical to
     *     the previous one.
     *
     *     Alternatively, the lexeme could be stored when building the potter at
     *     the cost of having stored some more useless strings, but measurements
     *     show that this decreases the speed.
     *
     *   - the lexeme can be saved in a temporary buffer before getting the next.
     *     It should not be a problem for memory (except when there are long
     *     comments).
     *   - the input buffer can be marked forcing it to keep the previous lexeme.
     *     It should be better than the previous solution. However, it would
     *     enlarge the input buffer, which will contain two lexemes with their
     *     comments. This solution and the previous one insert less useless
     *     lexemes in the pool. Note that later on, a scanned item with a viable
     *     lookahead (that caused its lexeme to be stored in the pool) could turn
     *     out to be part of a derivation that is a dead end, and others which
     *     did not require the lexeme to be stored in the pool be the right ones:
     *
     *           <S> ::= <key> a b | <id> a c
     *
     * Keeping the lexeme in a buffer or in the input buffer can spare some pool
     * insertions which are instead done with the other solutions.
     * Since the number of spurious lexemes in the pool is not high in general
     * (in common grammars it is zero), the first solution is chosen since it
     * is more efficient.
     */

    /** The (directory of the) parse tree. */
    int[][] tree;

    /** The number of blocks in the directory of the parse tree. */
    int treeBlocks;

    /** The length of the parse tree. */
    int treeLen;

    /** The index of the starting phrase in the parse tree. */
    int treeStart;

    /** The index of storing in the parse tree. */
    int loc;

    /** The number of derivations in the parse tree. */
    public int derNum;

    /** The number of elements in the parse tree. */
    public int eleNum;

    /** The number of alternative trees in the parse tree (forest). */
    public int altNum;

    /* Allocation details of the parse tree
     *
     * To spare the need to determine the size of the parse tree in advance,
     * a tree made of blocks is used.
     * Derivations are stored with no gaps and no holes between blocks (and
     * thus can cross blocks). It is homogeneous: the parse tree contains
     * derivations only (and therefore it can be visited moving from one
     * derivation to the next).
     * The storing of derivations into the tree is controlled with a location
     * counter, which grows up from zero to Integer.MIN_VALUE (which occurs
     * when the last possible block is completely filled).
     * The condition is that the last element to store has an index which
     * is within the range of the allowed ones and is allocated. If n is the
     * number of elements to store, and loc is the index of the first free
     * position, then x = loc + n - 1 is the index of the last element.
     * This expression never overflows even if loc and n = Integer.MAX_VALUE.
     * If loc has moved to one after that, it does not overflow either.
     * Note that loc at most could indicate one element after the last possible
     * one, which in this case has index Integer.MAX_VALUE.
     * To be a valid index, that expression must be <= 0.
     * The number of the block of that location is: x >>> NSHF.
     * If it is >= treeBlocks, then there is a need to allocate.
     */

    /** The flag of the derivation fields which denotes symbol header. */
    static final int HEADSYM = 1 << 31;

    /** The flag of the derivation fields which denotes header. */
    static final int HEAD = 1 << 30;

    /** The field of derivation heads. */
    static final int HEADF = HEAD | HEADSYM;

    /* Building the parse tree
     *
     * The building of the parse tree requires to solve the references among
     * phrases. This can either be done by allocating them in referred-first
     * ordering (reverse topsort) and remembering the indexes (to be used when
     * the referring subprases are generated), or making a prepass determining
     * the placement of all phrases, and then generating them in any order.
     * It is possible to scan a safe list backwards and even its window, and
     * allocate the phrases, but the whole process is not simple since first
     * the useful items need be collected (in postorder to generate the
     * referred ones before the referrers) and then the collected items
     * visited to allocate them. Therefore, the first solution is chosen.
     * 
     * Walking the subtree
     *
     * In order to avoid to use recursive calls since the stack does not
     * allow for much recursion, the items are visited in a single call.
     * This happens also with safe lists when there is a right recursive
     * rule in the grammar. The last list of a right recursive rule has
     * at least as many items as the depth of recursion irrespectively on
     * whether the previous ones are safe or not.
     * A chain is built of all the final items that need be part of the
     * parse tree. Starting from the item which is the root of the subtree
     * to encode, the visited items are marked:
     *
     *   - each item is in one of these states: not to be visited, to be
     *     visited. Initially all items are in the first state, except for
     *     the one at which visit starts. When visiting an item, it becomes
     *     not to visited, and the ones referred to by it become to be visited.
     *   - when visiting the subpointed item, insert is item in the chain.
     *     There is a need to cater for shared subtrees:
     *       - items inserted in the chain are flagged as such
     *       - when a flagged item is being inserted, there is a shared
     *         subtree. The items are visited again to compute the number
     *         of referrers for each item, and then another time to build
     *         the list inserting shared items only after the last referrer
     *         (and not after the first as it would happen in a single pass).
     *         The use of a doubly linked list is slower (and needs an extra
     *         field for each item).
     *   - items whose chain has been encoded previously (in a previous call
     *     to encodeTree) are not visited.
     *
     * The resulting chain has items representing deeper derivations first.
     * I.e. items in it (and in their left chains) always refer to items
     * which lie before in the list. This spares to compute the placement
     * or tree size since derivations are processed one at a time entirely,
     * and the indexes of the referred items are known when needed.
     * Testing for tree space when generating each phrase is cheaper than
     * extracting the rule kinds when marking items (which is needed
     * to compute tree size).
     * Shared subtrees can occur: suppose that there are two items I1 and I2
     * referring a same one S in this order:  I1, S, I2. When the chain is
     * build, it would be exactly in the same order. However, when I1 is
     * processed, it requires I2 to have already been processed. The result
     * is that an incorrect value is stored as reference (there are no
     * backlinks because shared subtrees do not occur with groups except for
     * empty OBO items, which are not a problem).
     * The best would be to reorder the chain. A shared item should be
     * inserted in the chain by the last one that references it, not by the
     * first one. However, this requires to keep a doubly linked list, which
     * entails a penalty for all items, even when there are no shared subtree.
     * It is cheaper to rebuild the chain only when there are such subtrees.
     * Reference counts are computed, and when visiting a referrer, the items
     * referenced to by it are inserted in the chain only when the reference
     * is the last one.
     * Left shared items are not a problem since they are not in the chain
     * and moreover, they are only predicted items, which are not really
     * visited.
     * The chain is made by linking backpointer fields.
     *
     * Processing the items
     *
     * The chain is then scanned, and for each item I in it, the phrase
     * represented by its left chain encoded. Its index (negated) is stored
     * in the backpointer field of I. This serves when a later reference
     * to that phrase is needed. This is also the place when the index of
     * a phrase generated in a previous run of encodeTree is kept.
     * Items in left chains are encountered in reverse ordering.
     * This applies also to groups since they are treated directly in the
     * engine.
     * Items which denote tokens are processed also, and the parse tree
     * representation of them stored in the same place.
     * All phrases are filled in reverse ordering and thus there is a need
     * to know the number of their elements (to displace in the tree).
     * However, in a left chain there can be elements which must not be
     * counted when rekoning the phrase length. This occurs only with
     * groups. A dedicated loop scans a left chain and determines the number
     * of group bodies.
     *
     * When a derivation has lower index than another, it represents the
     * matching of possibly inner rules, or rules which occur earlier.
     * E.g. in <A> ::= <B> <C>, the ordering in the tree is <B> <C> <A>.
     *
     * This needs less housekeeping than walking the items representing the
     * tree to be encoded. It makes only two visits.
     *
     * Optional and bounded groups
     *
     * Option groups need a special treatment. They have a rule which is never
     * singleton-reduced because its has two alternatives, but that has a body
     * which can be a singleton. Its body must be flattened into the &0 rule
     * (otherwise there would be an extra nesting).
     * It is not convenitent to make such a treatment when an option group
     * occurs as element in another derivation because it can also occur
     * in a rule of a singleton (e.g. in [[]]), whose derivation is created
     * on the fly without checking what is inside it. Therefore, they must be
     * treated when they are entered.
     * The group can either contain nothing, or a body which can also be a
     * singleton reduction. When it contains nothing, the geneated derivation
     * is empty and it is that of a repetition group.
     * When it contains a body which is not a singleton, the body effectively
     * replaces the contents of the current derivation. When it is a singleton,
     * it has been expanded before.
     *
     * Optional groups are different from bounded groups because the latter
     * are made of phrases in which a sub-phrase is present for each body,
     * while in the former the body is flattened in it. This requires to
     * go down one level in the items of the body, except when it is a
     * singleton.
     * These cases are treated by processing the items without generating
     * a phrase in the parse tree. If the inner item is not a singleton,
     * its representation becomes that of the upper one. Otherwise, singleton
     * chains are generated, and the index of the top one becomes the
     * representation of the upper item. Such representation is then stored
     * in its backpointer field.
     * This could also be done by changing all the references to such items
     * into references to their subpointers, but it requires to process all
     * terms.
     *
     * Note that groups are handled correctly also when build incrementally
     * by subsequent calls. The only one cases in which groups are not
     * treated as normal derivations is with OPT and OBO bodies. If the
     * head item were an OPT or OBO and the body generated in a previous
     * call, it would either generate a phrase, or skip one level as it would
     * be it had been done in a same call. This is so because the generation
     * of the phrase of the body is done always, and in the same way inside
     * a same call or in two different ones. Note, however, that lists
     * which have a final item for a body, have also a final item for the
     * OPT or OBO that contain it, and therefore it never occurs that they
     * are processed in two different calls.
     *
     * Backlinks
     *
     * Backlinks are sewed: when a group is the last repetition of another one,
     * its backlink becomes equal to that of the other.
     * Backlinks setting and sewing need be done explicitly since targets
     * are known only when a phrase is built, but they are needed when
     * building sub-phrases, which is done before.
     * When storing a reference to a sub-phrase which is a group that is
     * not the last element in an enclosing one, a loop is done starting
     * from the referenced phrase and iterating for all groups recursively
     * occurring as last element, setting for each of them the backlink
     * to the same top referencing one (more precisely, to the location
     * past it).
     * Singletons could be groups, in which case there is a need to set
     * backlinks in them. When they are not groups, the new backlink target
     * is defined for inner groups, be either them singletons or otherwise.
     * Since the last in a singleton chain can be a group, backlinks in
     * it and inner groups are set and sewed.
     *
     * Singletons
     *
     * Singletons are expanded by generating their chains of derivations, of
     * the appropriate kinds (i.e. normal or groups) according to the
     * nonterminals which are in the chain. The symbol which is the end of
     * the singleton chain is the one which is present in the item, a token
     * with its associated lexeme pool index, or another item.
     *
     * The derivations for the singletons are placed before the referring
     * derivation(s).
     * Singletons become known when generating the encoding of terms.
     * To place them before the referring phrase, space is allocated in
     * the tree before it. The amount of space for any rule is precomputed.
     * For groups which have a variable number of non-optional bodies it is
     * the space for the chain of a body times the bodies. There is no need
     * to rekon that of the optional bodies because they have no singletons
     * (and the singleton chain for the non-optional body containted in them
     * has beed generated previosuly).
     *
     * Sharing
     *
     * Left sharing is not a problem.
     * Sub sharing can also occur for subtrees which eventually derive
     * empty strings. This can occur with groups bodies also.
     * Sharing of subtrees is possible also with groups (it occurs only
     * with multiple empty bodies) because the backlinks would be the same
     * even with no sharing.
     * When a shared subtree has different singletons reduced to it,
     * the respective chains are generated. This is done also when it is
     * referred to by the same singleton because singleton chains are
     * generated when processing references, which makes each reference
     * a case in its own. However, this occurs seldom, and thus there
     * is no point in making such an extreme optimization.
     *
     * Start
     *
     * Tree building is started with the final item for the head item(s)
     * of the window. Moreover, there is a last call to be made on the
     * enclosing rule since the starting symbol can be a singleton.
     * In such a case, there is no item for it, and therefore encodeTree
     * cannot be called on it. It is instead called on the final item and
     * it does not produce a phrase for it. Only its singletons are generated.
     * Note that the last list is always safe, but having length one, it
     * is not reduced unless an explicit call is made.
     * Since no phrase is generated for the enclosing rule, the removal of
     * one level is done storing the representation of the inner level
     * in the backpointer of the upper one. This allows to get the index
     * of the starting rule in the completed parse tree.
     *
     * Incremental calls
     *
     * It works in an incremental way: it builds a piece of parse tree each
     * time it is called. The final operations on the tree are performed
     * outside it (e.g. the reduction of the tree).
     * The parse tree is allocated in blocks to support this.
     *
     * Performance
     *
     * The percentage of time spent in the building of the parse tree: is
     * 30% of recognizion time.
     *
     * Testing
     *
     * Not to destroy backpointers and subpointers when in testing mode
     * (which serves to print the items lists), the changes are done on
     * copies of them.
     *
     * Groups in basic engine
     *
     * The following applies only to basic engines which do not treat directly
     * groups. When building derivations for repetition groups, since they are
     * made by a chain of applications of the rules of groups, the subpointers
     * should be followed so as to visit all bodies within a single call.
     * This can be done only in one way and not in the opposite direction.
     * Repetition groups have a rule which ends with the nonterminal of the
     * group: it is the rule that allows to have several repetitions.
     * They have also another rule, which is the one that terminates recursion.
     * A derivation of a repetition group has a body (an occurrence of the
     * symbol which represents the body) as long as the nonterminal at the
     * left of the dot is the same as the first one for the group (or is of
     * the same kind): this is the way the top rule of a group gets itself
     * applied recursively. For {}* groups, the end is discovered earlier
     * by noting that the last repetition has nothing at the left of the
     * dot, and thus has sub null.
     * Note that when inside a repetition group, first the left items is
     * visited, and then the sub one, which means that the repetitions are
     * visited from left to right.
     * At each iteration the body at the left is then visited.
     * Lower limited groups: {alpha}(l:) are made by a first part which is
     * that of a repetitive group, bodies linked by the sub pointer, and a
     * second part which is a sequence of bodies, linked by the left pointer.
     * The former are scanned forward and the latter backwards.
     * Note also that the visit of a rule ends when there is no next item
     * at the left to visit. To apply this to repetition groups, the next
     * is not advanced to the sub pointer when the last body is visited.
     * The next at the last body is thus not null (which makes that body
     * processed) and becomes null at the subsequent iteration, causing
     * the loop to terminate.
     * To recognize that a rule is that of a repetition group its structure
     * can be visited to check that it is exactly the peculiar one of a
     * repetition group. This is simple for all groups except for the ranges
     * ones. To make this simple, an array is kept which tells the group
     * kinds of nonterminals: normal, simple group, etc. E.g. &1 is
     * characterised as body, and &2 as optionbody. This allows to handle
     * {...}(l:u) groups easily: when the sym is an optional body its
     * sub is taken if not empty, and when it is a body its sub is taken.
     * There is no need to distinguish all the cases here, but all they are
     * distinguished for generality.
     * There is a need to make a distinction between repetition groups
     * and the others, and also the body of repetition groups because
     * the body must be scanned following the leftpointer, but unlike normal
     * derivations, it has a backlink which is not null, and unlike
     * groups it does not have a repetition.
     * It is possible to distinguish a {}* repeated 0 times from and a {}
     * when building the parse tree by using the kind of nonterminals.
     */

    /**
     * Enlarge the parse tree so that the location prior to the specified one
     * exists.
     *
     * @param      loc current location counter in tree
     */

    void enlargeTree(int loc){
        int newlen = 0;
        if (this.tree != null){
            newlen = this.tree.length;         // length of block directories
        }
        int nextlast = (loc-1) >>> NSHF;       // last block needed
        if (nextlast >= newlen-1){             // enlarge block directories
            if ((nextlast+1 - newlen) < QUANTUM){
                newlen += QUANTUM;
            } else {
                newlen = nextlast + 1;
            }
            // TRACE(M,"enlargeTree: newlen %d%n",newlen);
            if (newlen < 0){
                throw new OutOfMemoryError();
            }
            int[][] n = new int[newlen][];
            if (this.tree != null){
                System.arraycopy(this.tree,0,n,0,this.tree.length);
            }
            this.tree = n;
        }
        // I could keep the max index allocated instead of the max nr of blocks, it makes
        // faster to test if the element at an index is present
        while (this.treeBlocks <= nextlast){   // allocate now the blocks
            // TRACE(M,"enlargeTree: all %d %d%n",
            //    this.treeBlocks,nextlast);
            this.tree[this.treeBlocks++] = new int[QUANTUM];
            if (this.treeBlocks < 0){
                throw new OutOfMemoryError();
            }
        }
    }

    /**
     * Reduce the parse tree if the directory or the last block have
     * an unused space higher than 20% of the total one to the strictly
     * needed size.
     */

    void reduceTree(){
        int bn = (this.loc - 1) >>> NSHF;     // offset of last element
        int off = (this.loc - 1) & MSK;       // its block
        int free = QUANTUM - (++off);
        if (((free * 100) / QUANTUM) > 20){   // last block with space unused
            int[] cur = this.tree[bn];
            int[] p = new int[off];
            System.arraycopy(cur,0,p,0,off);
            this.tree[bn] = p;
        }
        free = QUANTUM - (++bn);
        if (((free * 100) / QUANTUM) > 20){   // resize directory
            int[][] cur = this.tree;
            int[][] p = new int[bn][];
            System.arraycopy(cur,0,p,0,bn);
            this.tree = p;
        }
        this.treeLen = this.loc;
    }


    /**
     * Make copy of the specified subtree at the current location.
     *
     * @param      der index of the subtree
     * @return     index of the root of the copied subtree
     */

    /* The copy is done by seeking the start of the subtree, and then
     * copying the contents from it to the end, traslating the ones
     * that are relocatable.
     */

    /*
    private int copyTree(int der){
        TRACE(S,"copyTree: %d %d%n",der,this.loc);
        int h = this.tree[der>>>NSHF][der&MSK];    // head
        int el = h & ~HEAD;
        int len = 0;
        boolean group = false;
        if (el < this.tab.numOfRules){             // not a repetition group
            len = this.tab.ruleLen[el];            // fixed length
            if (tab.ruleToNt[el] >=
                tab.ntNrGroups){                   // non-repetition group
                group = true;
            }
        } else {                                   // repetition group
            len = el - this.tab.numOfRules;        // decode the length
            group = true;
        }
        int start = len + (group ? 2 : 1);
        int end = der + start;
        while (len > 0){                           // seek start of subtree
            up: {
                for (int i = 0; i < len; i++){
                    der++;
                    der = this.tree[der>>>NSHF][der&MSK];
                    if (der < 0) continue;         // token
                    break up;
                }
                break;
            }
            h = this.tree[der>>>NSHF][der&MSK];    // head
            el = h & ~HEAD;
            len = 0;
            group = false;
            if (el < this.tab.numOfRules){         // not a repetition group
                len = this.tab.ruleLen[el];        // fixed length
                if (tab.ruleToNt[el] >=
                    tab.ntNrGroups){               // non-repetition group
                    group = true;
                }
            } else {                               // repetition group
                len = el - this.tab.numOfRules;    // decode the length
                group = true;
            }
        }
        int delta = this.loc - der;                // length of traslation
        for (int i = der; i < end; i++){           // copy now and traslate
            int val = 0;                           // .. references
            el = this.tree[i>>>NSHF][i&MSK];
            if (((el & HEADF) == HEAD) ||          // head
                (el < 0)){
                val = el;
            } else if (el > der){                  // inside reference
                val = el + delta;
            } else {
                val = el;
            }
            this.loc++;
            if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(this.loc);
            }
            this.tree[(this.loc-1)>>>NSHF][(this.loc-1)&MSK] = val;
        }
        start = this.loc - start;
        TRACE(S,"copyTree end: %d %d%n",start,this.loc);
        return start;
    }
    */

    /* The parse tree API. */

    /* Informational methods. */

    /**
     * Deliver the symbol number for the specified name.
     *
     * @param      kind <code>'t'</code> for a terminal,
     *             <code>'n'</code> for a nonterminal
     * @param      symName name of the terminal or nonterminal
     * @return     symbol number
     * @exception  IllegalArgumentException if the name is not present
     *             in the grammar
     */

    public int symNr(char kind, String symName){
        return this.tab.symNr(kind,symName);
    }

    /**
     * Deliver the symbol number of the specified nonterminal name.
     *
     * @param      symName name of the nonterminal
     * @return     symbol number
     * @exception  IllegalArgumentException if the name is not present
     *             in the grammar
     */

    public int symNr(String symName){
        return this.tab.symNr('n',symName);
    }

    /**
     * Deliver the symbol number of the specified rule.
     *
     * @param      ruleNr rule number
     * @return     symbol number
     * @exception  IllegalArgumentException if the rule number is
     *             not valid
     */

    public int symNr(int ruleNr){
        return this.tab.symNr(ruleNr);
    }

    /**
     * Deliver the symbol number of the specified term in the specified
     * rule.
     *
     * @param      ruleNr number of the rule
     * @param      termNr number of the term
     * @return     symbol number, -1 if group
     * @exception  IllegalArgumentException if there is no such rule
     */

    public int symNr(int ruleNr, int termNr){
        return this.tab.symNr(ruleNr,termNr);
    }

    /**
     * Deliver the rule number of the specified nonterminal name and
     * alternative number.
     *
     * @param      symName nonterminal name
     * @param      altNr alternative number
     * @return     rule number
     * @exception  IndexOutOfBoundsException if the name is not present
     *             in the grammar or if the number of the alternative
     *             exceeds the range of the ones of the nonterminal
     */

    public int ruleNr(String symName, int altNr){
        return this.tab.ruleNr(symName,altNr);
    }

    /**
     * Deliver the rule number of the specified nonterminal number and
     * alternative number.
     *
     * @param      symNr nonterminal number
     * @param      altNr alternative number
     * @return     rule number
     * @exception  IllegalArgumentException if the symbol number is
     *             invalid or if the number of the alternative
     *             exceeds the range of the ones of the nonterminal
     */

    public int ruleNr(int symNr, int altNr){
        return this.tab.ruleNr(symNr,altNr);
    }

    /**
     * Deliver the rule number of the specified term in the specified
     * rule at the specified alternative. If the term is a group, the
     * rule at the specified alternative in the body is delivered.
     *
     * @param      ruleNr number of the rule
     * @param      termNr number of the term
     * @param      altNr number of the alternative
     * @return     rule number, -1 if there is no such term or alternative
     *             or if the term is not a nonterminal or group
     * @exception  IllegalArgumentException if there is no such rule
     */

    public int ruleNr(int ruleNr, int termNr, int altNr){
        return this.tab.ruleNr(ruleNr,termNr,altNr);
    }

    /**
     * Deliver the term number of the specified occurrence of the
     * specified symbol in the specified rule.
     *
     * @param      ruleNr number of the rule
     * @param      symNr number of the symbol
     * @param      symOcc number of the occurrence
     * @return     term number
     * @exception  IllegalArgumentException if there is no such symbol
     *             or occurrence or rule
     */

    public int termNr(int ruleNr, int symNr, int symOcc){
        return this.tab.termNr(ruleNr,symNr,symOcc);
    }

    /**
     * Deliver the symbol name of the specified symbol number.
     *
     * @param      symNr symbol number
     * @return     symbol name
     * @exception  IllegalArgumentException if the symbol number
     *             does not denote a symbol
     */

    public String symName(int symNr){
        return this.tab.symName(symNr);
    }

    /**
     * Deliver the literalised name of the specified symbol number.
     *
     * @param      symNr symbol number
     * @return     literalised name
     * @exception  IllegalArgumentException if the symbol number
     *             does not denote a symbol
     */

    public String symLitName(int symNr){
        return this.tab.symLitName(symNr);
    }

    /* Methods for derivations. */

    /**
     * Check that the specified index falls within the parse tree
     * and throw an exception if it does not.
     *
     * @param      idx index
     * @exception  IllegalArgumentException
     */

    private void checkIndex(int idx){
        if ((0 < idx) && (idx < this.treeLen)){
            return;
        }
        String s = Integer.toString(idx);
        throw new IllegalArgumentException(s);
    }

    /**
     * Check that the specified index denotes the index of a derivation
     * and throw an exception if it does not.
     *
     * @param      der derivation
     * @return     head of the derivation, with HEAD removed
     * @exception  IllegalArgumentException
     */

    protected int checkDer(int der){
        if ((0 < der) && (der < this.treeLen)){
            int h = this.tree[der>>>NSHF][der&MSK];  // rule number or length
            if ((h & HEADF) == HEAD){                // a derivation
                return h & ~HEAD;
            }
        }
        String s = Integer.toString(der);
        throw new IllegalArgumentException(s);
    }

    /**
     * Check that the specified term in the specified derivation
     * falls within the derivation, and throw an exception if it does not.
     *
     * @param      der derivation
     * @param      termNr term number
     * @return     length
     * @exception  IllegalArgumentException
     */

    private int checkIndex(int der, int termNr){
        doit: if ((0 < der) && (der < this.treeLen)){
            int h = this.tree[der>>>NSHF][der&MSK];  // rule number or length
            if ((h & HEADF) != HEAD) break doit;     // not a derivation
            h &= ~HEAD;
            if (h < this.tab.numOfRules){            // not a repetition group
                h = this.tab.ruleLen[h];             // fixed length
            } else {                                 // repetition group
                h -= this.tab.numOfRules;            // decode the length
            }
            if ((0 <= termNr) && (termNr < h)){
                return h;
            }
            der = termNr;                            // report error on termNr
        }
        String s = Integer.toString(der);
        throw new IllegalArgumentException(s);
    }

    /**
     * Throw an exception for an invalid argument.
     *
     * @param      arg argument
     * @exception  IllegalArgumentException
     */

    private void errArg(int arg){
        String s = Integer.toString(arg);
        throw new IllegalArgumentException(s);
    }

    /**
     * Deliver the index of the derivation of the starting symbol.
     *
     * @return     index of the derivation, 0 if there is none
     */

    public int getStart(){
        if (this.treeLen <= 1) return 0;  // no tree
        return this.treeStart;
    }

    /**
     * Trace the parse tree.
     */

    void traceTree(){
        traceTree(Trc.wrt,1);
    }

    /**
     * Trace the parse tree.
     *
     * @param      trc trace stream
     * @param      mode 0: plain text formatting, 1: plain text with
     *             numeric references
     */

    /* A parse can be traced in numeric form, in which case references
     * to derivations are represented numerically, or in symbolic form,
     * in which case they are represented as symbol names and presence
     * indexes (reference numbers, numbering references of a same nonterminal
     * from 0 onwards, and groups all together by themselves).
     * Presence indexes number derivations of a same symbol sequentially so
     * as to distinguish them. To compute presence indexes, a map is used,
     * which in the first part contains the counters for each nonterminal
     * (the last being reserved for all groups), and in the second part contains
     * the presence index of the nonterminal at the corresponding (displaced)
     * position in the parse tree, i.e. the first part serves to get new
     * presence numbers for each nonterminal, and the second to map defining
     * occurrences with presence numbers (so as to get them when tracing
     * applied occurrences).
     * It could be possible to use an hash table instead. However, tracing
     * parse trees does not occur so often as to require this optimization.
     * This method is not good to produce an html trace since there we have no problems
     * in linking derivations occurrences with their definition. Also, it is not
     * good for use in Parser since it does not order the tree.
     */

    void traceTree(PrintWriter trc, int mode){
        ParserTables tab = this.tab;
        if (this.treeLen <= 1) return;      // no tree
        int len = this.treeLen;
        int der = 1;
        int[] ntCounts = null;
        if (mode >= 1){
            ntCounts = new int[this.tab.numOfSyms+1+len];
            ntCounts[getSymNr(this.treeStart)]++;
        }
        for (int i = der; i < len;){        // scan the tree
            int t = getLength(i);           // length of phrase of derivation
            traceDer(i,trc,mode,ntCounts);  // trace it
            if (isGroup(i)) i++;
            i += t + 1;                     // step to next derivation
        }
    }

    /**
     * Trace a portion of the parse tree.
     *
     * @param      len length of the significant part of it
     */

    protected void traceTree(int len){
        Trc.out.println("encoded tree: " + len);
        for (int i = 0; i < len; i++){
            int el = this.tree[i>>>NSHF][i&MSK];
            Trc.out.print(i + ": " + el);
            if ((el & HEADF) == HEAD){
                el &= ~HEAD;
                Trc.out.print(" " + el + " " + getLength(i) +
                    " " + isGroup(i) + " " + isRepGroup(i));
                if (!isRepGroup(i)){
                    Trc.out.print(" " + tab.ntLitName(tab.ruleToNt[el]));
                }
            } else if (el < 0){
                int ln;
                Str st = new Str();              // trace lexeme
                String str;
                ln = getLexNr(el);
                str = getLexeme(ln);
                Str.strLit(str.toCharArray(),0,
                    str.length(),st);
                Trc.out.print(" " + st);
            }
            Trc.out.println();
        }
    }


    /**
     * Trace the derivation der.
     *
     * @param      der derivation
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public void traceDer(int der){
        traceDer(der,Trc.wrt,0,null);
    }

    /**
     * Trace the specified derivation.
     *
     * @param      der derivation
     * @param      trc trace stream
     * @param      mode 0: plain text formatting, 1: plain text with
     *             numeric references
     * @param      ntCounts map from derivation indexes to nonterminal
     *             presence numbers
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    protected void traceDer(int der, PrintWriter trc, int mode,
        int[] ntCounts){
        checkDer(der);                          // check index
        ParserTables tab = this.tab;
        if (mode == 0){
            trc.print(der + ": " +              // derivation number and name
                getLitName(der) + " ::=");      // .. of nonterminal
        } else {
            int ref = tab.numOfSyms;            // use last for all groups
            if (isRepGroup(der)){
                trc.print("{}*");
            } else if (isGroup(der)){
                trc.print("{}");
            } else if (mode == 1){
                trc.print(getLitName(der));
                ref = getSymNr(der);
            }
            ntCounts[tab.numOfSyms+1+der] = ntCounts[ref]++;
            trc.print(ntCounts[tab.numOfSyms+1+der]);
            trc.print(" ::=");
        }
        int t = getLength(der);                 // length of phrase of derivation
        Str st = new Str();
        for (int i = der+1; i < der+1+t; i++){  // scan the derivation
            trc.print(" ");
            int s = this.tree[i>>>NSHF][i&MSK]; // take symbol
            if (s < 0){                         // token
                int ln;
                String str;
                ln = getLexNr(s);
                st.length = 0;                  // trace lexeme
                str = getLexeme(ln);
                Str.strLit(str.toCharArray(),0,
                    str.length(),st);
                if (mode <= 1){
                    trc.print(st.toString());
                }
            } else {                            // another derivation
                if (mode == 0){
                    trc.print("\u00ab" + s +    // its derivation index
                        "\u00bb");
                } else {
                    if (isGroup(s)){
                        if (isRepGroup(s)){
                            trc.print("{}*");
                        } else {
                            trc.print("{}");
                        }
                    } else {
                        trc.print(getLitName(s));
                    }
                    trc.print(ntCounts[tab.numOfSyms+1+s]);
                }
            }
        }
        if (isGroup(der)){
            int ba = der+1+t;
            ba = this.tree[ba>>>NSHF][ba&MSK];   // backlink
            if (ba != 0){                        // present
                if (mode == 0){
                    trc.print(" \u00ab^" + ba + "\u00bb");
                }
            }
        }
        trc.println();
    }

    /**
     * Deliver the literalized name of the nonterminal of the specified
     * derivation.
     *
     * @param      der derivation
     * @return     string of the name
     * @exception  IllegalArgumentException if the index is invalid
     */

    String getLitName(int der){
        int h = checkDer(der);                // check index
        String name;
        ParserTables tab = this.tab;
        if (h >= tab.numOfRules){             // repetition group
            return "\u00ab&*\u00bb";
        } else {
            int ntNr = tab.ruleToNt[h];       // number of nonterminal of rule
            return tab.ntLitName(ntNr);
        }
    }

    /**
     * Deliver the length of the phrase of the specified derivation.
     * Note that if the derivation is that of a repetition group, the
     * length is the number of repetitions.
     *
     * @param      der derivation
     * @return     length
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public int getLength(int der){
        int h = checkDer(der);                 // check index
        if (h < this.tab.numOfRules){          // not a repetition group
            h = this.tab.ruleLen[h];           // fixed length
        } else {                               // repetition group
            h -= this.tab.numOfRules;          // decode the length
        }
        return h;
    }

    /**
     * Deliver the size of the specified derivation. It is the number
     * of tokens generated by the derivation and by the ones of the
     * occurrences of nonterminals in it.
     *
     * @param      der derivation
     * @return     size
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    /* This method cannot be implemented by using recursion since the
     * VM stack can overflow. It is also difficult to implement is with
     * a marking algorithm. The marks could be put in the head of phrases.
     * However, it is difficult to scan the tree backwards since all elements
     * must be visited to spot the beginning of phrases in order to know if
     * they belong to the subtree or not. But if marks are put in the MSB of
     * heads, then they become indistinguisheable from tokens, thus making the
     * visit impossible (unless another bit is used to mark heads, restricting
     * their range). It is instead implemented with a stack that is a circular,
     * extensible buffer which contains references to the subphrases to be
     * visited.
     * This method should not be used vary frequently, and thus a allocating
     * a stack at each call is not a problem.
     */

    public int getSize(int der){
        checkDer(der);                         // check index
        int n = 0;
        int sp = 0;
        int[] stack = null;
        int stackLen = 0;
        doit: do {
            int end = der + 1 + getLength(der);    // scan the derivation
            for (int i = der+1; i < end; i++){
                int ele = this.tree[i>>>NSHF][i&MSK];
                if (ele < 0){                      // token
                    n++;
                } else {                           // another derivation
                    if (sp >= stackLen){
                        int newlen = stackLen + 10;
                        if (newlen < 0){
                            throw new OutOfMemoryError();
                        }
                        int[] s = new int[newlen];
                        if (stackLen > 0){
                            System.arraycopy(stack,0,s,0,stackLen);
                        }
                        stack = s;
                        stackLen = newlen;
                    }
                    stack[sp++] = ele;
                }
            }
            if (sp == 0) break;
            der = stack[--sp];
        } while (true);
        return n;
    }

    /**
     * Test if the specified derivation is that of a group.
     *
     * @param      der derivation
     * @return     <code>true</code> if it is a group
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public boolean isGroup(int der){
        int h = checkDer(der);                    // check index
        ParserTables tab = this.tab;
        return (h >= tab.numOfRules) ||           // repetition group
            (tab.ruleToNt[h] >= tab.ntNrGroups);  // non-repetition group
    }

    /**
     * Test if the specified derivation is that of a repetition group.
     *
     * @param      der derivation
     * @return     <code>true</code> if it is a repetition group
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public boolean isRepGroup(int der){
        int h = checkDer(der);                    // check index
        return h >= this.tab.numOfRules;
    }

    /**
     * Test if the specified derivation is that of an alternative tree (symbol node).
     *
     * @param      der derivation
     * @return     <code>true</code> if it is
     */

    public boolean isAlt(int der){
        return (this.tree[(der)>>>NSHF][((der)&MSK)] & HEADF) == HEADSYM;         // symbol node
    }

    /**
     * Deliver an array of the indexes alternative trees.
     *
     * @param      der derivation
     * @return     array
     */

    public int[] getAlts(int der){
        int len = this.tree[(der)>>>NSHF][((der)&MSK)] & ~HEADF;
        int[] res = new int[len];
        for (int i = 0; i < len; i++){
            res[i] = this.tree[(der+i+1)>>>NSHF][((der+i+1)&MSK)];
        }
        return res;
    }

    /**
     * Deliver the number of the rule of the specified derivation.
     *
     * @param      der derivation
     * @return     rule number, -1 if it is a repetition group
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public int getRuleNr(int der){
        int h = checkDer(der);                // check index
        if (h < this.tab.numOfRules){         // rule
            return h;
        }
        return -1;                            // repetition group
    }

    /**
     * Deliver the alternative number of rule of the specified derivation.
     * It is the sequence number of the rule among the alternatives for
     * the nonterminal, numbered from zero onwards.
     *
     * @param      der derivation
     * @return     alternative number, 0 if it is a repetition group
     * @exception  IllegalArgumentException if the derivation is invalid
     */

    public int getAltNr(int der){
        int h = checkDer(der);                // check index
        if (h >= this.tab.numOfRules){        // repetition group
            return 0;
        }
        ParserTables tab = this.tab;
        int ntNr = tab.ruleToNt[h];           // number of nonterminal
        int ntrule = tab.ntToRule[ntNr];      // number of its first rule
        return h - ntrule;
    }

    /* Methods on elements and derivations. */

    /**
     * Deliver the symbol number of the specified element.
     *
     * @param      ele element
     * @return     symbol number, -1 if it is a group
     * @exception  IllegalArgumentException if the element is invalid
     */

    public int getSymNr(int ele){
        ParserTables tab = this.tab;
        if (ele < 0){                              // token
            int tn;
            tn = getTokNr(ele);
            return tn;                             // return it
        } else {
            int h = checkDer(ele);                 // check index
            if ((h >= this.tab.numOfRules) ||      // repetition group
                (tab.ruleToNt[h] >= tab.ntNrGroups)){ // non-repetition group
                return -1;
            }
            int nrNt = tab.ruleToNt[h];            // number of nonterminal
            return nrNt + tab.numOfToks;           // return symbol number
        }
    }

    /**
     * Deliver the token number of the specified token element.
     *
     * @param      e element
     * @return     token number
     */

    int getTokNr(int e){
        e &= ~TOK_ELEM;
        if ((e & (TOK_LEXNR | TOK_POINT)) == 0){  // inline
            if (--e == 0) return 0;
            return e % this.tab.numOfToks;
        }
        int p = e & ~(TOK_LEXNR | TOK_POINT);
        int bn = p >>> NSHF;
        int off = p & MSK;
        return this.tokListDir[bn][off];
    }

    /**
     * Deliver the symbol name of the specified element.
     *
     * @param      ele element
     * @return     symbol name, or the empty string if the element is a group
     */

    public String getSymName(int ele){
        int symNr = getSymNr(ele);           // symbol number
        if (symNr == -1){                    // group
            return "";
        }
        return tab.symName(symNr);           // return name
    }

    /**
     * Deliver the literalised symbol name the specified element.
     *
     * @param      ele element
     * @return     literalised symbol name, or the empty string if
     *             the element is a group
     */

    public String getSymLitName(int ele){
        int symNr = getSymNr(ele);           // symbol number
        if (symNr == -1){                    // group
            return "";
        }
        return this.tab.symLitName(symNr);   // return literalised name
    }

    /**
     * Test if the specified element is a derivation or a token.
     *
     * @param      ele element
     * @return     <code>true</code> if it is a derivation
     * @exception  IllegalArgumentException if the element is invalid
     */

    public boolean isDer(int ele){
        if (ele < 0) return false;       // token
        checkDer(ele);                   // check index
        return true;
    }

    /* Methods to get indexes of elements. */

    /**
     * Deliver the index of the element in the specified derivation
     * which corresponds to the specified term in the rule.
     * If the term number denotes the element past the last one,
     * it returns 0 (which is the same value returned by <code>getNext()</code>
     * as last value).
     *
     * @param      der derivation
     * @param      termNr term number
     * @return     index
     * @exception  IllegalArgumentException if the index or symbol
     *             numbers denote an element which is not in the derivation
     */

    public int getIndex(int der, int termNr){
        doit: if ((0 < der) && (der < this.treeLen)){
            int h = this.tree[der>>>NSHF][der&MSK];  // rule number or length
            if ((h & HEADF) != HEAD) break doit;     // not a derivation
            h &= ~HEAD;
            if (h < this.tab.numOfRules){            // not a repetition group
                ParserTables tab = this.tab;
                h = tab.ruleLen[h];                  // fixed length
            } else {                                 // repetition group
                h -= this.tab.numOfRules;            // decode the length
            }
            if ((0 <= termNr) && (termNr <= h)){     // end allowed
                if (termNr == h){                    // end index
                    return 0;
                }
                termNr += der + 1;                   // index of the element
                if (termNr >= this.treeLen) termNr = 0;
                return termNr;
            }
            der = termNr;                            // report error on termNr
        }
        String s = Integer.toString(der);
        throw new IllegalArgumentException(s);
    }

    /**
     * Deliver the index of the element in the specified derivation
     * which corresponds to the first occurrence of the specified nonterminal.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      symName name of the nontemianal symbol
     * @return     index
     * @exception  IllegalArgumentException if the index is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol
     */

    public int getIndex(int der, String symName){
        return getIndex(der,'n',symName,0);
    }

    /**
     * Deliver the index of the element in the specified derivation
     * which corresponds to the n-th occurrence of the specified nonterminal.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      symName name of the nontemianal symbol
     * @param      symOcc number of the occurrence
     * @return     index
     * @exception  IllegalArgumentException if the index is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol
     */

    public int getIndex(int der, String symName, int symOcc){
        return getIndex(der,'n',symName,symOcc);
    }

    /**
     * Deliver the index of the element in the specified derivation
     * which corresponds to the n-th occurrence of the specified symbol.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      kind <code>'t'</code> for a terminal,
     *             <code>'n'</code> for a nonterminal
     * @param      symName name of the symbol
     * @param      symOcc number of the occurrence
     * @return     index
     * @exception  IllegalArgumentException if the index is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol or occurrence
     */

    public int getIndex(int der, char kind, String symName, int symOcc){
        int h = checkDer(der);                       // check index
        if (h >= this.tab.numOfRules){               // repetition group
            errArg(der);
        }
        if ((kind != 't') && (kind != 'n')){
            throw new IllegalArgumentException(
                String.valueOf(kind));               // illegal kind
        }
        if (symOcc < 0) errArg(symOcc);
        ParserTables tab = this.tab;
        int res = 0;
        int occ = symOcc;
        int end = der + 1 + getLength(der);
        for (int i = der+1; i < end; i++){           // scan the derivation
            int n = this.tree[i>>>NSHF][i&MSK];
            if (n < 0){                              // token
                int tn;
                tn = getTokNr(n);
                tn = tab.tokOrder[tn];               // number in name table
                if ((kind == 't') !=
                    (tn < tab.terNum)) continue;
                if (tab.tokStrings[tn].equals(symName)){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            } else {                                 // derivation
                if (kind != 'n') continue;
                n = this.tree[n>>>NSHF][n&MSK] & ~HEAD;
                if (n >= this.tab.numOfRules){       // repetition group
                    continue;
                }
                n = tab.ruleToNt[n];                 // number of nonterminal
                if (tab.ntStrings[n].equals(symName)){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            }
        }
        if (res > 0) return res;                     // found
        if (occ < symOcc) errArg(symOcc);            // symOcc too large
        throw new IllegalArgumentException(symName); // not found
    }

    /**
     * Deliver the index of the element in the specified derivation
     * which corresponds to the n-th occurrence of the specified symbol.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      symNr number of the symbol
     * @param      symOcc number of the occurrence
     * @return     index
     * @exception  IllegalArgumentException if the index is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol or occurrence
     */

    public int getIndex(int der, int symNr, int symOcc){
        int h = checkDer(der);                       // check index
        if (h >= this.tab.numOfRules){               // repetition group
            errArg(der);
        }
        if (symOcc < 0) errArg(symOcc);
        ParserTables tab = this.tab;
        int occ = symOcc;
        int end = der + 1 + getLength(der);
        int res = 0;
        for (int i = der+1; i < end; i++){           // scan the derivation
            int n = this.tree[i>>>NSHF][i&MSK];
            if (n < 0){                              // token
                int tn;
                tn = getTokNr(n);
                if (tn == symNr){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            } else {                                 // derivation
                n = this.tree[n>>>NSHF][n&MSK] & ~HEAD;
                if (n >= this.tab.numOfRules){       // repetition group
                    continue;
                }
                n = tab.ruleToNt[n] + tab.numOfToks; // symbol number
                if (n == symNr){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            }
        }
        if (res > 0) return res;                     // found
        if (occ < symOcc) errArg(symOcc);            // symOcc too large
        throw new IllegalArgumentException(
            Integer.toString(symNr));                // not found
    }

    /**
     * Deliver the index of the element which is next to the specified one.
     * Groups are entered.
     *
     * @param      idx index of the element
     * @return     index, 0 if no next available
     * @exception  IllegalArgumentException if the index is invalid
     */

    /* Since backlinks are sewed, unnesting is always done in one step.
     * Nesting, however, can require several steps. Since a group can be
     * immediately followed by another group, after unnesting there is a
     * need to test the presence of another group and when one is present,
     * to enter it.
     */

    public int getNext(int idx){
        checkIndex(idx);                        // check index
        idx++;                                  // advance index
        if (idx == this.treeLen){               // end
            return 0;
        } 
        int ele = this.tree[idx>>>NSHF][idx&MSK];  // get element
        do {
            if (ele > 0){                       // derivation or backlink
                if ((ele & HEADF) == HEAD){     // end of non-group derivation
                    ele = 0;
                    break;
                }
                if (ele > idx){                 // backlink
                    idx = ele;
                    if (idx == this.treeLen){   // end
                        ele = 0;
                        break;
                    } 
                    ele = this.tree[idx>>>NSHF][idx&MSK];
                    continue;
                }
                ParserTables tab = this.tab;
                int h = this.tree[ele>>>NSHF]   // derivation
                    [ele&MSK] & ~HEAD;
                if ((h >= tab.numOfRules) ||    // repetition group
                    (tab.ruleToNt[h] >=         // non-repetition group
                    tab.ntNrGroups)){
                    idx = ele;
                    idx++;
                    ele = this.tree[idx>>>NSHF] // get first in group
                        [idx&MSK];
                    continue;
                }
            }
            ele = idx;
            break;
        } while (true);
        return ele;
    }

    /* Methods to get elements. */

    /**
     * Deliver the element at the specified index in the parse tree.
     *
     * @param      idx index
     * @return     element
     * @exception  IllegalArgumentException if the index is invalid
     */

    public int getElement(int idx){
        checkIndex(idx);                        // check index
        return this.tree[idx>>>NSHF][idx&MSK];
    }

    /**
     * Deliver the element in the specified derivation which corresponds
     * to the specified term in the rule.
     *
     * @param      der derivation
     * @param      termNr term number
     * @return     element
     * @exception  IllegalArgumentException if the derivation or term
     *             numbers denote an element which is not in the derivation
     */

    public int getElement(int der, int termNr){
        checkIndex(der,termNr);           // check index
        termNr += der + 1;                // index of the element
        return this.tree[termNr>>>NSHF][termNr&MSK];
    }

    /**
     * Deliver the element in the specified derivation which corresponds
     * to the first occurrence of the specified nonterminal.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      symName name of the nonterminal symbol
     * @return     element
     * @exception  IllegalArgumentException if the derivation is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol
     */

    public int getElement(int der, String symName){
        int idx = getIndex(der,'n',symName,0);
        return this.tree[idx>>>NSHF][idx&MSK];
    }

    /**
     * Deliver the element in the specified derivation which corresponds
     * to the n-th occurrence of the specified nonterminal.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      symName name of the nontemianal symbol
     * @param      symOcc number of the occurrence
     * @return     element
     * @exception  IllegalArgumentException if the derivation is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol or occurrence
     */

    public int getElement(int der, String symName, int symOcc){
        int idx = getIndex(der,'n',symName,symOcc);
        return this.tree[idx>>>NSHF][idx&MSK];
    }

    /**
     * Deliver the element in the specified derivation which corresponds
     * to the n-th occurrence of the specified symbol.
     * Groups are not entered.
     *
     * @param      der derivation
     * @param      kind <code>'t'</code> for a terminal,
     *             <code>'n'</code> for a nonterminal
     * @param      symName name of the symbol
     * @param      symOcc number of the occurrence
     * @return     element
     * @exception  IllegalArgumentException if the derivation is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol or occurrence or the kind is
     *             invalid
     */

    public int getElement(int der, char kind, String symName, int symOcc){
        int idx = getIndex(der,kind,symName,symOcc);
        return this.tree[idx>>>NSHF][idx&MSK];
    }

    /**
     * Deliver the element in the specified derivation which corresponds
     * to the n-th occurrence of the specified symbol. Groups are not entered.
     *
     * @param      der derivation
     * @param      symNr symbol number
     * @param      symOcc number of the occurrence
     * @return     element
     * @exception  IllegalArgumentException if the derivation is invalid,
     *             or if the derivation is a repetition group, or
     *             if there is no such symbol or occurrence
     */

    public int getElement(int der, int symNr, int symOcc){
        int idx = getIndex(der,symNr,symOcc);
        return this.tree[idx>>>NSHF][idx&MSK];
    }

    /**
     * Deliver the string of the element in the specified derivation
     * which corresponds to the specified term in the rule.
     * For a token, it is the lexeme, and for a derivation it is the lexemes
     * recursively derived by it, separated by spaces.
     *
     * @param      der derivation
     * @param      termNr term number
     * @return     string
     * @exception  IllegalArgumentException if the derivation or term
     *             numbers denote an element which is not in the derivation
     */

    public String toString(int der, int termNr){
        checkIndex(der,termNr);           // check index
        termNr += der + 1;                // index of the element
        return toString(this.tree[termNr>>>NSHF][termNr&MSK]);
    }

    /**
     * Deliver the string of the specified element.
     * For a token, it is the lexeme, and for a derivation it is the lexemes
     * recursively derived by it, separated by spaces.
     *
     * @param      ele element
     * @return     string
     * @exception  IllegalArgumentException if the element is invalid
     */

    public String toString(int ele){
        Str s = new Str();
        toString(ele,s);             // build string
        return s.toString();
    }

    /**
     * Deliver the string of the specified element appended to the specified
     * string. For a token, it is the lexeme, and for a derivation it is the
     * lexemes recursively derived by it, separated by spaces.
     *
     * @param      ele element
     * @param      st string
     * @exception  IllegalArgumentException if the element is invalid
     */

    public void toString(int ele, Str st){
        toString(ele,st,1);
    }

    /**
     * Deliver the string of the specified element appended to the specified
     * string or into the specified stream. For a token, it is the lexeme,
     * and for a derivation it is the lexemes recursively derived by it.
     *
     * @param      ele element
     * @param      st string or stream
     * @param      mode 0: do not insert spaces, 1: separate tokens with
     *             spaces, 2: generate a parenthetised string
     * @exception  IllegalArgumentException if the element is invalid
     */

    public void toString(int ele, Object st, int mode){
        this.mode &= ~PLACED;
        if (st instanceof Str){
            toString(ele,(Str)st,null,mode);
        } else {
            toString(ele,null,(PrintWriter)st,mode);
        }
        this.mode &= ~PLACED;
    }

    /**
     * Write the string of the specified element into the specified
     * string or stream.
     *
     * @param      ele element
     * @param      st string
     * @param      wr stream
     * @param      mode 0: do not insert spaces, 1: separate tokens with
     *             spaces, 2: generate a parenthetised string
     * @exception  IllegalArgumentException if the element is invalid
     */

    /* It cannot be implemented by using recursion since the VM stack can
     * overflow. It is implemented with a stack that contains a reference
     * to the subphrases which have not yet been completed. This allows
     * to visit a phrase, then its subphrases, and then again the phrase.
     */

    private void toString(int ele, Str st, PrintWriter wr, int mode){
        ParserTables tab = this.tab;
        if (ele < 0){                           // token
            if (((this.mode & PLACED) != 0) &&
                ((mode & 3) != 0)){
                char ch = ' ';
                if (st != null) st.append(ch);
                else wr.print(ch);
            }
            String s;
            s = getLexeme(getLexNr(ele));
            if (st != null) st.append(s);
            else wr.print(s);
            this.mode |= PLACED;
        } else {                                // another derivation
            int sp = 0;
            int[] stack = new int[20];          // create stack
            int stackLen = stack.length;
            stack[sp++] = ele;                  // insert first phrase
            stack[sp++] = 0;                    // nr of its elements processed
            do {
                int state = stack[sp-1];
                ele = stack[sp-2];
                if (state == 0){                // initiate phrase
                    if ((mode & 2) != 0){       // parenthetised form
                        if (((this.mode & PLACED) != 0) &&
                            ((mode & 3) != 0)){
                            char ch = ' ';
                            if (st != null) st.append(ch);
                            else wr.print(ch);
                        }
                        if (isGroup(ele)){
                            char ch = '{';
                            if (st != null) st.append(ch);
                            else wr.print(ch);
                        } else {
                            String s = getSymLitName(ele);
                            char ch = '[';
                            if (st != null){
                                st.append(s);
                                st.append(ch);
                            } else {
                                wr.print(s);
                                wr.print(ch);
                            }
                        }
                        this.mode &= ~PLACED;
                    }
                    state = ele + 1;
                }
                int end = ele + 1 + getLength(ele);  // end index in phrase
                if (state < end){                    // elements to process
                    stack[sp-1] = state + 1;
                    int val = this.tree[state>>>NSHF][state&MSK];
                    if (val < 0){                    // token
                        toString(val,st,wr,mode);
                    } else {                         // another phrase
                        if (sp >= stackLen){
                            int newlen = stackLen + 10;
                            if (newlen < 0){
                                throw new OutOfMemoryError();
                            }
                            int[] s = new int[newlen];
                            if (stackLen > 0){
                                System.arraycopy(stack,0,s,0,stackLen);
                            }
                            stack = s;
                            stackLen = newlen;
                        }
                        stack[sp++] = val;           // stack it
                        stack[sp++] = 0;
                    }
                    continue;
                }
                if ((mode & 2) != 0){                // end phrase
                    char clo = ']';                  // .. parenthetised form
                    if (isGroup(ele)){
                        clo = '}';
                    }
                    if (st != null) st.append(clo);
                    else wr.print(clo);
                    this.mode |= PLACED;
                }
                sp -= 2;                             // remove from stack
            } while (sp > 0);
        }
    }

    // this must then be fit into the conventions of the others
    String derToString(int der){
        return "";
    }
    String derToString(int der, int mode, int[] ntCounts){
        return "";
    }

    /** Whether a string which requires a space has been written. */
    private static final int PLACED = 1 << 8;

    /**
     * Deliver the lexeme number of the lexeme associated to the
     * specified element.
     *
     * @param      ele element
     * @return     lexNr
     * @exception  IllegalArgumentException if the element is invalid
     */

    public int getLexNr(int ele){
        if (ele >= 0){                  // not token
            errArg(ele);
        }
        ParserTables tab = this.tab;
        int e = ele;
        e &= ~TOK_ELEM;
        if ((e & (TOK_LEXNR | TOK_POINT)) == 0){  // inline
            if (--e == 0) return 0;
            int ln = e / tab.numOfToks;
            if (ln == 0) ln = e;                  // no lexNr, use tokNr
            else ln += tab.numOfToks;
            //TRACE(S,"getLexNr: %d%n",ln);
            return ln;
        }
        int p = e & ~(TOK_LEXNR | TOK_POINT);
        int bn = p >>> NSHF;
        int off = p & MSK;
        char[] blk = this.tokListDir[bn];
        if ((e & TOK_LEXNR) == 0){                // in-pool, no lexNr
            //TRACE(S,"getLexNr no pool: %d%n",
            //    (int)blk[off]);
            return blk[off];
        }
        off++;
        e = blk[off++];                           // lexNr
        if (e >= 0x8000){
            e &= ~0x8000;
            e |= blk[off++] << 15;
        }
        e += tab.numOfToks;
        //TRACE(S,"getLexNr: %d%n",e);
        return e;
    }

    /**
     * Deliver the point of the specified token element.
     *
     * @param      ele element
     * @return     point, -1 if not present
     */

    public long getPoint(int ele){
        if (ele >= 0){                            // not a token
            errArg(ele);
        }
        int e = ele;
        e &= ~TOK_ELEM;
        if ((e & TOK_POINT) == 0){                // inline, or in-pool no point
            return -1;
        }
        int p = e & ~(TOK_LEXNR | TOK_POINT);
        int bn = p >>> NSHF;
        int off = p & MSK;
        char[] blk = this.tokListDir[bn];
        off++;                                    // tokNr
        if ((e & TOK_LEXNR) != 0){                // in-pool, lexNr
            e = blk[off++];                       // lexNr
            if (e >= 0x8000) off++;
        }
        long pt = blk[off++];                     // rebuild it
        if (pt >= (1L << 15)){
            pt &= ~(1L << 15);
            pt |= (long)blk[off++] << 15;
            if (pt >= (1L << 30)){
                pt &= ~(1L << 30);
                pt |= (long)blk[off++] << 30;
                if (pt >= (1L << 45)){
                    pt &= ~(1L << 45);
                    pt |= (long)blk[off++] << 45;
                }
            }
        }
        return pt;
    }

    /**
     * Deliver the String of the lexeme in the lexemes pool at the
     * specified lexeme index
     *
     * @param      lexNr lexeme index
     * @return     string
     */

    public String getLexeme(int lexNr){
        if (lexNr >= this.tab.numOfToks){
            return this.pool.toString(lexNr-this.tab.numOfToks);
        } else {
            return this.tab.tokStrings[this.tab.tokOrder[lexNr]];
        }
    }

    /**
     * Print the statistics of the parsing.
     *
     * @param      trc trace stream
     */

    void statistics(PrintWriter trc){
    }

    /**
     * Deliver the size of the parse tree.
     *
     * @return     size in bytes
     */

    long treeSize(){
        long size = 0;
        if (this.tree != null){
            size = 4 + this.tree.length * 4;
            if (this.tree.length > 1){
                size += (this.treeBlocks - 1) * (QUANTUM * 4 + 4);
            }
            size += this.tree[this.treeBlocks - 1].length * 4 + 4;
        }
        return size;
    }

    /**
     * Deliver the size of the tokens list.
     *
     * @return     size in bytes
     */

    long tokListSize(){
        long size = 0;
        if (this.tokListDir != null){
            size = 4 + this.tokListDir.length * 4;
            if (this.nextBlock > 1){
                size += (this.nextBlock - 1) * (QUANTUM * 2 + 4);
            }
            size += this.tokListDir[this.nextBlock - 1].length * 2 + 4;
        }
        return size;
    }

    /**
     * Deliver the size of the final data generated.
     *
     * @return     size in bytes
     */

    public long size(){
        long size = treeSize();          // tree
        if (this.pool != null){
            size += this.pool.size();    // lexemes strings
        }
        size += tokListSize();           // tokens list
        return size;
    }

    /**
     * Deliver the size of the dynamic memory used.
     *
     * @return     size in bytes
     */

    public long heapSize(){
        return this.heap;
    }

    /** The amount of dynamic memory used, in bytes. */
    long heap;

    /**
     * Deliver the size of the static memory used.
     *
     * @return     size in bytes
     */

    public long tabSize(){
        return this.tab.prsSize;
    }

    /**
     * Deliver the size of the stack used.
     *
     * @return     size in bytes
     */

    int stackLength(){
        return 0;
    }
}