/*
 * @(#)ParserRnglrEbnf.jpp       1.0 2020/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLRTables.*;
import lbj.ParserGLRengine;
//import lbj.Graph.*;

/**
 * The <code>ParserRnglrEbnf</code> class provides the RNGLR for EBNF flat parsing algorithm.
 *
 * @author  Angelo Borsotti
 * @version 1.0   14 Apr 2020
 */



/*
This is the flat version of RNGLR for EBNF.

- rnglrParser.js contains the unoptimized version of this parser.
- the one here is an optimized one
- one rule only for each nontermnal (to comply to the paper)

- it uses a standard scheme for generalized parsers: it keeps an ordered set of parses
  (aka GSS nodes, or items) for each input symbol (which resembles the "u" set of Scott).
  It scans its elements making either terminal shifts, that add elements to the set of
  the next symbol, or reductions that add elements to the current set as nonterminal
  shifts (besides fragments of the forest).
  When the added elements are already present and processed, they are enqueued in a
  reduction worklist for further processing, that is visited together with the current
  set, until both are visited completely.
  Note that this is done in a single pass over the current set and the reduction worklist
  because of the use of right-nulled (rn) reductions (which relieve from making several
  passes until no more elements are added).
  The reduction worklist resembles the "r" set of Scott. However, "r" keeps all the reductions
  to do, while here the rwl keeps only the ones to be done because were left over (actually
  it keeps the edges to reprocess).
  Consequently, the reducer and the shifter do not need to detect what reductions to do
  next.

- a gss node contains a state and the head of its list of edges,
  a gss edge contains the index of the next edge, the index of the tonode and that of the sppf

- weakness of the flat derivations: see tg32.138. The parser at each step does not
  know that the list of values is ended and then builds one collecting all the values
  encountered so far, which means n^2/2 in total, values that are trown away, except for
  the last one. This does not plague rnglr because it builds forests as garlands, and
  although they are trown away as well, they are made of 2 elements each, so the parsing
  time is linear instead of quadratic.


Convergence conflicts

  - the convergence conflicts are conflicts due to the fact that in machines (be them DFAs
    or NFAs) there are edges that converge in a same state, which does not happen with items
    for BNF rules. When this happens and the lookaheads of both edges have a non-null
    intersection, then there is a convergence conflict, which is a problem when the end state
    of such edges is final because we do not know which reduction to make, which instead we
    could tell looking to the lookaheads
  - addelritem in elr1+ refuses to add an item when there is a convercence conflict because this
    would produce infinite states besides producing a DFA that is useless for a ELR1 parser
    (unless we do as Bison does, i.e. do not care).
    For rnglr it does not matter if the lookaheads intersect or not.
    E.g. with <S> ::= {"" | b} {a {b | <S> c}}*, that has convergence conflicts, an infinite
    number of states would be generated. In elr1+ it is avoided because items are not added,
    and this is not a problem for elr1+ because it does not have to treat grammars with conflicts,
    and for rnglr this problem is avoided merging the leftpointers.
    For the elr1 that has the items on the stack, it has an increasing numbers of candidates
    (items), not infinite because it does not parse infinite strings.
    When a state has two candidates, with different lookaheads, that converge in a same one,
    there is no conflict, and in the dynamic next state on the stack there are two candidates,
    equal except for the different cids.
    Convergence conflicts would disappear in the elr1+ dfa because two items produce two items
    in the next state since they have different leftpointers, but, as said above, the second
    item is not added.

  - why convergence conflicts are a problem for ELR1?
    The problem is that it finds an item which has two predecessors and it does not know
    which one to follow, or that there are two items that apply.
    The problem seems to occur in the parser that puts the items on the stack, and not in
    the one that uses leftpointers (i.e. that does not put the candidates on the stack and
    instead it uses the DFA with leftpointers).
    The latter is clear: two items that produce a next item would produce also two
    leftpointers, i.e. two candidates in the next state, but they would have overlapping
    lookaheads, so when in a next state they will have successors that are final, they
    will also have overlapping lookaheads.
    The goal in ELR1 is that when there is a reduction, there must be only one path to follow
    to do it. This would not to be the case since for a same next symbol two final items
    denote a reduction. I.e. the convergence conflict appears here as a reduce-reduce one.
    Then also the former is clear since it does the same thing, but on the stack.
    However, the algorithm is defined for ELR1 grmmars, that do not have conflicts, so
    for the one on the stack the problem does not exist.
    And the same if the leftpointers are merged: the path would surely not be unique.
    Currently, the ELR1 pilot is generated even if there are conflicts because I followed the
    same idea as Bison: to resolve conflicts instead of complaining. This means that the
    parser handles also grammars that are not strictly ELR1, providing one parse when there
    would be several

  - since on the stack there are items with only one pointer (#cid), with convergence
    conflicts there should be more than one, showing that there could be more than one
    parse.
    And since convergence conflicts occur when there are more than one item converging
    in a same successor item and their lookaheads are not disjoint and the shift is done
    with the same symbol, with elr1+ this cannot occur because they would have different
    pik's (i.e. leftpointers).
    With elri+ when there is a convergence conflict the second item is not added, and
    no conflict is reported, and parsing is done all the same.

  - rnglr if we wanted to put on the stack the candidates, what would we put in the case of a 
    convergence conflict? I think that we must put the candidates with their cid, which means
    that they are distinct when the cid is different or -better- they have a set of cids
  - two convergent transitions are not a problem for ELR1 because in the dynamic
    state they are split; and so it could be for two conflicting ones, except that later
    they will generate two reductions. It is so because two candidates with the same
    state and lookahead produce successors that eventually are final states, and with the
    same lookaheads. It is then not possible to choose a reduction.
    Now, suppose that we keep them distinct. If there is no convergence conflict, then
    there should be no problem, the candidates will eventually come to a final state,
    the reduction will be unique, and I guess that there will be not a fan-out of candidates.
    If instead there is a convergence conflict, perhaps there will be fan-out, which is
    bad, but not infinite if the candidates are on the stack since only the ones that are
    needed to parse the input are generated, and not all the possible ones as is the case
    of the DFA.
    Of course, to produce a DFA with cids, there is a need for sets of cids (aka leftpointers).
    Not, suppose instead that we keep sets of cids only for the conflicting ones, and not
    for the others. This will prevent the fan-out, but when we come to the final states
    we must generate several reductions. But perhaps this can be done also recording sets of cids.
    The question is: if we on the dynamic states with convergent transitions keep the
    candidates distinct (each with its proper cid, and then why not, with its proper lookahead),
    then why we do not do the same on the pilot? We do not because that will produce infinite
    states.
    And what if we use a LR(0)? there would be no lookaheads and then no conflicts.
    We have then sets of leftpointers.
    Items differ only for the states (and leftpointers), as they do in LR. It would be
    pointless to make them differ also for the lookaheads because it would increase the
    number of states, and the lookaheads are only used to build the parse tables: record
    in them the rule to reduce for each lookahead. There would be no benefit not merging
    them.

  - why in LR(1) tables the items with the same dot are collapsed merging theit lookaheads?
    I do not think that this is because otherwise an endless number of states would be produced.
    Not merging would perhaps lead to reductions that are sharper?
    Not sure: suppose in a state we have:
        S -> xxx . alpha, [l1]
        S -> xxx . alpha, [l2]
    Then, in later states, when the dot eventually becomes final we would have:
        S -> xxx alpha ., [l1]
        S -> xxx alpha ., [l2]
    which means that we have two reductions with different lookaheads, but for the same
    rule, which is the same as having only one item with lookaheads merged.
    This should apply also to pilots with machines.
    However, with machines, reductions are done following chains of candidates. And
    either they are in the stack (dynamic states, in which case they are not collapsed),
    or they are in the pilot, in which case they are not collapsed either.
    The lookaheads serve to avoid conflicts that are present in a LR(0) DFA. Without conflicts,
    the actions are unique, and the parsing deterministic.
    The lookaheads serve to make sure that when a reduction is done, the parser can proceed
    because the symbol in the input is one of the lookaheads. If the lookaheads are less
    precise or are not present at all, the parser makes a reduction and then it cannot proceed
    and then it terminates unsuccessfully, which means that it discovers an error later.
    Note that when building a state, and finding that two items have the same dot, the
    lookaheads are merged. They are not when, after building a state, it tests if there is
    already an equivalent state. It must have the same items, with the same dots and lookaheads.
    If, instead, a LALR DFA is built, then an equivalent state is one that has the same items
    with the same dots, but any lookahead, which are then merged (and are then less precise).

  - I think that it is possible to avoid to put the candidates in the stack even without
    leftpointers providing that they are not collapsed in pilots.
    The leftpointers in the stack are not needed because they can be built on the fly:
    examining the previous state it is possible (though costly) to determine the predecessor
    of any canditate of the current state

  - in rnglre when there are sets of leftpointers we could merge items with the same dot merging their
    lookaheads and merging their leftpointers irrespectively on whether the lookaheads intersect
    or not

  - to reduce the number of states, it would be possible to have states reached with
    several symbols: we follow the links between items in a state with the ones in the
    predecessor states. Now, these states are in gss nodes connected with edges.
    A leftpointer from an item I2 points to an item I1, and I1 has a machine state M1
    and I2 has M2. M1 then has arcs to M2 labelled with symbols.
    An edge is then to be followed if the symbol on it is one of the symbols in the arcs.
    We must have some kind of table that tells this, e.g. let's have a comb, accessed
    with machine states and edge symbols: c(mac,sym) tells if an edge labelled sym is
    valid for a link to an item with machine state mac.
    Of course, this comb takes space and such space should be smaller than the increased
    number of states if each state is always accessed with the same symbol.
    At parse time, however, there is a need to access this table when visiting paths,
    which is not a simple algorithm, and making it more complex is not a good idea.
  - LR1 states are always reached with the same symbol, ELR1 states can be reached with
    different symbols, but the ones here are instead reached with the same one. When
    making a reduction in the LR1 and ELR1 case the states and symbols are on the stack,
    and they are the only ones to reduce, so it is irrelevant whether the states can be
    reached always with the same symbol or not. In ELR1RN instead the stack is a
    graph and when making reductions there are several walks to follow. If a state can
    be reached with several symbols, then the walks can be labelled with symbols that
    belong to several alternatives, and there would be a need to decide what edge to follow.
    This is what rnglrParser does. Here instead all walks are valid because all of the
    incoming edges in a gss node are labelled with the same symbol.
  - to reduce the number of states, the map from items of state J to state I that are
    connected with an arc from I->J can be put on that arc. But then, there should be
    a means to get it knowing what pilot states a gss edge connects.
    Well, this is the same as having in a state a set of tables, each one holding the
    leftpointers of the items when the state is reached from a specific other one.
    But these tables require space, much the same as duplicating the states.

Reductions

  - when making reductions, rnglre must thread all paths and in them the graph of links
    between candidates

  - the rn tables have reductions with the number of elements before the dot. It is
    used to find the paths long that number that made up the reduction (the rn tail is
    then added).
    Clearly, with machines this is changed because it would be meaningless.
    It is used in reduce() to know how many hops it must do to find the start of the rule,
    which is here changed because we must hop on the leftpointers.

  - for fixed-length rules, the reductions could perhaps be simpler. I did it in elr1+, but
    there it has a stack that can be accessed positionally, while here there is a graph.
    However, it is simpler to tread paths of a given length instead of treading then to
    the end.

  - the thing is that if the rule does not have a RE, the reduction length is known
    which means that in such a case there is no need to store the leftpointer, but it is
    this still true also when there are convergences? it is if the rules are kept separate
    because a non-RE rule has a fixed length and all what we need is to go back a number
    of states equal to the rule length following all paths, even if there were several
    leftpointers, but if a nt has only one machine, then there could be paths of different
    lengths, except for nts that have only one rule or all non-RE rules all with the same
    length. 
    Note that when there are rules of different length in a same machine state, their
    length is > 0; rules of length 0 make the initial state final, so they are not mixed
    with non null rules.
    What matters is that the length of all the paths from the accepting state at hand
    of the machine is the same, which allows to treat RE rules like, e.g. a [b], that have
    two accepting states, both with only one path to the initial state.
    Omitting the useless sets of leftpointers reduces the number of states:

       pilot ELR(1)      all sets  only re  +rn items
       java       2048   5686      3180     3180
       C          1177   3533      2316     2320
       pascal     1391   2409      1586     1587

    N.B. the time needed to make reduction is the same, we have to hop anyway; remember that
    rn tails apply also to rules that have a fixed length. However, there are fewer states.

  - in reductions, I have put the lhs because it is needed to perform nonterminal shifts,
    but there is a need for the item too

  - reductions are made by starting from an item in a state that denotes a reductin and
    following all the chains of leftpointers in the pilot states of all preceding gss nodes
    until the end of them and collecting the sppfs that are on the gss edges.
    Reductions to already processed gss nodes are kept in a worklist when gss nodes are
    processed, and then done.
    Actually, the reductions in such worklist are stored indicating the first gss node down
    the first edge of each chain (aka path) because that allows to avoid to reprocess all
    the reductions from a node, which would otherwise occur when an edge is added to an
    existing gss node. In such a case, recording that node in the worklist would make all
    the reductions done from is to be redone again.
    In the parser tables, the machine states that have a rn path to a final state are marked
    as RNTAIL, and items in pilot states that have such machine states in them are shown
    dashed in html graphs.
    In the pilot compressed DFA, reductions are stored as with ELR1: in each cell (state,terminal),
    where the terminal is each one of a reduction lookahead, the number of the item that starts
    such a reduction is kept.
    When making a reduction from a pilot item that have a machine state in it that is not
    a final state, but one that has a rn path to a final state, the reduction adds to the
    derivation the rn tail.
    There could be many rn tails. The reducer produces all the parse subforests for all of
    them.
  - a gssnode has a pilot state in it, with items in it and leftpointers. When, starting
    with an item we see that it has at least a leftpointer, we visit the edges to previous
    gss nodes and go to the leftpointed items in them, and repeat the process.
    Note that for each leftpointer we have a distinct walk, which could have the same
    edges as another. They will produce the same sppf, that would be stored only once.
    This means that we can have, e.g., a shorter walk and a longer one (that contains the
    shorter one).

Reduction paths (aka walks)

  - starting from a gss node N that has reductions, each reduction starts from a reduction item
    in it, and stops when one of its chain ends. We cannot put the chains of all the reduction
    item in N together because otherwise we would get paths of lengths which are not correct
    for each item. E.g. if in N item I1 reduces nt A, and item I2 reduces B, then the
    machines of A and B could have reductions of different lengths.
  - here we always build the paths starting from node down to the first edge when m > 0.
    When m > 0 it is called always with an edge. And 0 the path could be made of the
    startedge only, which occurs when the leftpointers of the reduction item point to items
    that have no leftpointers.
  - there is a need to find a path for all the chain of items.
    This means that we must carry along some knowledge of what items we are following.
    All the leftpointers are stored in a unique array, each set ending with a -1.
    This allows to keep here only one number that allows to pass from one leftpointer to
    the next and know when there are no more. The array stateHops is indexed with states
    and items that tells the index in the stateHopt array where the leftpointers are.
  - each pair pathedg,pathitm at index lev is equivalent to a walk in which the node is
    TONODE(pathedg[lev]) and the item is stateHopt[pathitm[lev]]
  - the reducer produces a walk for every item chain, not only for every path in gss.
    It is true that we need only paths in gss to make derivations, but following the
    chains of items, a chain can be longer than another, which means that we should have
    different reductions.
    To make reductions we need paths, not items chains, so all we need is to know
    when a path ends because one of the chains in it has ended, but to know this we must
    carry along edges and the chains that pass thru them, and eventually deliver paths.
    If two chains end at the same node, there is no need to deliver two paths.
    Note that for sure there are walks in the GSS that are long enough to contain all
    the chains of items.
  - we could take all the reduction paths visiting cycles only once. However, this is
    not much useful for applications, so, we disregard cyclic paths.
    The measures show that there is almost no difference in parse times between this and
    the solution in which cycles are not visited. However, in some cases the number of
    paths visiting cycles once can be very big.
    N.B. It is possible to get one path at a time also visiting cycles once: we have simply to
    remember where we left when building the previous path.
  - it is possible to know when the GSS is cyclic. This happens when an edge is added
    from a node in the level to another in the same level that has an higher index,
    if there are no cycles we can avoid to check if paths are cyclic.
  - to verify the finding of paths I use some methods that create nodes and edges and
    then one that builds a graph from a string representation. This could be useful to
    debug other parts too.
  - in rnglrParser, when an edge already exists, but has a different sppf, e.g. a token, a
    new edge is created. Scott does not, and also my rnglr does not because they treat BNF
    and in it from a dotted rule there is only one successor with one symbol: the one after
    the dot. But with EBNF there could be one successor state reached with two edges with
    two different symbols. If a pilot state can then reach another with two such edges, also
    the GSS must have two, unless the pilot state is split.
    I split states that would be equal except that they were accessed with different accessing
    symbols because of this problem. With pointers as pairs the problem did not exist because
    we could follow the proper edges testing the symbols on them.
    The example is:  S ::= b B S S | a | ε; B ::= ε; string: "bb". The pilot had a state
    I6 with two arcs to I3 with different labels. If the state I3 is not split in two,
    each with its own accessing symbol (i.e. if states are not reached always with the same
    symbol), when making the reductions all the edges are followed, generating spurious,
    wrong reductions.
    Perhaps it could be possible to have in states tables for leftpointers that depend on
    the incoming state, which should reduce the number of states, but this requires space and
    time and I am not sure that it solves the problem.
  - suppose I carry along in the gss the lengths of the strings parsed, starting from
    the states that have items with initial machine states (there could be problems with
    loops in gss), then when making reductions, I could know the lengths of the paths to
    visit. E.g. let's have in gss nodes a set of lengths. When the node is created and
    its state has an initial machine item, the set contains {0}, then when it is created
    as a result of a terminal shift, it should increase all the values in the set, and
    add a {0} if it contains an initial machine state.
    When it is created because of a nonterminal shift, the same. When making reductions,
    the set is taken and the paths of that length visited.
    When an edge is added to an existing node, I am not sure if its set must be merged
    with the one of the state: suppose that the edge has longer chains, then when making
    reductions, longer chains would be visited also down the other edges.
    So, perhaps the set must be attached to edges instead of nodes.
    But then the thing becomes much more complex: it is like carrying along the paths when
    nodes are created, which is the same as the Crespi's solution to put the candidates
    on the LR stack.
    Perhaps it needs to have states that are accessed always with the same symbol.
    Perhaps for some grammars these sets are large.
    It is slow.
  - N.B. from a same gss node there can be both non-empty derivations and empty ones.
  - note that it is not possible to avoid to scan the leftchains when making reductions:
    if there were no leftpointers, they would have to be built on the fly.
    From a reduction item, we can go to a previous state that has an initial item for the
    machine of the reduction one, but that is not necessarily the end of the path.
    States can have initial machine items that are the end of chains thave have
    nothing to do with the reduction chain that is being visited. See, e.g. tg32.28,
    state 2, that has an item 2 <1_<T>,{b a},{1}> from which a reduction chain starts
    and also an initial item for T, that has nothing to do with it.

Minimizing reductions

  - When a node is first created, it has only one edge, so there is no problem doing the
    reduction down to it. When it is already there, let's suppose that the node has not yet
    been processed, then all the edges must be processed. When an edge is added to an already
    processed node, then a reduction is enqueued in the rwl. Since this is done only when
    new edges are added, and this cannot go on forever, there is no need to check that the
    reduction to enqueue is not already in the queue.
  - the problem here is when there is already an edge: it has a sppf. How can we know that
    such sppf has the same cover as the new one we want to add?
    This is so also in the Scott's one: when the edge is not present it is created and
    the sppf set in it, but when it is present, it is not created, and the new rule node
    added to its sppf.
    When a reduction is first done, an edge is created from a node in the present level to
    another in the level that ends the derivation. So, if another reduction is done, and it
    shares the edge, also its derivaton must end in the same level.
    The problem here is that when the edge is first created, it could have a sppf for
    a etree. I think that if another reduction is done and shares the same edge, it should
    not add any rule node since it will be done when the etree is generated.

    Scott
    node present
      edge not present, create edge
          if m != 0
              add only m != 0 reductions down edge
    else
      add all empty reductions
      if m != 0
          add all m != 0 reductions
  
    This holds for nonempty reductions:
    If the edge is added to an existing node that has already been processed, then the reducer
    adds all the reductions of that edge to the rwl without checking that they are already in
    the rwl. It adds all reductions, not only the nonempty ones, actually it adds the table of
    reductions.
    Nothing is done for empty reductions, which in the Scott's algo are added only when a new
    node is created. Now, when a new node is created, it cannot be before the current one,
    so all its reductions will be processed.
    So, here we skip the reductions that Scott skips because when the node is present and
    already processed and the edge not, we add all the reductions to the rwl, but when the
    rwl is processed, onlu the nonempty reductions are done. If the node has not already
    been processed, it will, and at that time all reductions empty and nonempty are done,

Reductions, further ideas

  - in elr1 we have a linear stack, and when a reduction is made we do not know the
    number of elements to pop. We could keep another stack, one that holds the
    index of the beginnings of reductions. We would then not need to hop and to
    keep the leftpointers in the states. Well, only that because we must still
    collect the symbols from the stack, which means visiting its elements, although
    in a simpler way
    But here, we have to keep one such stack for every parse. There are cases
    in which they are represented by several lefpointers attached to a same item
    representing derivations that can have different lengths and then have paths
    in the gss of different lengths. We should carry along in nodes the info of the
    beginning, a sort of backpointer. But even if that was not the case, we must still
    hop in the gss to find the beginning of derivations, even when they have known
    lengths, so it is not possible to make a pop of a known length as we instead
    could to in ELR

Problematic groups

  - Berry-Sethi allows to distinguish a nonterminal that is inside a star from one that is
    not because they have different numbers.
    We could put in the pilot the Berry-Sethi items allowing then to tell easily a nt in
    a derivation that is inside a star, and to draw a dotted line in the sppf when that
    nonterminal generates the empty string (in that specific place).
    The items that are in the Berry-Sethi states represent different parsers, and in them
    we can tell if the nonterminals are star-nullable.
    E.g. for a RE (a)*|aaa and string aaa, the final state reached has two paths to the
    initial one: one for the a's in the star and another for the others.
    Suppose then that the a's are nullable nts: there would be two paths in the GSS
    and in one of them we would know that the nonterminal at hand is a nullable one in a star.
    Question: should then we use numbered nonterminals in the pilot edges? No, probably not.
    Probably we should use directly the BS items in the pilot.
    Berry-sethi FAs have states that contain items with numbered letters, which allows
    to tell that a specific instance of a nt in a derivation is inside a star and then to
    discard derivations in which it occurs more than once. These automa cannot parse
    a string against a RE, but at least could tell that a symbol is in a star.
  - it should be possible also to build pilots from NFA machines, and also directly with items
    of the grammar.
    The items that represent groups would step in them without keeping memory of their structure,
    and thus be similar to the machines. To know the structure, a virtual nonterminal for each
    group must be introduced.
  - PAT, that has for the star a bypass so as not to repeat indefinitely a nullable
    argument, does not need to split anything since it does not have nonterminals. If we
    would do the same, we would need to split nullable nonterminals that occurs in stars and
    outside them
  - we could produce machines in which for * there is one branch that matches an empty
    body and another that matches the nonempty ones. It is so in PAT. This would allow
    to treat problematic groups: it would generate no iterations or nonempty ones, but not
    a mixture of both.
    This requires to split a piece of the grammar in nonterminals that produce empty and in
    their versions that do not produce it, but this would be limited to the ones that appear
    in star (and perhaps in plus).
    N.B. S ::= (a|ε)* c and S ::= (a)* c  produce the same machine and forest. This is so
    because we here are flattening the derivations, and thus the empty bodies do not appear.
    They appear in: S ::= (a|A)* c; A ::= ε.
    I could do it in an optimized version that resolves the ambiguities of groups.
  - problematic groups occur in rn tails and also in GSS. I have developed an algorithm that
    detects if a path (in general) in a graph visits cycles more than once. This is appropriate
    for the web version because it allows to highlight repeateable sons in forest due to
    nullable bodies in repetition groups, but it generated too many combinations in general.
    Moreover, in this optimized version of the algorithm there is no need to highlight them,
    so, paths in GSSs that contain cycles are discarded. As for rn tails, I disallow paths
    that contain a same edge more than once, which allows in grammars like, e.g.
    <S> ::= {<A>}* <A>, <A> ::= "" with empty text to show a derivation with an empty body
    that would otherwise disappear.

Pilots

  - the leftpointers are there for efficiency because they could be reconstructed at parse
    time, spending time.
    I.e. from a state and item A, go to the previous state, and scan its items and take the
    ones that have A as successor. These are the leftpointers of A.
  - in pilots, in items, left is 0 for the ones that lead to fixed-length reductions, which
    is good to reduce the number of states because leftpointers are not used to make reductions.
    Actually, to know that a machine state leads to a reductions one with a fixed length
    reduction, the graph must be visited, and cycles detected. To make this simpler, when
    a machine has a variable-length reduction, all its states are marked as states that do
    not lead to fixed-length reductions.

  - the null rule has a machine with an initial state that is also accepting

  - I minimized the DFA machines. I produce them from NFAs, and when building new states I
    check that they are unique, so, they are not far from minimal.

  - in the ones for rnglr, each machine state can have several reductions so, a redRule
    is not sufficient, but here we have only one rule for each nt.

Bounded groups (n,m)

  - I do not know what is the behaviour with bounded groups, but they are not supported
    for the time being.
  - in a grammar they are not much used; they are more useful in a lexer
  - could the FAs with counters help? I do not think so, they are for bounded groups


LR modes

  - the whole idea of lr isles is that the parser could resort to lr parsing, which is much faster.
    This could be done in isles that have no groups (so as to make known-length reductions).
    The idea is that there are isles in the grammar in which parsing can be fast. If in a elr1
    pilot with conflicts there are isles without conflicts in which parsing can be done with elr1
    parsing, that is fast. If it were not so because of variable-length reductions, then it would
    be better to look for isles, e.g. that contain only fixed-length reductions in which there is
    no need to hop.
    The problem of plugguing LR isles into a ELR1 is that we must take a ELR1 frontier state and
    find an equivalent one in a LR pilot from which parsing can proceed. More of less like finding
    the dotted rules that are in the items of the ELR1 one and seek a LR state that has the same
    dotted rules (and perhaps lookaheads too).
    But ELR1 parsing is not much different from the LR one, and the measures show that its speed
    is comparable (at least if fixed rules are treated as a special case).
    So, we use a elr1 one that has no conflicts (in which case there is no need to build one,
    since it is already there).
  - the rn reduction in isles must be kept because an isle state can be reached also
    by the reducer when making a sequence of empty reductions, and thus it must also behave
    as a normal state. E.g. <S> ::= <A> <B> | <B> <A> with A and B empty.
    Note that here I produce a ELALR table from a LR1 one, that has the lookaheads defined
    on the reductions, including the rn ones. Actually it has them on all the items,
    also on the terminal shift ones, which are not needed and are discarded when building
    the compressed tables. So, we do not need a special rn version of the step-by-step one.
  - the question is on whether it is convenient to use isles that have only fixed
    rules in them, or also rules that have repetition groups.
    With the fixed ones it is simpler to make reductions. They are discovered by accessing
    the derlen table with the machine state of the reduction, and seeing that there is in it
    a length defined. Treating them as a special case is convenient since they are the majority.
  - the gain of the lr modes is quite big (it doubles the speed in javalalr) in grammars that
    are almost LALR
  - lr modes allow to build the forest incrementally, reducing then the size of the GSS,
    and the total size of the footpring: the size of the forest grows along with parsing,
    but that of the gss is smaller. If the forest is not produced incrementally, at the end
    there is a large gss and a large forest (and it is difficult to reduce the gss when the
    forest is sifted out of it).
  - the static lr mode needs the dynamic one to reenter it as soon as possible, but it can
    also do without it
  - the lr modes are entered when there is only one gss node on the level because at this
    point parsing can proceed deterministically. When there are several nodes, there are
    several parses to be kept in parallel and it is not possible to mix gss and a linear
    stack, even when one of these parses enters an isle. This means that it must be possible
    to use the pilot for lr parsing and also for glr parsing, i.e. the tables must be good
    for both, and this means that the reductions must be represented in the same way.
    If that were not possible, then there should be two tables and when parsing in lr mode
    the lr one must be used.
    There is a table (derlen) that for each mac state tells the derivation length, if fixed,
    or -1 if not. When parsing in lr mode, the table is accessed and then the parser knows if
    the derivation has a fixed length.
  - the idea is that in lr mode the reductions are fast, so states that have reductions
    with several leftpointers are not lalr.
  - the dynamic lr mode is done when finding an adequate state even if it does not
    belong to any isle. Then either it performs a reduction replacing that state with
    another (in which case the lr static mode is attempted), or it performs a shift and
    then the mainloop is entered
  - since the criterion is to have a single action, shift or reduction, then a state must
    not have both or several reductions, which means that a reduction item must have only
    one leftpointer and have only one incoming edges from a same predecessor (which is
    guaranteed by accessing states always with a same symbol).
    It can have edges from different predecessors because when a LR stack would be built
    it would have only one predecessor. Of course, if states are reached always with a
    same symbol, there is no predecessor with several edges to the state.
  - after the kernel is made, reductions are done that add new gss nodes, Nodes are processed
    in sequence, and when a node has been processed, and its forest built, it it no longer
    useful, except when a new edge is added to it, or perhaps a new forest added to an
    existing edge. If there were a way to know when that cannot occur, the nodes could
    be removed, thus leading to smaller GSSs. That way is to detect if there are cyclic
    nonterminals: if there are none, then this cannot occur.
  - in lr dyn, a reduction is sone if it is adequate. A state could be inadequate for some
    terminals and not for some others. However, even an inadequate state could have some
    adequate actions for some terminals.
    This is the case when there is only one action, and also when there is only one shift
    or normal reduction.
    I have done it building a table that tells what actions are adequate, but the gain is null
    compared with the simpler check that there are no more than one action.
    This simple check tells that an action is inadequate when in the corresponding entry in
    the compressed table there is a shift and a rn reduction or a normal reduction and an
    rn one. However, this occurs seldom.
  - the window of gss levels that are removed by the dynamic lr modes begings at
    the lookback node of the reduction and ends at the current level.


- Forest encoding

  - the forest fragments are attached to the edges when reductions are made. Then, when
    a safe place in parsing is found (end of a lr mode) or at the end, the final forest
    is built transferring the fragments into an array (and relocating then references in
    them).

  - the etrees are built in the forest when encoding so as to put in it only the
    ones needed and not all. This was done setting to a dedicated value the elements that
    refer to a e-nt, and eventually resolving them
  - the Scott's paper says that etrees can be precomputed. In rnglr I did not do that because
    I wanted to add to the forest only the needed ones, and not all, and I had no idea how to
    precompute them and store them in the parse tables in such a way as to take only the needed
    ones and copy them in the actual forest. Precomputed etrees should have the edges relocated
    when they are copied.
    Instead I build them on the fly, and remember the ones build so as to reuse them as needed.
    Here the etrees are somehow more complex, they are forests.
    Note that here I need the pieces of the forest corresponding to the rn parts of rules.
    Ideally, having a Rekers parser (but note that I have only a Rekers recognizer now), and
    feeding it with a grammar made of a start symbol that has as rule:

         <S> ::= <A> | <B> | ...

    where <A>, <B> are all the nullable nonterminals, it could produce a forest with all the
    etrees (or better, eforests). Then I could store them relocating them properly (in some
    position-independent form).
    Adding also alternatives for the rn tails:

         <S> ::= <X1> <X2> ... | <Xm> <Xm> ...

    I could also generate the forests for the rn tails.
    That could also be done with an Elkhound one, but perhaps that is too much; a simpler
    one could do.
    The thing is that I need a Rekers for EBNF, which means that I must take the original
    Rekers algorithm, with the extra search. But perhaps there is a way of generating the
    forest without using a parser.
    Let's see: a concatenation is a forest node with the terms concatenated as sons.
    An alternative is a forest node with alternative nodes.
    The problem of patological REs must be dealt with here, e.g. stating that S -> A* with A
    nullable has a tree with a root and only one son.

    The problem is that the current form of forest does not allow to represent nodes with
    an infinite number of sons. A son can be a pointer to a father, thus allowing for cyclic
    grammars, but not a pointer to itself (perhaps), i.e. the number of sons is still limited.
    A rule such as S -> a {A}* b with A nullable can be represented as a node with how many
    nodes? To represent an infinite number of A's there would be a need for a special element
    that means: infinite A's.
    This, however, would be needed only for a case that in practice has no relevance, so
    we can as well choose to put only one A, or none at all.
    In summary, the eforest of a rule is made by taking all the paths from the start
    state to an end state that have all nullable nonterminals or empty.
    It is made of symbol nodes (made of a header followed by a sequence of intexes of rule nodes)
    and rule nodes (made of a link to next, and a derivation, made of a header with the length,
    followed by a sequence of elements).

     -  a nullable nonterminal can have rules that are non-nullable but that can have
        a nullable tail. I can compute the eSPPFs for all the nodes in machines that
        can have nullable paths to final states (perhaps some are redundant, e.g. the
        nodes that are reached with nullabla edges)
     -  esppfs are not computed by removing *s. E.g. S -> A (a)*. In this case there is a
        nullable path and is the one with no iterations. We take one iteration only if the
        body is nullable. In detail:

                       ,-B-,
                        v /
              ()---A--->()---C--->(())     A B C   if B nullable, A C otherwise
                                           S -> A B* C: S -> A B C, S -> A C
                           ,-B-,
                            v /
              ()-A-->()-B-->()-C->(())     A B C   if B nullable, none otherwise
                                           S -> A B+ C:  S -> A B C

                      ,------C-----v
              ()-A-->()-B-->()-C->(())     A B C   if B nullable, A C otherwise
                                           S -> A [B] C:  S -> A B C, S -> A C

     -  but this is debatable since a solution is that we could take no iterations always,
        be the body nullable or not.
        The case occurs only when the body is nullable. Then the answer of the parser
        "there are no iterations" is the same as "there is one" since they carry the
        same information. From the first one, the user can decide if he wants to
        interpret as no iterations or one with a nullable body as he likes, much the
        same as what the parser could do.
        Think also the case {A|B}* with both A and B nullable. The parser could return:
        "there is one A iteration, and alternatively there is a B iteration", which
        is the same as the user can tell. So, little is the usefulness for a parser to
        say that. Note also that the parser could also say "there are no iterations".
        It would present to the user three possible alternatives, which the user can
        as well figure out by himself.
     -  note that also taking no iterations the visit of the graph is not simple:
        in the thid case above we must choose the shortest path. It would be simpler to
        use machines built from the simplified rules above.
        To have no-iterations, in the first two cases we can simply discard the cyclic paths.
     -  with all solutions, it seems complex to define the paths to be taken (and then the
        trees) in terms of the machines, and instead simpler to define them in terms of the
        rules. In terms of machines we could say that we take all the nullable paths from
        accepting states to the initial one and make up a forest in which they are
        alternative derivations (trees).
     -  with S -> A [B] C we expect one etree, with S -> A B C | A B C we expect two,
        but the machines are the same. We could say that we have one derivation for each
        rule or one for each nonterminal.
     -  the case S -> A {B|C} D is even worse because here we must choose B or D, and both
        are ok, and nullable. A forest with two alternative trees must be generated.

  - I think that it is possible to encode the etrees in advance: in the forest, symbol nodes
    contains pointers to the rule nodes, and rule nodes contain elements that are pointers
    to other sppf (there are no tokens in etrees).
    The links between a node and its sons are absolute; they should be made relative to
    the node, i.e. as offsets from it.
    Suppose the etree of a nt is stored with the pointers in symbol nodes relative to the
    beginning of the symbol node, and the elements that contain nts.
    When copying a etree we should copy this, and then scan it to relocate the pointers
    in the symbol nodes and to remap the elements. It does not seem much different from
    building it on the fly.
    It is thus simpler to compute the rn tails as sequences of nonterminals, and then to
    create at parse time the sppfs from them

  - Scott uses a map to keep memory of the sppf nodes that lay in a same level: it maps
    nt,cover to the sppf node, where cover is the index of the level from which the
    derivation of nt starts. I tried this solution (-ADDHASH), but obviously it was
    slower than the hashing.
    The hash table contains all the sppfs (all levels), but it is autoaging: the visit of
    hash chains stops when an element of a previous level is found = only the elements of
    the current level are visited
    There is one directory for symbol nodes and another for rule nodes.
    I kept the head of the list of symbol nodes of a level in the sentinel.
    N.B. Here we have rule nodes even if actually they are not devoted to any rules since
    there is only one rule for each nt. They are devoted to derivations.

  - addGssSppf() builds a piece of sppf in the edges array, which will later be encoded
    in the final forest by encodetree.
    The symbol nodes in the edges array have the following form.
    N.B. edgeshdata is an array, its index 0 contains data for the first edge of the current
    level.
    This is the flat forest encoding:
                                                           edgeshdata
        +0  next:    link to next (only if no hashing)         *--> to the last rule
        +1  cover:   HEADSYM | index of nodes sentinel+1 
        +2  remap:   0
        +3  nt       nt
                     embedded rule, the first              <----,
        +4  rule     HEADSYM | index of next rule  *            |
        +5           HEAD | nt | len               |            |
        +6           elements                      |            |
                                                   |            |
        non-embedded rule:                         |            |
                                                   |            |
        +0  next     HEADSYM | index of next rule <'            *
        +1  head     HEAD | nt(b9-b0) | len(b28-b10)
        +2           elements

        in the GSS edges, in GSS SPPF nodes, and in the final forest nodes, the elements are:

        < 0          token
        ELR_RN | nt  nullable nt
        HEAD | tree  already built, tree: index in the final forest
        sppf         index of the sppf node in the edges array

        in the LR stack, the sppf denotes:

        < 0          token
        ELR_RN | nt  nullable nt
        tree         already built, tree: index in the final forest

    There are always symbol nodes in the forest, i.e. there are no isolated rule nodes;
    the optimization is that the first rule is attached to the symbol node.
    Then, when a new rule node has to be added to the same symbol node, there is no need to
    restructure it (which is instead done in the Scott's one).

    The format in the final forest is:

        symbol node:

        +0  head:    HEADSYM | number of alternatives
        +1           index of first alternative
        +.           .....
        +n           index of last alternative

        rule node:

        +0  head:    HEAD | ELR_TREE | nt(b9-b0) | len(b28-b10)
        +1           elements

        elements:

        < 0          token
        tree         index of a sppf node


Benchmarking

  - rnglrmea comment measurefile

  - I tried to have a test case for javascript, ecma 262 + jquery, but the latest syntax
    is quite complicated (many rules are parameterized denoting several EBNF rules) and
    requires a big effort to be converted in BNF. I tried Rest too, but its syntax is
    scattered in a large document and requires also a big effort to be converted in BNF.

  - I compared this with rnglr (it provides a forest according to the recursive representation
    of groups).

  - measure of states
                ------nr of states------------  gram size   fixed
                LALR    ELR1+   ELALR1  +isles              reduc. isles
    javalalr     624    3113      1882    1879     1095      1027   1024
    java         744    3732      2270    1273     1320      1332    533
    c            483    2604      1286     582      912       849    192
    cpp         1072   24740      3688    1715     1990      2696   1033
    freepascal  1116   16044      2381    1398     2005      1272    425
    html        1740  112676      2132    1146     3056      1959    993
    gram1          9       9        10       1       16        10      1
    json          46      68        47      44       86        36     33
    xml1          30      23        24      21       53        24     21
    go           608    3524      1537     735     1112       766    291

    html.bnf: the ELR1 pilot has states too many states, the ELALR(1) one is used.

    kernel size	1	2	3	4	5
    javalalr	100.0%	0.0%	0.0%	0.0%	0.0%
    java        84.9%	5.9%	4.9%	1.2%	3.0%
    c	        67.8%	21.8%	7.0%	3.0%	0.3%
    cpp	        68.9%	22.7%	5.0%	3.0%	0.5%
    freepascal	95.1%	4.9%	0.0%	0.0%	0.0%
    html        90.4%	9.6%	0.0%	0.0%	0.0%
    gram1       100.0%	0.0%	0.0%	0.0%	0.0%
    json        100.0%	0.0%	0.0%	0.0%	0.0%
    xml1        100.0%	0.0%	0.0%	0.0%	0.0%

    I have measured this, but the parser speed seems not much related to this, which could
    depend on the gss nodes generated besides the kernel ones.

  - measure the gain of lr mode in javalalr and java
      javalalr: 270 toks/ms  -> 633
      java:     222 toks/ms  -> 303
    the gain is big with a grammar that is almost LR, but considerable also with one that
    is only half LR

  - memory:
                   lr mode on    lr mode off
    grammar        bytes/tok     bytes/tok
    javalalr.bnf      20.4         20.4
    javalalr.bnf     284.9         61.2
    java.bnf         342.7         73.5
    c.bnf            746.3        199.8
    cpp.bnf          426.7         41.8
    freepascal.bnf   340.5         13.09
    html.bnf        7605.2       7372.6
    json.bnf         215.7        157.7
    xml1.bnf          52.2          2.6
    go.bnf           326.7         99.7

  - data of the grammar
                    grammar *+      group   opt     % rep
                    size    rep.gr  simple          over grammar
    javalalr.bnf    1095    134      2       45      12.2%
    java.bnf        1320    154      0       54      11.7%
    c.bnf            912     77      6       49       8.4%
    cpp.bnf         1990    153      3      127       7.7%
    freepascal.bnf  2005    224     25       80      11.2%
    html.bnf        3056    360      4       29      11.8%
    gram1.bnf         16      2      0        0      12.5%
    json.bnf          86     14      1        4      16.3%
    xml1.bnf          53     13      0        1      24.5%
    go.bnf          1112    139     12       60      12.5%

  - measuring the amount of input that is parsed in lr mode and in ndet mode, it seems that
    40% is parsed in lr mode for go, and only 25% for c, which justifies why go is faster
    in rnglre, and I should do the same for rnglr to see why in it it is so much faster
  - since lr parts have fewer reductions, we must also rekon how many are done in each mode
    go: 73% in nondet, c: 95% in nondet, which again shows why go is faster

  - have a distribution of the parse speed over the files. For each grammar, parserscope
    collects the speeds and then determine the maximum and then choose the rank.
    Note that this serves only to see the frequencies of the speeds of the corpus, not to
    determine the total average speed of the parser.
    The median tells the most frequent case of speeds,

  . justification for removing the outliers from the corpus of go
    rank 5.0 50.0 100.0 150.0 200.0 250.0 300.0 350.0 400.0 450.0 500.0
    parse speed distribution  0.2  4.7  4.5  3.6  4.5  5.5  8.1  12.0  20.8  20.4  6.9  8.6
    i.e. only 0.2% of the files have a very low speed (<= 5 toks/ms)

  - jit spoils the measurements because it compiles the bytecode as execution goes by.
    When compiling a sequence of files, the bytecode gets compiled and after the first one
    the times become stable.
    Source files can contain different applications of the rules, which means that even LR
    parsing could show non-linear parse times across files. Only when the same rules are
    applied in a way that is proportional to the input the parse times are linear.
    E.g. in javalalr corpus there are files that have differing parse speeds because they
    have a different syntactic structure.
    Therefore, it is not possible to chart the parse speeds with the length of the input
    because the result is not linear even for LR parsing.
    So, the only meaningful measure is the average speed across all the corpus, to be
    compared with that of other parsers.
  - measuring the average parser speed serves to compare the speed of this algorithm with
    that of others and to compare the speed of a corpus of a grammar with that of other
    grammars

  - https://catalog.data.gov/dataset?res_format=JSON&page=2


Optimizations

 - leftpointers as indexes (i.e. not pairs)
 - LALR pilot
 - fixed-length reductions
 - lr one-pass modes (isles)
 - acyclic GSS detection
*/

class ParserRnglrEbnf extends ParserGLRengine {

    // Access to GSS nodes and edges
    private static final int NODE_EDGES = QUANTUM;
    private static final int EDGE_TO = 1;
    private static final int EDGE_SPPF = 2;

    /** 
     * Construct a parser for the specified grammar and lexicon.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    public ParserRnglrEbnf(ParserTables tab, Object inp, String flags, String algo){
        setParserData(tab,inp,flags,algo);
    }

    /** 
     * Construct a parser for the specified grammar and lexicon.
     */

    public ParserRnglrEbnf(){
    }

    /** 
     * Set the specified parser data.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    @Override
    protected void setParserData(ParserTables tab, Object inp, String flags, String algo){
        this.tab = tab;
        this.tablr = (ParserLRTables.ELR1RNFAtables)this.tab.pilot.lrTables;
        this.lex = new ParserLex(tab,inp);
        this.algo = algo;
        settrc(flags);
        EOF = this.tab.numOfToks;
    }

    /**
     * Deliver a string representing the symbol/state of the specified GSS node.
     *
     * @param      l index of the node
     * @return     string
     */

    @Override
    protected String GSSsymbol(int l){
        return "" + l;
    }

    /**
     * Deliver a string representing the specified GSS node.
     *
     * @param      itm index of the node
     * @return     string
     */

    @Override
    protected String itemToString(int itm){
        int dt = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)];
        StringBuilder sb = new StringBuilder();
        java.util.Formatter f = new java.util.Formatter(sb);
        f.format("%s [%s]",itm,dt);
        int tok = 0;
        for (int e = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES]; e != 0; e = gssEdgeDir[(e)>>>NSHF][((e)&MSK)]){
            f.format(", %d%s",e,edgeToString(e,tok));
        }
        return sb.toString();
    }

    /**
     * Deliver a string representing the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    @Override
    protected String edgeToString(int edge, int tok){
        if (edge == 0){
            return "";
        }
        int le = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        String sbs = esToString(edge,tok,true);
        return String.format("(to: %d s: %s)",le,sbs);
    }

    /**
     * Deliver a string representing the sppf of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    private String esToString(int edge, int tok){
        return esToString(edge,tok,false);
    }

    /**
     * Deliver a string representing the sppf of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    private String esToString(int edge, int tok, boolean full){
        if (edge == 0){
            return "";
        }
        return sToString(gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],tok,full);
    }

    /**
     * Deliver a string representing the sppf of the specified edge.
     *
     * @param      edge edge
     */

    protected String edgeSppfToString(int edge){
        return String.format("[%d %s]",gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],sToString(gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],0,false));
    }

    /**
     * Deliver a string representing the specified sppf.
     *
     * @param      su sppf
     * @param      tok number of the token, if the sppf represents the EOF
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    private String sToString(int su, int tok, boolean full){
        if (su == 0) return "";
        String sbs = Integer.toString(su);
        if (su < 0){                           // token
            int tn = 0;
            int ln = 0;
            if (tok == tab.numOfToks){ // eof
                tn = tab.numOfToks;
                ln = tab.numOfToks;
            } else {
                tn = getTokNr(su);
                ln = getLexNr(su);
            }
            sbs = tab.tokLitName(tn);
            if (ln != tn) sbs += "," + getLexeme(ln);
            long pt = getPoint(su);
            if (pt >= 0) sbs += "," + pt;
        } else if ((su & ELR_RN) != 0){      // nullable nt
            if (this.tab != null){
                sbs = this.tab.gramSymToString(su & ~ELR_RN) + "e";
            } else {                         // in testing
                sbs = "" + (su & ~ELR_RN) + "e";
            }
        } else {
            sbs = "" + (su & ~HEADF);
            if (full){
                if ((su & HEADF) != 0){          // already encoded
                    su &= ~HEADF;
                    sbs += "t";
                    if (isAlt(su)){
                        int nru = this.tree[(su)>>>NSHF][((su)&MSK)] & ~HEADSYM;
                        for (int i = 0; i < nru; i++){
                            sbs += i == 0 ? "" : "|";
                            // this should be derToString(i+su ?
                            sbs += " " + derToString(i,0,null);
                        }
                    } else {
                        sbs += " " + derToString(su,0,null);
                    }
                } else {                         // sppf gss
                    boolean first = true;
                    for (int i = su & ~HEADSYM;;){
                        if (!first) sbs += " |";
                        first = false;
                        int len = gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)] & ~HEADF;          // length of phrase of derivation
                        int nt = len & ELR_TREE_NT;
                        sbs += " " + this.tab.gramSymToString(nt) +
                            " ::= " + sppfRuleToString(i,false);
                        i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)] & ~HEADSYM;
                        if (i == 0) break;
                    }
                }
            } else {
                if ((su & HEADF) != 0){          // already encoded
                    su &= ~HEADF;
                    if (isAlt(su)){
                        sbs = getLitName(this.tree[(su+1)>>>NSHF][((su+1)&MSK)]);
                    } else {
                        sbs = getLitName(su);
                    }
                } else {                         // sppf gss
                    int len = gssEdgeDir[(su+1)>>>NSHF][((su+1)&MSK)] & ~HEADF;
                    int nt = len & ELR_TREE_NT;
                    sbs = this.tab.gramSymToString(nt) + "/" + su;
                }
            }
        }
        return sbs;
    }

    /**
     * Add a GSS node if none exist in the current level with the specified state,
     * and possibly an edge to the specified node, if none exists, with the specified sppf.
     *
     * @param      st pilot state
     * @param      le to node, 0 if none
     * @param      sppf sppf of the edge
     * @param      dupl 0: do not check if another node with the same state is present
     * @return     length
     */

    /* N.b. with dupl = 0 it keeps note of the added node in the stater, i.e. it does not
     * use the hash table, and this is used in the lr dyn mode avoiding to reinitialize
     * // then the hash table should it instead have been used
     */

    @Override
    protected int addNode(int st, int le, int sppf, int dupl){
        ;
        addNodeNr++;
        ;

        ;
        this.addedEdge = -1;
        int itm = 0;
        int hfunct = 0;
        int l = 0;
        boolean found = false;
        search: {
            if (dupl == 0){
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm = this.stater[st];
            if (itm < this.absLevelGss){   // an item with the same dot not present
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm -= this.delta;
            found = true;
        } // search
        boolean pedfound = false;
        boolean tohash = false;
        // #endif
        ;
        add: if (found){
            ;
            if (le == 0) break add;
            // add the new pedigree if not already there
            int prev = searchNodeEdge(itm,le);
            if (prev == -1){            // found
                pedfound = true;
                break add;
            } else if (prev == -2){     // not found, to be hashed
                tohash = true;
                prev = 0;
            }
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
            gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = sppf;
            this.gssEdgeNr = l + EDGE_FIELDS;
            // prepend new edge
            if (prev == 0){
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] & 0x7fffffff;
                gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] = tohash ? (l | 0x80000000) : l;
            } else {
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)];
                gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)] = l;
            }
            ;
            this.addedEdge = l;
        } else {
            l = 0;
            addedge: {
                if (le == 0) break addedge;
                // create new node and edge
                if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                    enlargeGSS(1);
                }
                l = this.gssEdgeNr;
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
                gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
                gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = sppf;
                this.gssEdgeNr = l + EDGE_FIELDS;
                this.addedEdge = l;
            }
            if (this.gssNodeNr >= this.gssNodeLength){
                enlargeGSS(0);
            }
            int n = this.gssNodeNr++;
            int[] block = this.gssNodeDir[n >>> NSHF];
            int off = n & MSK;
            block[off] = st;
            block[off+NODE_EDGES] = l;
            itm = n;
            ;
            this.items++;
        }
        if (!pedfound && tohash){
            hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = this.edgeshlink.length << 1;
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = itm;
        }
        if (found) itm = -itm;
        return itm;
    }

    /**
     * Search an edge from the specified GSS node to the other specified GSS node.
     *
     * @param      itm  from node
     * @param      le   to node
     * @return     index of the edge
     */

    @Override
    protected int searchNodeEdge(int itm, int le){
        int hfunct = 0;
        int prev = 0;                
        add: {
            int edg = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES];
            if (edg >= 0){     // >= 0 when a node is created with no edges, ..
                               // and then an edge is added it must not be hashed
                ;
                int len = 0;
                for (int i = edg; i != 0;
                    i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)],
                    len++){
                    int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                    if (lef == le){
                        ;
                        prev = -1;                
                        this.addedEdge = -i;
                        break add;
                    } else if (lef > le){     // (A) keep pedigrees in ascending left ordering to speed search
                        break;
                    }
                    prev = i;
                }
                if (len > 20){
                    //nrsearchNodeEdgerehash++;
                    // put the list in the hash table
                    for (int i = edg; i != 0;
                        i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)]){
                        int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                        hfunct = (itm*31 + lef) & (this.edgeshdir.length - 1);
                        int z = i - this.levelEdgeGss;      // relative to level
                        if (z >= this.edgeshlink.length){
                            int newlen = this.edgeshlink.length << 1;
                            if (z > newlen) newlen = z + 1;
                            this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                            this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
                        }
                        this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
                        this.edgeshdir[hfunct] = i + this.deltaEdges;
                        // use edgeshdata[] to hold the start node
                        this.edgeshdata[z] = itm;
                    }

                    prev = -2;         // to hash
                    gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] |= 0x80000000;
                }
            } else {      // < 0: it has a long list
                hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
                for (int z = this.edgeshdir[hfunct];
                    z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                    int edge = z - this.deltaEdges;
                    if (this.edgeshdata[z-this.absLevelGssEdges] == itm &&
                        gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)] == le){
                        prev = -1;                
                        this.addedEdge = -edge;
                        break add;
                    }
                }
                prev = -2;         // to hash
            }
        } // add
        ;
        return prev;
    }

    /**
     * Create a new GSS node for the specified state in the current level, and possibly an
     * edge to another node with the specified sppf.
     *
     * @param      state pilot state for the node
     * @param      to to node, 0 if none
     * @param      tree sppf
     * @return     index of the node
     */

    @Override
    protected int newGSSENode(int state, int to, int tree){
        ;
        int l = 0;
        if (to != 0){
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
                /*
                TRACE(M,"newGSSENode enlarged %d blocks: %s\n",
                    this.gssEdgeNr,gssBlocksToString());
                */
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = to;
            gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = tree;
            this.gssEdgeNr = l + EDGE_FIELDS;
        }

        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int n = this.gssNodeNr++;
        int[] block = this.gssNodeDir[n >>> NSHF];
        int off = n & MSK;
        block[off] = state;
        block[off+NODE_EDGES] = l;

        if (to != 0){
            int hfunct = (n*31 + to) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,this.edgeshlink.length << 1);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,this.edgeshdata.length << 1);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = n;
        }

        this.stater[state] = n + this.delta;
        ;
        // nrOfNodes++;
        this.items++;
        ;
        return n;
    }

    /**
     * Print the statistics.
     *
     * @param   print stream
     */

    @Override
    public void statistics(PrintWriter trc){
        trc.printf("lrsmode %s lrsmode1 %s lrdmode %s ndetmode %s mloopnr %s\n",
            lrsmode,lrsmode1,lrdmode,ndetmode,mloopnr);
        trc.printf("mode tokens: %s mode reductions %s\n",
            Arrays.toString(modetoks),Arrays.toString(modereds));
    }

    /** The reference to the LR parse tables. */
    ParserLRTables.ELR1RNFAtables tablr;

    /**
     * Parse the input from the lexer that was specified at object construction
     * time.  Return whether the parsing ended successfully.
     *
     * @return <code>true</code> if the parsing succeeds, and <code>false</code> otherwise.
     */

    public boolean parse(){
        ;
        ;
        enlargeGSS(0);                        // create first gss blocks
        enlargeGSS(1);
        this.levelGss = 2;                    // this serves to make makeSentinel below work
        this.gssNodeNr = 0;
        this.gssEdgeNr = 1;                   // for edges hash: 0 = null
        makeSentinel();                       // create a sentinel
        this.loc = 1;

        this.stater = new int[this.tablr.stateNr]; // what states are already in the current level
        boolean res = false;
        this.level = 1;
        this.levelGss = this.gssNodeNr;
        this.absLevelGss = this.levelGss;
        this.delta = 0;
        this.levelEdgeGss = this.gssEdgeNr;
        this.deltaEdges = 0;
        this.absLevelGssEdges = this.levelEdgeGss;
        this.levelEdgeGss = this.gssEdgeNr;
        this.etrees = new int[this.tab.numOfNts];
        this.reduceWl = new int[400];
        this.reduceWli = 0;

        this.encodetreestack = new int[this.longestRule];

        // create an initial ParseTop with grammar-initial-state,
        // set active-parsers to contain just this
        int first = newGSSENode(0,0,0);         // create a node for the start state
        ;

        this.potter = new int[60];

        this.currentToken = tokenizer();
        int potlen = 0;

        // for each input symbol
        mainloop: for (;;){
            ;
            if (this.currentToken < 0) break;

            int topmostParsers = this.gssNodeNr - this.levelGss;
            int newNode = 0;
            int parser = 0;

            if (this.tablr.elr1kind == 1){            // lr modes on
                tryDeterministic: while (topmostParsers == 1){   // same as if ()for(;;)

                    // see if static lr mode applicable
                    parser = this.gssNodeNr - 1;
                    int spar = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
                    boolean isfront = ((this.tablr.isFrontierStates[(spar)>>>ParserTables.NSHIFTB] & (1 << (spar& ParserTables.MASKB))) != 0);
                    ;
                    if (isfront){
                        // there is only one gss node = one parser, and it has a frontier state
                        ;
                        int edge = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)+NODE_EDGES];
                        edge &= ~0x80000000;
                        if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] == 0){
                            int lev = this.level;
                            int prevedge = this.gssEdgeNr;
                            int lrstate = parseELR();
                            if (lrstate < 0){
                                this.gssNodeNr = this.levelGss;  // make it fail
                                break mainloop;
                            }
                            ;
                            if (this.level > lev && this.gssNodeNr > this.levelGss){ // new level needed
                                this.level--;
                                makeSentinel();
                                this.level++;
                                this.levelGss = this.gssNodeNr;
                                this.absLevelGss = this.levelGss + this.delta;
                                this.levelEdgeGss = this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                            } else {
                                // replace the node
                                this.stater[gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)]] = 0;   // remove the pointer to the node
                                this.gssNodeNr--;
                                int curEdgeNr = this.gssEdgeNr;
                                this.gssEdgeNr = prevedge;
                                this.delta += 1;       // roll up total delta
                                this.absLevelGss = this.levelGss + this.delta;
                                this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                                // adjust the sentinel
                                gssNodeDir[(this.levelGss-2)>>>NSHF][((this.levelGss-2)&MSK)] = -this.level;
                            }
                            // no need to check for duplicates
                            newNode = addNode(lrstate,gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)],this.LRtree,0);
                            parser = newNode;
                        }
                    }
                    // lr dynamic mode
                    ;
                    int lrres = parseELRdyn();
                    if (lrres == -2) return false;
                    newNode = this.gssNodeNr-1;
                    if (lrres == -1) break tryDeterministic;
                    if (lrres == -3) break mainloop;
                    if (lrres == 0){
                        parser = newNode;
                        this.currentToken = tokenizer();
                        continue mainloop;
                    }
                } // tryDeterministic
            } 

            // repeatedly run the reducer, and the scanner to save tokens
            int lexstore = 0;
            potlen = 0;                            // initialise pot for next list
            int start = newNode;
            if (start == 0) start = this.levelGss;
            int i = start;
            this.reduceWldp = 0;
            clo: for (;;){
                boolean advanceList = false;
                cloloop: if (i < this.gssNodeNr){
                    advanceList = true;
                    // process shifts and reductions
                    int state = gssNodeDir[(i)>>>NSHF][((i)&MSK)];
                    int flen = this.tablr.LRbase[state];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                    ;

                    boolean nonZeroReduction = false;
                    // process the empty reductions and save the shifts, if any
                    for (int j = 0; j < flen; j++){
                        int act = this.tablr.LRtable[fstart+j];
                        ;
                        if (act >= ParserLRTables.ISREDUCE){          // reduction
                            int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
                            if (m == 0){                          // empty reduction
                                int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
                                ;
                                reducer(i,act,0,false);
                            } else {
                                nonZeroReduction = true;
                            }
                        } else {                  // shift
                            // put it in potter
                            if (potlen >= this.potter.length){
                                this.potter = Arrays.copyOf(this.potter,this.potter.length << 1);
                            }
                            // there is no need here to check if there is already such a shift
                            // in potter: at the worst we will try twice the same shift
                            this.potter[potlen++] = act;   // new state
                            this.potter[potlen++] = i;     // item to be advanced
                            lexstore |= act;
                            ;
                        }
                    }
                    // process the nonempty reductions (if any): do them down to
                    // all the edges
                    if (nonZeroReduction){
                        ;
                        for (int edge = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES]; edge != 0; edge = gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)]){
                            edge &= ~0x80000000;           // remove hash mark
                            ;
                            for (int j = 0; j < flen; j++){
                                int act = this.tablr.LRtable[fstart+j];
                                if (act < ParserLRTables.ISREDUCE) continue; // not a reduction
                                int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
                                if (m == 0) continue;                    // empty reduction
                                if (gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)] >= this.levelGss) continue;   // edge due to an empty reduction
                                reducer(i,act,edge,false);
                            }
                        }
                    }
                } else if (this.reduceWldp != this.reduceWli){
                    ;
                    ;
                    int itm = this.reduceWl[this.reduceWldp++];
                    int ru = this.reduceWl[this.reduceWldp++];
                    int mm = this.reduceWl[this.reduceWldp++];
                    int ed = this.reduceWl[this.reduceWldp++];
                    for (int j = 0; j < mm; j++){
                        // the entry in the compressed table
                        int act = this.tablr.LRtable[ru+j];
                        if (act >= ParserLRTables.ISREDUCE){          // reduction
                            int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
                            if (m == 0) continue;                 // empty reduction
                            reducer(itm,act,ed,true);
                        }
                    }
                    this.currentRed = this.reduceWldp;
                } else {
                    break;
                } // cloloop
                if (advanceList){
                    i++;
                }
            } // clo

            this.absReduceWli += this.reduceWli;
            this.reduceWli = 0;
            ;

            ;
            //Trc.out.printf("lev: %d levelGss %d absLevelGss %d\n",
            //    this.level,this.levelGss,this.absLevelGss);
            //tracerItemsList(this.levelGss-2);
            makeSentinel();
            this.level++;
            ;
            ;

            this.levelGss = this.gssNodeNr;
            this.absLevelGss = this.levelGss + this.delta;
            this.levelEdgeGss = this.gssEdgeNr;
            this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
            int z = 0;
            if (this.currentToken != EOF){
                z = saveToken(lexstore);      // eof cannot be encoded
            }
            ;
            for (int k = 0; k < potlen;){             // scan the potter
                int newState = potter[k++] & 0xfffffff;
                int toadvance = potter[k++];
                int w = addNode(newState,toadvance,z,1);
                if (w < 0) w = -w;
                ;
            }
            ;
            if (this.gssNodeNr == this.levelGss){    // kernel empty
                break;
            }
            if (this.currentToken == EOF){
                break;                               // eof
            }
            int nexttoken = tokenizer();
            if (nexttoken < 0) break;

            this.currentToken = nexttoken;
        } // mainloop
        ;
        // we come here either with a token that has not been recognized. i.e.
        // no parsers could shift it, or with an EOF shifted, i.e. a node for the
        // state that has S'-> S EOF .
        ;
        rec: if (this.gssNodeNr - this.levelGss != 1){
            res = false;
        } else {
            if (this.currentToken != EOF){
                res = false;
                break rec;
            }
            res = true;
            int e = gssNodeDir[(this.levelGss)>>>NSHF][((this.levelGss)&MSK)+NODE_EDGES];
            int to = gssEdgeDir[(e+EDGE_TO)>>>NSHF][((e+EDGE_TO)&MSK)];
            ;

            e = gssNodeDir[(to)>>>NSHF][((to)&MSK)+NODE_EDGES];
            ;
            if ((gssEdgeDir[(e+EDGE_SPPF)>>>NSHF][((e+EDGE_SPPF)&MSK)] & ELR_RN) != 0){
                int startnt = this.tab.grammar[this.tab.startRule];
                encodeEtree(startnt);  // return sppf in etrees[startnt]
            } else {
                encodetree(gssEdgeDir[(e+EDGE_SPPF)>>>NSHF][((e+EDGE_SPPF)&MSK)]);     // produce parse tree
            }
        }
        makeSentinel();     // close the gss
        ;
        return res;
    }

    /** The chain of items in a reduction path. */
    int[] pathItems;

    /**
     * Deliver a string representing a chain of hops that starts from the specified index.
     *
     * @param      idx index
     * @return     string
     */

    private String hopsToString(int idx){
        if (idx < 0) return "{}";
        String str = "{";
        for (int i = idx; this.tablr.stateHopt[i] >= 0; i++){
            if (i > idx) str += ",";
            str += this.tablr.stateHopt[i];
        }
        str += "}";
        return str;
    }

    /**
     * Deliver a string representing the specified parser action.
     *
     * @param      act action
     * @return     string
     */

    private String actToString(int act){
        if (act >= ParserLRTables.ISREDUCE){          // reduction
            int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
            int macsn = (act & ParserLRTables.MACMASK) + this.tablr.ntMacStart[nt];
            int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
            int reditem = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
            return "reduction nt " + this.tab.gramSymToString(nt) +
                (m == 0 ? " empty" : "") + " mac " + macsn + " item " + reditem;
        }
        return "shift to state " + (act & ~(ParserLRTables.SAVELEX | ParserLRTables.SAVEPOS));
    }

    /** Whether the GSS is cyclic. */
    private boolean gssCyclic;

    /**
     * Perform all reductions from the specified firstitm GSS node and down
     * the specifed edge, or no edge if the reduction has length zero.
     *
     * @param   firstitm GSS node from which the reduction starts
     * @param   act reduction action, from the compressed table
     * @param   startedge edge of firstitm down which the reduction is made, if
     *          the length of the reduction is not zero, and 0 otherwise.
     * @param   rwl <code>true</code> if the reduction is done from the rwl
     */

    /* A set of reductions is done for all the item chains that start from a reduction
     * item in a pilot state. For each such item there is a reduction action in the compressed
     * table at the cell (state,terminal), where the terminal is the lookahead for the
     * reduction.
     * From the specified action, the following data are got:
     *
     *    machine state number: it is the number of the machine state, relative to its
     *                          initial one, of the item of the reduction.
     *                          It serves to determine the rn tail and the length of the
     *                          reduction if it has a fixed lengh.
     *    reduction item nr:    the number of the reduction item in the state of the node (firstitm),
     *                          it is the head of the chain of items, whose links are contained
     *                          in the statehops
     *    nonterminal:          the nonterminal being reduced
     *    m:                    tells if the reduction is empty
     *
     * When called with an empty reduction, startedge = 0.
     * Otherwise, startedge is the edge down which there are the paths of the reduction.
     * The paths start with startedge and then proceed from the its to node.
     * When the length of the reduction is 1, then there is only one path, made of startedge.
     *
     * The fixed length here is that of a reduction state, that can contain reduction items
     * that are not final items. I keep separate this length from that of the final state
     * because the latter is used in lr static parsing.
     */


    private void reducer(int firstitm, int act, int startedge, boolean rwl){
        int startred = gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)];
        int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
        int macsn = (act & ParserLRTables.MACMASK) + this.tablr.ntMacStart[nt];  // absolute mac state nr
        int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
        int reditem = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
        int items = this.tablr.stateHops[startred][reditem];

        ;
        // getting the paths from start makes parse times much longer because a lot more paths
        // are found: all the ones that passes for all neighbours of start, and not only from v,
        // so, we get instead the paths starting at v

        int derlen = this.tablr.rnDerlen[macsn];
        boolean fixed = derlen >= 0;
        boolean nullrule = false;
        int second = firstitm;
        if (m > 0){                       // not an empty reduction
            second = gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)];
            if (gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] == 0){      // no path beyond startedge
                nullrule = true;
            } else if (derlen == 1){
                nullrule = true;
            }
        } else {
            nullrule = true;
        }
        // nullrule here means that there are no edges to find
        int origitem = second;
        int lev = 0;
        boolean first = true;
        int ed = 0;

        ;
        if (fixed){
            // allocate pathIterator to the max derlen
            if (this.pathIterator == null || this.pathIterator.length < this.tablr.maxRnDerlen){
                this.pathIterator = new int[this.tablr.maxRnDerlen];
            }
        }
        if (this.pathIterator == null || this.pathIterator.length < 100){
            this.pathIterator = new int[100];
            this.pathItems = new int[100];
        }
        int[] pathedg = this.pathIterator;           // progress points in states to deliver next path
        int[] pathitm = this.pathItems;
        if (m > 0){
            pathedg[lev] = startedge;
            pathitm[lev] = items;                    // the first of the items in the
                                                     // tonode of the startedge to visit
            lev++;
            // this is needed in order to have something to start with to make paths
        }
        allph: for (;;){                             // visit all paths
            makepath: {
                if (fixed){                          // find next fixed-length path
                    up: if (first){
                        if (nullrule){
                            ;
                            break makepath;
                        }
                        first = false;
                        ed = gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] & 0x7fffffff;
                        pathedg[lev++] = ed;
                    } else {
                        ;
                        // build next path
                        // go up until it is possible to go sideways
                        while (lev > 1){
                            ed = pathedg[--lev];
                            ;
                            ed = gssEdgeDir[(ed)>>>NSHF][((ed)&MSK)];
                            if (ed != 0){
                                pathedg[lev++] = ed;
                                break up;
                            }
                        }
                        break allph;               // no more paths
                    }
                    // go down to bottom
                    while (lev < derlen){
                        int le = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                        ;
                        ed = gssNodeDir[(le)>>>NSHF][((le)&MSK)+NODE_EDGES] & 0x7fffffff;
                        pathedg[lev++] = ed;
                    }
                } else {                            // find nex variable-length path
                    boolean goleft = false;
                    up: if (first){
                        if (nullrule){
                            ;
                            break makepath;
                        }
                        first = false;
                        int node = gssEdgeDir[(pathedg[lev-1]+EDGE_TO)>>>NSHF][((pathedg[lev-1]+EDGE_TO)&MSK)];
                        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];
                        int itemnr =  this.tablr.stateHopt[pathitm[lev-1]];
                        int lset = this.tablr.stateHops[state][itemnr];
                        if (lset < 0){             // no more chains
                            break makepath;
                        }
                        ed = gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] & 0x7fffffff;
                        if (this.gssCyclic){
                            // this is the simplified version in which all cycles are rejected
                            int to = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                            for (int i = 0; i < lev; i++){
                                if (gssEdgeDir[(pathedg[i]+EDGE_TO)>>>NSHF][((pathedg[i]+EDGE_TO)&MSK)] == to){
                                    continue allph;
                                }
                            }
                        }
                        pathedg[lev] = ed;
                        pathitm[lev++] = this.tablr.stateHops[state][itemnr];
                    } else {
                        ;
                        // build next path
                        // go up until it is possible to go sideways
                        while (lev >= 1){
                            pathitm[lev-1]++;             // next item
                            if (this.tablr.stateHopt[pathitm[lev-1]] >= 0){   // next item
                                ;
                                ed = pathedg[lev-1];
                                break up;
                            }
                            ed = pathedg[--lev];
                            ;
                            if (lev == 0) break allph;    // do not visit the siblings of the first
                            ed = gssEdgeDir[(ed)>>>NSHF][((ed)&MSK)];            // .. ege, the one down which we reduce
                            if (ed != 0){
                                goleft = true;
                                // pathedg[lev++] = ed;  done below
                                break up;
                            }
                        }
                        break allph;               // no more paths
                    }
                    // go down to bottom
                    for (;;){
                        if (goleft){
                            goleft = false;
                        } else {
                            int le = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                            ;
                            ed = gssNodeDir[(le)>>>NSHF][((le)&MSK)+NODE_EDGES] & 0x7fffffff;
                        }
                        int node = gssEdgeDir[(pathedg[lev-1]+EDGE_TO)>>>NSHF][((pathedg[lev-1]+EDGE_TO)&MSK)];
                        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];
                        int itemnr =  this.tablr.stateHopt[pathitm[lev-1]];
                        int lset = this.tablr.stateHops[state][itemnr];
                        if (lset < 0){             // no more chains
                            break makepath;
                        }
                        if (ed == 0) continue allph;   // no next edge, but there should be
                        if (this.gssCyclic){
                            // this is the simplified version in which all cycles are rejected
                            int to = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                            for (int i = 0; i < lev; i++){
                                if (gssEdgeDir[(pathedg[i]+EDGE_TO)>>>NSHF][((pathedg[i]+EDGE_TO)&MSK)] == to){
                                    continue allph;
                                }
                            }
                        }

                        if (lev >= this.pathIterator.length){
                            this.pathIterator = Arrays.copyOf(this.pathIterator,lev+100);
                            pathedg = this.pathIterator;
                            this.pathItems = Arrays.copyOf(this.pathItems,lev+100);
                            pathitm = this.pathItems;
                        }
                        pathedg[lev] = ed;
                        pathitm[lev++] = this.tablr.stateHops[state][itemnr];
                    }
                }
            } // makepath
            // TRACE(P,"reducer gss node %d\n",this.gssNodeNr);
            // TRACE(P,"reducer gss %s\n",GSStoString());
            // TRACE(P,"reducer path m %s %s: %s\n",m,firstitm,pToString(pathedg,lev));
            ;

            int len = m == 0 ? 0 : lev;
            int u = 0;                   // to node
            if (m == 0){
                u = origitem;
            } else {
                u = gssEdgeDir[(pathedg[lev-1]+EDGE_TO)>>>NSHF][((pathedg[lev-1]+EDGE_TO)&MSK)];
            }
            int k = gssNodeDir[(u)>>>NSHF][((u)&MSK)];
            int lrbase0= this.tablr.LRbase[k];int pl = this.tablr.LRcheck[lrbase0+nt] == lrbase0 ? this.tablr.LRtable[lrbase0+nt] : 0;;
            ;

            int w = addNode(pl,u,0,1);             // add a node in the current list for pl if not
                                                   // present and an edge (if not present) to u
            int wa = Math.abs(w);
            if (u > this.levelGss && wa <= u){     // backlink, GSS contains a cycle
                this.gssCyclic = true;
            }
            ;

            addtree: if (m > 0){
                if (this.addedEdge < 0){            // edge already there
                    int sppf = gssEdgeDir[(-this.addedEdge+EDGE_SPPF)>>>NSHF][((-this.addedEdge+EDGE_SPPF)&MSK)];
                    if (sppf > 0 && (sppf & ELR_RN) != 0){ // empty etree: all its derivations ..
                        break addtree;                     // .. already there
                    }
                }
                if (this.tablr.rnTails[macsn] != null){    // there is a rn tail
                    for (int i = 0; i < this.tablr.rnTails[macsn].length; i++){
                        int newsym =  this.addedEdge >= 0 ? 0 : gssEdgeDir[(-this.addedEdge+EDGE_SPPF)>>>NSHF][((-this.addedEdge+EDGE_SPPF)&MSK)];
                        int sppf = addGssSppf(nt,pathedg,len,
                            this.tablr.rnTails[macsn][i],newsym);
                        if (this.addedEdge >= 0){
                            gssEdgeDir[(this.addedEdge+EDGE_SPPF)>>>NSHF][((this.addedEdge+EDGE_SPPF)&MSK)] = sppf;
                        }
                    }
                } else {                                   // no rn tail
                    int newsym =  this.addedEdge >= 0 ? 0 : gssEdgeDir[(-this.addedEdge+EDGE_SPPF)>>>NSHF][((-this.addedEdge+EDGE_SPPF)&MSK)];
                    int sppf = addGssSppf(nt,pathedg,len,null,newsym);
                    if (this.addedEdge >= 0){
                        gssEdgeDir[(this.addedEdge+EDGE_SPPF)>>>NSHF][((this.addedEdge+EDGE_SPPF)&MSK)] = sppf;
                    }
                }
            } else {
                if (this.addedEdge >= 0){     // edge added (with node added or present)
                    gssEdgeDir[(this.addedEdge+EDGE_SPPF)>>>NSHF][((this.addedEdge+EDGE_SPPF)&MSK)] = ELR_RN | nt;
                }
            }
            ;
            red: if (this.addedEdge >= 0){         // edge added (with node added or present)
                if (w < 0){                        // new node not added, only edge added
                    if (m != 0){
                        w = -w;
                        addred: if (!rwl && w == firstitm){
                            ;
                            if (gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)+NODE_EDGES] >= 0){         // short list
                                if (gssEdgeDir[(this.addedEdge+EDGE_TO)>>>NSHF][((this.addedEdge+EDGE_TO)&MSK)] > gssEdgeDir[(startedge+EDGE_TO)>>>NSHF][((startedge+EDGE_TO)&MSK)]) break addred;  // edge after: processed in allph
                            }                          // long list: new edge prepended
                            int flen = this.tablr.LRbase[startred];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                            if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                                ParserLRTables.ISREDUCE){
                                // enqueue only if there are reductions (but there could be only empty ones)
                                addAllReductions(firstitm,fstart,flen,this.addedEdge);
                            }
                        }
                        int curItem = rwl ? this.gssNodeNr : firstitm;
                        if (w >= curItem) break red;  // node not yet processed
                        ;
                        // enqueue only nonempty reductions, i.e., the ones that have the added edge
                        int flen = this.tablr.LRbase[pl];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                        if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                            ParserLRTables.ISREDUCE){
                            // enqueue only if there are reductions (but there could be only empty ones)
                            addAllReductions(w,fstart,flen,this.addedEdge);
                        }
                    }
                }
            }
            if (nullrule) break;
        }
        ;
    }

    /** 
     * Test if the the adding of the edge to the specified path makes it contains a same cycle
     * more than once. N.B. for some graphs the performance is very bad and the number of
     * cycles, simple and otherwise, is very large.
     *
     * @param   ed edge canditate for adding
     * @param   node last node of the path
     * @param   path list of edges of the path
     * @param   pathitm list of items of the path
     * @param   lev length of the path
     * @param   startnode initial node of the path
     * @return  <code>true</code> if it does, <code>false</code> otherwise
     */

     /* Paths contain non-empty elemens as well as empty ones. Cycles can only occur
      * with the empty ones.
      * However, it is not simple to tell when an edge has a derivation for the empty
      * string, except perhaps to note that its endpoints belong both to the same level.
      * But also this requires time.
      * Alas, it means that in some cases we serch a cycle that is not there and then
      * we will not find it.
      *
      * The duplication of states due to the use of leftpointers that are not pairs makes
      * some walks that are not duplication of cycles appear as if they were.
      * E.g. <S> ::= a {<A> <B>}* b c; <A> ::= ""; <B> ::= ""
      * has a walk: <S> ::= 13/7.0---c--->10/5.0---b--->7/6.1---<B>e--->6/4.1---<A>e--->
      * 7/6.1---<B>e--->6/4.1---<A>e--->5/2.1---a--->2/0.0 +rn-tail: ""
      * in which there is: <B>e <A>e <B>e <A>e but the two Ae's come from two different
      * edges.
      * Note that it is not possible to use the sppfs to identify edges here instead of their
      * indexes, and so reject this path because when there is a sequence, e.g. A B A B, it
      * could seem two iterations of a cycle when they come from a path that is not.
      */

    private boolean makesCycle(int ed, int node, int[] path, int[] pathitm, int lev, int startNode){
        // find the main cycle
        ;
        ;
        // TRACE(P,"makesCycle gss %s\n",GSStoString());
        // TRACE(P,"makesCycle path %s\n",pToString(path,lev));

        int w = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
        boolean found = false;
        int startseq = -1;

        int sder = gssEdgeDir[(ed+EDGE_SPPF)>>>NSHF][((ed+EDGE_SPPF)&MSK)];
        cyc: if (w == node){
            // autoloop
            for (int j = 0; j < lev; j++){
                if (path[j] == ed){
                    ;
                    found = true;
                    break;
                }
            }
            startseq = lev;
        } else {
            int relen = (lev - startseq)*2;
            if (this.reusablePath == null){
                this.reusablePath = new int[relen];
            } else if (this.reusablePath.length < relen){
                this.reusablePath = new int[relen];
            }
            int[] purged = this.reusablePath;
            int purgedi = 0;
            for (int i = lev-1; i >= 0; i--){
                int from = (i == 0) ? startNode : gssEdgeDir[(path[i-1]+EDGE_TO)>>>NSHF][((path[i-1]+EDGE_TO)&MSK)];
                if (from == w){
                    startseq = i;
                    break;
                }
            }
            if (startseq < 0) break cyc;
            ;
            // here we must find from the beginning a sequence of arcs that is
            // the same as the current one - once the inner loops are removed.
            // Let's purge the current sequence of the inner loops to make this simple
            for (int j = startseq; j < lev; j++){
                purged[purgedi++] = path[j];
                // find the edge that has its to-node the same as
                // the to-node of the current one
                for (int m = j+1; m < lev; m++){
                    int from = (m == 0) ? startNode : gssEdgeDir[(path[m-1]+EDGE_TO)>>>NSHF][((path[m-1]+EDGE_TO)&MSK)];
                    if (gssEdgeDir[(path[m]+EDGE_TO)>>>NSHF][((path[m]+EDGE_TO)&MSK)] == gssEdgeDir[(path[j]+EDGE_TO)>>>NSHF][((path[j]+EDGE_TO)&MSK)]){      // inner loop
                        // skip to this
                        j = m;
                    }
                }
            }
            purged[purgedi++] = ed;
            System.arraycopy(purged,0,purged,purgedi,purgedi);
            // then find the purged sequence in the path, purging the path on the fly
            // find in the path the edge that is equal to the first one of the sequence
            // and then try to match the sequence
            sea: for (int i = 0; i < startseq; i++){
                int purgedstart = -1;
                for (int j = 0; j < purgedi; j++){
                    if (path[i] == purged[j]){
                        purgedstart = j;
                        break;
                    }
                }
                if (purgedstart < 0) continue;
                // here the path at index i has an edge that could be the
                // start of a cycle; let's see if it starts a cycle
                int endcycle = -1;
                for (int j = i+1; j < startseq; j++){
                    int from = (i == 0) ? startNode : gssEdgeDir[(path[i-1]+EDGE_TO)>>>NSHF][((path[i-1]+EDGE_TO)&MSK)];
                    if (gssEdgeDir[(path[j]+EDGE_TO)>>>NSHF][((path[j]+EDGE_TO)&MSK)] == from){
                        // cycle found;
                        endcycle = j + 1;
                        break;
                    }
                }
                if (endcycle < 0) continue;
                // try a match
                ;
                int pi = purgedstart;
                for (int j = i; j < endcycle && pi < purgedstart+purgedi; j++){
                    ;
                    if (path[j] != purged[pi]) continue sea;
                    pi++;
                    // skip inner loops
                    for (int m = j+1; m < endcycle; m++){
                        ;
                        int from = (m == 0) ? startNode : gssEdgeDir[(path[m-1]+EDGE_TO)>>>NSHF][((path[m-1]+EDGE_TO)&MSK)];
                        if (gssEdgeDir[(path[m]+EDGE_TO)>>>NSHF][((path[m]+EDGE_TO)&MSK)] == gssEdgeDir[(path[j]+EDGE_TO)>>>NSHF][((path[j]+EDGE_TO)&MSK)]){
                            // skip to this
                            ;
                            j = m;
                        }
                    }
                }
                if (pi == purgedstart+purgedi){
                    found = true;
                }
                ;
                break;
            }
        }
        ;
        // checkpath(startNode,path,lev,ed,found);
        return found;
    }

    /** The flag that marks the elements in a GSS SPPF that are nullable nonterminals. */
    private static final int ELR_RN = 0x20000000;

    /** 
     * Build a fragment of forest in the GSS collecting the elements that are present
     * in the specified path, adding the rn tail if any and putting them in a (so called)
     * SPPF rule node (which is just a derivation here rather than a rule), creating also
     * a SPPF symbol node if one is not already present with the desired cover, or return
     * one if an identical one already exists.
     *
     * @param   nt nonterminal for the derivation
     * @param   path edges of the reduction path
     * @param   plen length of the path
     * @param   rntail sequence of nonterminals of the rn tail
     * @param   symNode: index of the symbol node, if already present, 0 to create one
     * @param   startnode initial node of the path
     * @return  index of the sppf node
     */

    /* The cover of the derivation to be added is represented with the index of the
     * level at which its first element starts.
     * A hash table links all the GSS SPPFs and allows to find quicly one that has the
     * desired nt and cover.
     * Another hash table links all the rule nodes that have the desired nt and elements
     * and allows to find quickly if the desired rule node is already present.
     */

    int addGssSppf(int nt, int[] path, int plen, int[] rntail, int symNode){
        ;
        ;

        int len = plen;
        if (rntail != null) len += rntail.length;
        if (this.reusablePath == null){
            this.reusablePath = new int[len];
        } else if (this.reusablePath.length < len){
            this.reusablePath = new int[len];
        }
        int[] gamma = this.reusablePath;
        int j = 0;
        for (int i = plen-1; i >= 0; i--){
            gamma[j++] = gssEdgeDir[(path[i]+EDGE_SPPF)>>>NSHF][((path[i]+EDGE_SPPF)&MSK)];
        }
        if (rntail != null){
            for (int i = 0; i < rntail.length; i++){
                gamma[j++] = rntail[i] | ELR_RN;
            }
        }

        // find the number of the level
        int tonode = gssEdgeDir[(path[plen-1]+EDGE_TO)>>>NSHF][((path[plen-1]+EDGE_TO)&MSK)];
        int tonodeLev = tonode--;
        while (gssNodeDir[(tonodeLev)>>>NSHF][((tonodeLev)&MSK)] >= 0) tonodeLev--; 

        int targetSentinel = tonodeLev - 1;
        int thislev = this.levelGss - 2;

        int start = this.gssEdgeNr;
        int lastRule = 0;
        // simpler solution, with the link
        // there are cases in which we know already the symbol node, so skip search
        int hfunct = (nt + tonodeLev) & (this.sppfsymhdir.length - 1);
        int hfunctrule = 0;
        sy: if (symNode == 0){
            ;
            for (int z = this.sppfsymhdir[hfunct];
                z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                int s = z - this.deltaEdges;
                if ((gssEdgeDir[(s+3)>>>NSHF][((s+3)&MSK)] == nt) &&
                    ((gssEdgeDir[(s+1)>>>NSHF][((s+1)&MSK)] & ~HEADSYM) == tonodeLev)){    // found
                    symNode = s + 4;
                    ;
                    break;
                }
            }
        } else {
            ;
        }
        // compute the hash function to find the rule node
        hfunctrule = nt + symNode;
        if (symNode == 0) hfunctrule += this.gssEdgeNr + 4;
        for (int i = 0; i < len; i++){
            hfunctrule = 31*hfunctrule + gamma[i];
        }
        hfunctrule &= this.sppfsymhdir.length - 1;

        boolean createRule = false;
        boolean embeddedRule = false;
        boolean symadded = false;
        doit: if (symNode == 0){          // create it
            symadded = true;
            // compute length of node
            int nrfields = 6 + len;
            // enlarge block if no sufficient space available
            ;
            if (this.gssEdgeNr+nrfields > this.gssEdgeLength){
                enlargeEdges(this.gssEdgeNr+nrfields);
                /*
                TRACE(M,"addGssSppf enlarged %d blocks: %s\n",
                    this.gssEdgeNr,gssBlocksToString());
                */
            }
            int next = 0;
            int z = this.gssEdgeNr - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = z << 1;
                if (z < this.edgeshlink.length << 1){        // extend at least twice
                    newlen = this.edgeshlink.length << 1;
                }
                // this perhaps also in other places in which an unknown amount is needed
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.sppfsymhdir[hfunct];   // insert at beginning
            this.sppfsymhdir[hfunct] = this.gssEdgeNr + this.deltaEdges;
            // use edgeshdata[] to hold the tail of the list of rules
            this.edgeshdata[z] = this.gssEdgeNr + 4;
            ;

            gssEdgeDir[(this.gssEdgeNr+1)>>>NSHF][((this.gssEdgeNr+1)&MSK)] = tonodeLev | HEADSYM;   // cover
            // what does it mean that I use it for the level?
            gssEdgeDir[(this.gssEdgeNr+2)>>>NSHF][((this.gssEdgeNr+2)&MSK)] = 0;                     // remapping, used now for the level
            gssEdgeDir[(this.gssEdgeNr+3)>>>NSHF][((this.gssEdgeNr+3)&MSK)] = nt;
            this.gssEdgeNr += 4;
            // create embedded rule node
            symNode = this.gssEdgeNr;
            createRule = true;
            embeddedRule = true;
            lastRule = this.gssEdgeNr;
            ;
        } else {
            // check if it has the same rule
            // here check that the children are the same, and perhaps also the rule number.
            // - what would happen if the nonterminal has two rules that are different but have the
            //   same children? It would occur only if it has two identical rules

            ;

            // but here we check if there is a rule node with the same children, irrespectively on
            // whether they are children of a symbol node with the desired nt
            // There could be at the same level two rules with the same elements and different nt,
            // e.g. S ::= A | B; A = a; B = a;
            // To make the hash value different we add the nonterminal number

            hloop: for (int z = this.sppfrulehdir[hfunctrule];
                z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                if (this.edgeshdata[z-this.absLevelGssEdges] != symNode) continue;
                int ri = z - this.deltaEdges;
                if ((gssEdgeDir[(ri+1)>>>NSHF][((ri+1)&MSK)] & ELR_TREE_NT) != nt) continue;
                // flat forest encoding, with the len in the header
                int dlen = (gssEdgeDir[(ri+1)>>>NSHF][((ri+1)&MSK)] & ELR_TREE_LEN) >>> ELR_TREE_SHF;
                int end = ri + 2 + dlen;              // end of rule
                j = 0;
                if (dlen != len) continue hloop;
                for (int i = ri + 2; i < end; i++, j++){
                    int sppf1 = gssEdgeDir[(i)>>>NSHF][((i)&MSK)];
                    if (gamma[j] != sppf1) continue hloop;
                    /*
                    // the code here checks if the new one matches one that
                    // is already encoded. However, this should not occur because
                    // if there are trees to be added to the forest, the forest
                    // piece is not definitive, except that if the other is a rule
                    // node already encoded and we are trying to add an identical one
                    // this can spare a duplication
                    if ((gamma[j] & ELR_RN) != 0){           // etree
                        int nt1 = gamma[j] &~ ELR_RN;
                        if ((sppf1 & ELR_RN) != 0){          // already encoded tree
                            int nt2 = SPPFNT(sppf1);
                            if (this.etrees[nt2] != sppf1) continue hloop;  // not an etree
                            if (nt1 != nt2) continue hloop;
                        } else {
                            continue hloop;
                        }
                    } else {
                        continue hloop;
                    }
                    */
                }
                ;
                break doit;
            }
            // lastRule = symNode;

            // there is no such a child, create it
            createRule = true;
        } // doit
        int startrule = -1;
        if (createRule){
            ;
            lastRule = this.edgeshdata[symNode - this.levelEdgeGss - 4];
            if (!embeddedRule){                    // append it to the list for this symbol node
                gssEdgeDir[(lastRule)>>>NSHF][((lastRule)&MSK)] = this.gssEdgeNr | HEADSYM;
                // update the tail of rules in the entry relative to the top of symbol node
                this.edgeshdata[symNode - this.levelEdgeGss - 4] = this.gssEdgeNr;
                ;
                // enlarge blocks if no sufficient space available
                ;
                if (this.gssEdgeNr+len+2 > this.gssEdgeLength){
                    enlargeEdges(this.gssEdgeNr+len+2);
                }
            }
            int z = this.gssEdgeNr - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = z << 1;
                if (z < this.edgeshlink.length << 1){        // extend at least twice
                    newlen = this.edgeshlink.length << 1;
                }
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.sppfrulehdir[hfunctrule];  // insert at beginning
            this.sppfrulehdir[hfunctrule] = this.gssEdgeNr + this.deltaEdges;
            // set entry relative to the rule node
            this.edgeshdata[z] = symNode;
            ;

            ;
            startrule = this.gssEdgeNr;
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = HEADSYM;     // next rule
            this.gssEdgeNr++;
            int hdr = nt | (len << ELR_TREE_SHF) | ELR_TREE;
            gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = HEAD | hdr;
            this.gssEdgeNr++;
            ;
            for (int i = 0; i < len; i++){
                int sppf = gamma[i];
                gssEdgeDir[(this.gssEdgeNr)>>>NSHF][((this.gssEdgeNr)&MSK)] = sppf;
                this.gssEdgeNr++;
                ;
            }
        }
        ;
        return symNode;
    }

    /**
     * Deliver a string representing the specified GSS sppf.
     *
     * @param      sppf index of the start of the GSS sppf (i.e. not +4)
     * @return     string
     */

    private String gssSppfToString(int sppf){
        String str = "";
        int second = gssEdgeDir[(sppf+1)>>>NSHF][((sppf+1)&MSK)];
        if (second < 0){                    // symbol node
            int cover = gssEdgeDir[(sppf+1)>>>NSHF][((sppf+1)&MSK)] & ~HEADSYM;
            int nt = gssEdgeDir[(sppf+3)>>>NSHF][((sppf+3)&MSK)];
            int rule = gssEdgeDir[(sppf+4)>>>NSHF][((sppf+4)&MSK)] & ~HEADSYM;
            str += this.tab.gramSymToString(nt) + "/" + cover + " ->";
            for (int i = rule; i != 0; i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)] & ~HEADSYM){
                str += " " + i;
            }
        } else {                            // rule node
            int len = gssEdgeDir[(sppf+1)>>>NSHF][((sppf+1)&MSK)] & ~HEADF;
            int nt = len & ELR_TREE_NT;
            len = (len & ELR_TREE_LEN) >>> ELR_TREE_SHF;
            str += this.tab.gramSymToString(nt) + " ->";
            for (int i = 0; i < len; i++){
                int el = gssEdgeDir[(sppf+i+2)>>>NSHF][((sppf+i+2)&MSK)];
                str += " " + sToString(el,0,false);
            }
        }
        return str;
    }

    /**
     * Deliver a string representing the specified GSS sppf rule node.
     *
     * @param      r index of the GSS sppf rule node
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    protected String sppfRuleToString(int r, boolean full){
        int len = gssEdgeDir[(r+1)>>>NSHF][((r+1)&MSK)] & ~HEADF;
        int nt = len & ELR_TREE_NT;
        len = (len & ELR_TREE_LEN) >>> ELR_TREE_SHF;
        StringBuilder str = new StringBuilder();
        if (full){
            int link = gssEdgeDir[(r)>>>NSHF][((r)&MSK)] & ~HEADSYM;
            str.append(String.format("%d link: %d nt: %s len: %s elements:",
                r,link,this.tab.gramSymToString(nt),len));
        }
        for (int i = 0; i < len; i++){
            if (full || i > 0){
                str.append(' ');
            }
            int el = 0;
            el = gssEdgeDir[(r+i+2)>>>NSHF][((r+i+2)&MSK)];
            if (el == -1){           // invalid
                str.append("?");
            } else if (el < 0){               // token
                str.append(getLexeme(getLexNr(el)));
            } else if ((el & HEADF) != 0){    // already built
                el &= ~HEADF;
                str.append("*" + el);
            } else if ((el & ELR_RN) != 0){   // nullable nt
                int gp = el & ~ELR_RN;
                str.append(this.tab.gramSymToString(gp));
                str.append("e");
            } else {
                str.append(Integer.toString(el));
            }
        }
        return str.toString();
    }

    /**
     * Generate the final parse subforest for the specified nonterminal.
     *
     * @param    root nonterminal
     * @return   index of the subforest in the forest
     */

    int encodeEtree(int root){
        ;
        if (this.etrees[root] != 0){         // already done
            return this.etrees[root];
        }

        int loc = this.loc;
        int start = loc;

        int dp = 0;
        int qp = 0;
        this.encodequeue[qp++] = root;           // enqueue root
        this.etrees[root] = -1;
        while (dp != qp){                        // while queue not empty
            int i = this.encodequeue[dp++];      // dequeue
            ;
            this.etrees[i] = this.loc;           // remapping
            // the number of alternative trees is the same as the number of
            // distinct nonempty rn tails
            int[][] rntails = this.tablr.ntRnTails[i];
            ;
            int nrrn = rntails.length;

            // store then the symbol node if needed
            int ruleInSym = 0;
            if (nrrn > 1){
                ;
                loc = this.loc;
                this.loc += nrrn + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = nrrn | HEADSYM;
                ruleInSym = loc + 1;
            }
            // visit the rn tails now
            for (int j = 0; j < rntails.length; j++){
                int[] rntail = rntails[j];
                loc = this.loc;
                if (ruleInSym > 0){
                    this.tree[(ruleInSym)>>>NSHF][((ruleInSym)&MSK)] = loc;
                    ruleInSym++;
                }
                // reserve space in tree for rn tail
                int len = rntail.length;
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                int hdr = i | (len << ELR_TREE_SHF) | ELR_TREE | HEAD;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr;
                loc++;
                for (int k = 0; k < len; k++){
                    int el = rntail[k];
                    ;
                    if (this.etrees[el] > 0){              // e-nt already encoded
                        el = this.etrees[el] | HEAD;
                    } else if (this.etrees[el] == 0){
                        el &= ~ELR_RN;
                        // add it to queue to visit
                        ;
                        this.etrees[el] = -1;
                        if (qp >= this.encodequeue.length){
                            if (dp > 10){                   // shift down, if worth
                                System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                                qp -= dp;
                                dp = 0;
                            } else {                        // enlarge
                                this.encodequeue = Arrays.copyOf(this.encodequeue,this.encodequeue.length+100);
                            }
                        }
                        this.encodequeue[qp++] = el;        // enqueue it
                        el |= ELR_RN;
                    } else {
                        el |= ELR_RN;
                    }
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                }
            }
        }

        // scan the rule nodes stored above in the final parse tree and remap the references to
        // grammar nts to the ones in the parse tree
        ;

        for (int i = start; i < this.loc;){            // scan the tree
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            ;
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int len = h & ~HEADF;                  // length of phrase of derivation
                int nt = len & ELR_TREE_NT;
                len = (len & ELR_TREE_LEN) >>> ELR_TREE_SHF;
                i++;
                int end = i + len;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];                  // length of phrase of derivation
                    if ((el & HEADF) == HEAD){         // already set
                        el &= ~HEAD;
                    } else if ((el & ELR_RN) != 0){
                        ;
                        el = this.etrees[el & ~ELR_RN];
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                this.derNum++;
                this.eleNum += len;
            }
        }

        this.treeLen = this.loc;
        this.treeStart = start;

        return start;
    }

    /**
     * Visit the sppfs (a graph, mostly a dag) creating the nodes in the final forest
     * along with the visit while remembering the positions, and resolving references in
     * the second pass done on the final forest.
     *
     * @param    root nonterminal
     * @return   index of the subforest in the forest
     */

    int encodetree(int root){
        ;
        if (this.ruleptrs == null){
            this.ruleptrs = new int[20];
        }
        this.treeLen = this.loc;
        if ((root & HEADF) == HEAD){         // already done
            ;
            this.treeStart = root & ~HEADF;
            return root & ~HEADF;
        }
        // here we know that the rule derives the empty string because the cover is 0
        if (gssEdgeDir[(root-3)>>>NSHF][((root-3)&MSK)] == HEADSYM){        // empty rule
            int lhs = gssEdgeDir[(root-1)>>>NSHF][((root-1)&MSK)] & 0xfffffff;
            if (this.etrees[lhs] != 0){
                ;
                this.treeStart = this.etrees[lhs];
                return this.etrees[lhs];
            }
        }
        int loc = this.loc;
        int start = loc;

        int dp = 0;
        int qp = 0;
        if ((gssEdgeDir[(root-3)>>>NSHF][((root-3)&MSK)] & HEADTREE) == 0){  // not already encoded
            this.encodequeue[qp++] = root-4;     // enqueue root
        }
        while (dp != qp){                        // while queue not empty
            int i = this.encodequeue[dp++];      // dequeue
            ;

            // make sure that derivations for a same empty rule has one single instance in the
            // final parse tree
            if (gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)] == HEADSYM){        // empty rule
                int el = gssEdgeDir[(i+3)>>>NSHF][((i+3)&MSK)];
                int lhs = el & 0xfffffff;
                if (this.etrees[lhs] != 0){      // already encountered
                    ;
                    continue;
                } else {
                    ;
                }
            }

            int nrrules = 0;
            gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] = this.loc;                        // set it to consider allocated
            ;

            // I must allocate/copy the symbol node only if it has > 1 rules,
            // but I do not know it, and neither I know how many they are so as to allocate
            // the table of its rules. I first allocate/copy the rules and then the symbol
            // node, but I must remember somewhere the locations of the symbol nodes ... it
            // would had been better to link the rules in a list instead of having a table
            // of symbol nodes in the final parse tree.
            // But then all rules would have a field in them for the link, also the ones that
            // belong to symbol nodes that have only one rule.

            for (int j = i + 4; j != 0; j = gssEdgeDir[(j)>>>NSHF][((j)&MSK)] & ~HEADSYM){
                int len = gssEdgeDir[(j+1)>>>NSHF][((j+1)&MSK)] & ~HEADF;
                int nt = len & ELR_TREE_NT;
                len = (len & ELR_TREE_LEN) >>> ELR_TREE_SHF;
                ;
    
                // reserve space in tree for rule
                loc = this.loc;
                // save the start address of this rule node
                if (nrrules >= this.ruleptrs.length){
                    this.ruleptrs =  Arrays.copyOf(this.ruleptrs,nrrules << 1);
                }
                this.ruleptrs[nrrules++] = loc;
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = (len << ELR_TREE_SHF) | nt | ELR_TREE | HEAD;
                ;
                loc++;

                int startrule = loc;
                ;
                int elstart = j + 2;
                for (int k = j + 2; k < j + 2 + len; k++){
                    int el = gssEdgeDir[(k)>>>NSHF][((k)&MSK)];
                    ;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                    if (el == -1){
                        Trc.out.printf("invalid at: %d lev %d j %d i %d\n",k,this.level,j,i);
                    }
                    if ((el & HEADF) != 0) continue;       // token or already built
                    if ((el & ELR_RN) != 0){                // nullable nt
                        ;
                        continue;
                    }
                    if ((gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & HEADTREE) != 0){  // already built
                        continue;
                    }
                    if (gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)] != 0){
                        continue;
                    }

                    ;
                    gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)] = -1;  // mark
                    if (qp >= this.encodequeue.length){
                        if (dp > this.encodequeue.length/QUEUE_THRES_1){  // shift down, if worth
                            System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                            qp -= dp;
                            dp = 0;
                        } else {                        // enlarge
                            this.encodequeue = Arrays.copyOf(this.encodequeue,this.encodequeue.length+this.encodequeue.length/QUEUE_THRES_2);
                        }
                    }
                    this.encodequeue[qp++] = el-4;      // enqueue it
                }
            }
            // store then the symbol node
            if (nrrules > 1){
                ;
                // SPPFGSS(i+2) = this.loc;                // remap it to symbol node
                gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)] = this.loc;                // remap it to symbol node
                loc = this.loc;
                this.loc += nrrules + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = nrrules | HEADSYM;          // number of rules
                for (int j = 0; j < nrrules; j++){      // copy the rules
                    loc++;
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = this.ruleptrs[j];
                }
            }
        }

        // scan the rule nodes stored above in the final parse tree and remap the references
        // to symbol nodes in the edges blocks to the ones in the parse tree
        ;

        loc = this.loc;
        for (int i = start; i < loc;){                 // scan the tree
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int len = h & ~HEADF;                  // length of phrase of derivation
                int nt = len & ELR_TREE_NT;
                len = (len & ELR_TREE_LEN) >>> ELR_TREE_SHF;
                ;
                i++;
                int end = i + len;
                int elstart = i;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];
                    ;
                    if (el == -1){
                        Trc.out.printf("invalid at: %d\n",i);
                    }
                    if ((el & HEADF) == HEAD){          // already built
                        el &= ~HEAD;
                    } else if (el > 0 && (el & ELR_RN) != 0){     // nullable nt
                        nt = el & ~ELR_RN;
                        ;
                        if (this.etrees[nt] == 0){      // not already encountered
                            this.etrees[nt] = encodeEtree(nt);
                        }
                        el = this.etrees[nt];
                    } else if (el > 0){
                        ;
                        if ((gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & HEADTREE) != 0){     // already built
                            el = gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] & ~(HEADTREE | HEADSYM);
                        } else {
                            if (gssEdgeDir[(el-3)>>>NSHF][((el-3)&MSK)] == HEADSYM){        // empty rule
                                int lhs = gssEdgeDir[(el-1)>>>NSHF][((el-1)&MSK)] & 0xfffffff;
                                el = this.etrees[lhs];
                                // how can I be sure that it has already been encoded?
                                if (this.etrees[lhs] == 0){
                                    Trc.out.printf("!! encodetree ref empty %d\n",-this.etrees[lhs]);
                                    el = -this.etrees[lhs];
                                    el = gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)];
                                }
                                ;
                            } else {
                                el = gssEdgeDir[(el-2)>>>NSHF][((el-2)&MSK)];
                            }
                        }
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                this.derNum++;
                this.eleNum += len;
            }
        }

        this.treeLen = this.loc;
        this.treeStart = gssEdgeDir[(root-2)>>>NSHF][((root-2)&MSK)];               // not "start" when it has several rules
        ;

        // return start;
        return treeStart;
    }

    /**
     * Do ELR parsing.
     *
     * @return   state at the end of parsing, negated if the input is not recognized
     */

    // this is called with a gss that has one node with a frontier state

    private int parseELR(){
        int res = 0;
        int node = this.gssNodeNr - 1;       // the one with the frontier state
        ;
        int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES];
        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];           // its state
        node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        int startstate = gssNodeDir[(node)>>>NSHF][((node)&MSK)];      // the junction one
        ;
        this.LRstackBottom = this.gssEdgeNr;
        // initialize the stack with the node that starts the LR parsing
        ;
        pushLRstack(state,gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)]);
        for (;;){
            ;
            int nracts = this.tablr.LRbase[state];int acts = nracts + this.currentToken+this.tab.tokBase;nracts = this.tablr.LRcheck[acts] == nracts ? this.tablr.LRtable[acts] : 0;if (nracts> 0){nracts= 1;} else if (nracts < 0){acts= -nracts;nracts = this.tablr.LRtable[acts++];};
            if (nracts == 0){                 // no action
                // set the cursor in the input one token back because here we come with a token
                // that has been eaten, and is wrong, and the cursor is past to it
                this.lex.stream.reset();
                res = -1;
                break;
            }
            // of course, there is only one, otherwise the state would not be an isle one
            int act = this.tablr.LRtable[acts];

            if (act >= ParserLRTables.ISREDUCE){  // reduce
                int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
                int macsn = (act & ParserLRTables.MACMASK) + this.tablr.ntMacStart[nt];  // absolute mac state nr
                int derlen = this.tablr.derlen[macsn];
                boolean fixed = derlen >= 0;
                int reditem = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
                ;

                int startSpReduct = this.gssEdgeNr - 3;
                if (fixed){
                    // the reduction has fixed length, take fixed chunk
                    startSpReduct -= (derlen << 1) + derlen;
                } else {
                    // the length is not known, hop to find it
                    derlen = 0;
                    int[][] hops = this.tablr.stateHops;
                    int[] hopt = this.tablr.stateHopt;
                    int le = hops[state][reditem];
                    if (le >= 0){
                        for (le = hopt[le]; le >= 0;){
                            derlen++;
                            ;
                            startSpReduct -= 3;                       // previous stack frame
                            if (startSpReduct < this.LRstackBottom) break;
                            state = gssEdgeDir[(startSpReduct)>>>NSHF][((startSpReduct)&MSK)];
                            le = hops[state][le];
                            if (le < 0) break;
                            le = hopt[le];
                        }
                    }
                }
                int z = 0;
                ;
                z = encodeELRtree(nt,derlen,startSpReduct);
                this.gssEdgeNr -= derlen*3;          // pop the stack
                // now move from the exposed state with the reduced nonterminal
                int topstack = this.gssEdgeNr - 3;
                ;
                int lookback = gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)] & LRS_STATE_MASK;
                if (topstack < this.LRstackBottom){      // end of LR piece
                    int lrbase1= this.tablr.LRbase[startstate];int newState1 = this.tablr.LRcheck[lrbase1+nt] == lrbase1 ? this.tablr.LRtable[lrbase1+nt] : 0;;
                    ;
                    ;
                    this.gssEdgeNr = this.LRstackBottom;
                    if (((this.tablr.isFrontierStates[(newState1)>>>ParserTables.NSHIFTB] & (1 << (newState1& ParserTables.MASKB))) != 0)){
                        ;
                        pushLRstack(newState1,z);
                        state = newState1;
                        ;
                        continue;
                    }
                    this.LRtree = z | HEAD;
                    res = newState1;
                    break;
                }

                int lrbase2= this.tablr.LRbase[gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)]];int newState = this.tablr.LRcheck[lrbase2+nt] == lrbase2 ? this.tablr.LRtable[lrbase2+nt] : 0;;
                ;
                pushLRstack(newState,z);
                state = newState;
            } else {                            // shift
                this.level++;
                ;
                int z = 0;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = -1;
                    break;
                }
                z = saveToken(act);          // eof cannot be encoded
                int newState = act & ParserLRTables.STATEMASK;
                pushLRstack(newState,z);
                ;
                state = newState;
                this.currentToken = tokenizer();
                if (this.currentToken < 0){
                    res = -1;
                    break;
                }
            }
        }
        ;
        return res;
    }

    /**
     * Deliver a string representing the specified sppf of the LR stack.
     *
     * @param      sppf contents of a field that denotes a sppf
     * @return     string
     */

    private String lrsppfToString(int sppf){
        int su = sppf;
        if (su > 0){        
            if ((su & ELR_RN) == 0){      // not nullable nt
                su |= HEAD;               // make it already encoded
            }
        }
        return sToString(su,0,false);
    }

    /**
     * Trace the lr stack startng from the specified bottom.
     *
     * @param      stackBottom index of the start element to trace
     */

    protected void traceLRstack(int stackBottom){
        Trc.out.printf("stack");
        for (int i = stackBottom; i < this.gssEdgeNr; i += 3){
            Trc.out.printf(" %d:(%d,%d",i,gssEdgeDir[(i)>>>NSHF][((i)&MSK)],gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)]);
            int t = gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)];
            String s = lrsppfToString(t);
            Trc.out.printf(",%s)",s);
        }
        Trc.out.printf("\n");
    }

    /**
     * Encode the specified piece of the lr stack into the final forest.
     *
     * @param      nt nonterminal that is the root of the generated forest fragment
     * @param      derlen length of the derivation on the lr stack
     * @param      startSpReduct start index on the lr stack
     * @return     index in the final forest for the fragment generated
     */

    private int encodeELRtree(int nt, int derlen, int startSpReduct){
        ;
        // on the stack there are derlen values, each being a token or a derivation
 
        int befsp = startSpReduct+1;
        if (befsp > this.LRstackBottom &&
            gssEdgeDir[(befsp)>>>NSHF][((befsp)&MSK)] == this.level){           // empty yield
            ;
            ;
            if (this.etrees[nt] == 0){
                this.etrees[nt] = this.loc;
            } else {
                return this.etrees[nt];              // return already encoded e-tree
            }
        }

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = nt | (derlen << ELR_TREE_SHF) | ELR_TREE;
            newloc += derlen + 1;

            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;

            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr | HEAD;
            loc = newloc - 1;

            // visit the stack for this rule
            for (int i = this.gssEdgeNr - 3; i > startSpReduct; i -= 3){
                int val = gssEdgeDir[(i+2)>>>NSHF][((i+2)&MSK)];
                // store value
                if ((val & HEADF) == HEAD) val &= ~HEAD;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = val;                        // store value
                ;
                loc--;
            }
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeLen = newloc;
            this.treeStart = this.loc;
            this.loc = newloc;
        } // doit
        return start;
    }

    /**
     * Do ELR dynamic mode parsing.
     *
     * @return     >= 0: parsing successful, -1: LR parsing cannot be done,
     *             -2: internal error because of malformed GSS, -3: EOF detected
     */

    /* It is called when there is only one parser, that does not transit to a
     * frontier state, and that has a linear reduction.
     * It does not use the simplified lr stack, but the gss.
     * A fixed-length or a variable-length reduction can have several paths in the gss.
     * In this case the method fails, and the caller reverts to normal processing.
     * When there is only one path and the reduction is a fixed-length one the derivation
     * is unique even if there are several leftpointers in the chain.
     * When instead the reduction is variable-length one, the presence of several leftpointers
     * can lead to chains of different lengths. In such a case the method fails, and normal
     * processing is done.
     *
     * Since this is entered with a gss node whose only action is one for an item that
     * is a machine initial one, and then all nodes produced after have only one edge,
     * then it can make faster reductions since the gss would contain a linear sequence
     * of elements, much the same of a LR stack. There would be no need to hop in the case
     * of star, but that holds only for the topmost reduction because for it we would know
     * the start of the reduction, but not for the subsequent ones.
     */

    private int parseELRdyn(){
        int res = 0;
        int parser = this.gssNodeNr - 1;
        ;
        determin: {
            int state = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
            int nracts = this.tablr.LRbase[state];int acts = nracts + this.currentToken+this.tab.tokBase;nracts = this.tablr.LRcheck[acts] == nracts ? this.tablr.LRtable[acts] : 0;if (nracts> 0){nracts= 1;} else if (nracts < 0){acts= -nracts;nracts = this.tablr.LRtable[acts++];};
            ;

            if (nracts != 1){
                ;
                res = -1;
                break determin;
            }
            int act = this.tablr.LRtable[acts];
            if (act >= ParserLRTables.ISREDUCE){             // reduce
                int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
                int macsn = (act & ParserLRTables.MACMASK) + this.tablr.ntMacStart[nt];  // absolute mac state nr
                int m = (act & ParserLRTables.RULEFIXED) != 0 ? 0 : 1;
                int reditem = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
                if (((this.tab.cyclic[(nt)>>>ParserTables.NSHIFTB] & (1 << (nt& ParserTables.MASKB))) != 0)){
                    res = -1;
                    break determin;
                }
                ;
                int z = 0;
                int lookback = this.gssNodeNr - 1;

                int derlen = this.tablr.rnDerlen[macsn];
                if (derlen >= 0){             // fixed
                    // here it would be better to avoid to scan the path twice:
                    // here and in encode
                    int node = parser;
                    for (int i = 0; i < derlen; i++){
                        int edge = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES];
                        if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] != 0){
                            res = -1;
                            break determin;
                        }
                        lookback = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                    }
                } else {
                    derlen = 0;
                    state = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
                    int[][] hops = this.tablr.stateHops;
                    int[] hopt = this.tablr.stateHopt;
                    int le = hops[state][reditem];
                    if (le >= 0){
                        if (hopt[le+1] >= 0){    // there are several leftpointers
                            ;
                            res = -1;
                            break determin;
                        }
                        for (le = hopt[le]; le >= 0;){
                            derlen++;
                            int edge = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)+NODE_EDGES];
                            if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] != 0){
                                res = -1;
                                break determin;
                            }
                            lookback = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
                            state = gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)];
                            le = hops[state][le];
                            if (le < 0) break;
                            if (hopt[le+1] >= 0){    // there are several leftpointers
                                ;
                                res = -1;
                                break determin;
                            }
                            le = hopt[le];
                        }
                    }
                }
                ;

                // no need to treat the case of rule with rn tail: it has a conflict because
                // it has a reduction for the rule and others for the empty nts of the rn tail
                z = encodeELRdyntree(nt,derlen,this.gssNodeNr - 1);
                if (z < 0){
                    res = -1;
                    break determin;
                }
                ;
                // pop the levels
                if (lookback < this.levelGss){           // in a level before the current one
                    // find the end of the level
                    int startNodelev = lookback;
                    startNodelev--;
                    while (gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)] >= 0) startNodelev--; 
                    ;
                    int curNodeNr = this.gssNodeNr;
                    int curEdgeNr = this.gssEdgeNr;
                    this.gssNodeNr = -gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)];  // deallocate nodes
                    this.gssEdgeNr = gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)+NODE_EDGES];     // and edges
                    this.levelGss = this.gssNodeNr;
                    this.delta += curNodeNr - this.gssNodeNr;       // roll up total delta
                    this.absLevelGss = this.levelGss + this.delta;
                    this.levelEdgeGss = this.gssEdgeNr;
                    this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                    this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;

                    // adjust the sentinel
                    gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)] = -1;
                    ;
                } else {
                    // do not pop the current level: empty reduction
                }
                // create the new node
                int lrbase3= this.tablr.LRbase[gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)]];int newState = this.tablr.LRcheck[lrbase3+nt] == lrbase3 ? this.tablr.LRtable[lrbase3+nt] : 0;;
                ;
                int newNode = addNode(newState,lookback,z|HEAD,0);
                if (newNode < 0) newNode = -newNode;
                ;
                res = newNode;
            } else if (act > 0) {
                // can shift unambiguously
                makeSentinel();
                this.level++;
                ;
                ;
                this.levelGss = this.gssNodeNr;
                this.absLevelGss = this.levelGss + this.delta;
                this.levelEdgeGss = this.gssEdgeNr;
                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                int z = 0;
                if (this.currentToken != EOF) z = saveToken(act);  // eof cannot be encoded
                int newState = act & ParserLRTables.STATEMASK;
                int newNode = addNode(newState,parser,z,0);
                if (newNode < 0) newNode = -newNode;
                ;
                ;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = -3;
                    break determin;
                }
                // return to mainloop
                res = 0;
            }
        } // determin
        ;
        return res;
    }

    /**
     * Encode the derivation starting from the specified node collecting the trees of
     * each element and encoding the ones that are not yet so (instead of creating a node
     * with its sppf), which happens when the previous levels are not lr.
     *
     * @param     nt nonterminal of the derivation
     * @param     derlen length of the derivation
     * @param     rootnode index of the gss sppf to encode
     * @return    index in the final forest of the fragment generated
     */

    private int encodeELRdyntree(int nt, int derlen, int rootnode){
        ;
        // on the gss there is a linear path with n values, where n is the length of the derivation,
        // each being a token or a derivation

        // detect if it is an etree
        if (derlen == 0){
            ;
            if (this.etrees[nt] == 0){
                this.etrees[nt] = this.loc;
            } else {
                return this.etrees[nt];              // return already encoded e-tree
            }
        }

        // scan the derivation to build the etrees and the missing trees
        int node = rootnode;
        for (int i = 0; i < derlen; i++){
            int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES];
            int sppf = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
            if (sppf > 0 && (sppf & ELR_RN) != 0){     // nullable nt
                int lhs = sppf & ~ELR_RN;
                ;
                if (this.etrees[lhs] == 0){         // not already encountered
                    this.etrees[lhs] = encodeEtree(lhs);
                }
                gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)] = this.etrees[lhs] | HEAD;
                ;
            } else if ((sppf & HEADF) == 0){       // not yet encoded
                gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)] = encodetree(sppf) | HEAD;
                ;
            }
            node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        }

        int newloc = this.loc;
        int start = newloc;
        doit: {
            int hdr = (derlen << ELR_TREE_SHF) | nt | ELR_TREE | HEAD;
            newloc += derlen + 1;
            if (((newloc-1) >>> NSHF) >= this.treeBlocks){
                enlargeTree(newloc);
            }
            int loc = this.loc;
            // store header
            ;
            this.tree[(loc)>>>NSHF][((loc)&MSK)] = hdr;
            loc++;

            // visit the gss for this rule
            node = rootnode;
            for (int i = derlen-1; i >= 0; i--){
                int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES];
                int val = gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)];
                if ((val & HEADF) == HEAD) val &= ~HEAD;
                // store value            
                int l = loc + i;
                this.tree[(l)>>>NSHF][((l)&MSK)] = val;                  // store element
                ;
                node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
            }
            this.LRstackBottom = node;
            this.eleNum += newloc - start - 1;
            this.derNum++;
            this.treeLen = newloc;
            this.treeStart = this.loc;
            this.loc = newloc;
        } // doit
        ;
        return start;
    }

    /**
     * Measure the amount of memory used by all the data.
     * Trace also the occupation of each kind of data so as to spot if there is one
     * that is unusually large.
     *
     * @return     total amount
     */

    protected int dataSize(){
        int[] data = new int[50];
        int n = 0;
        data[n++] = arraySize(this.gssNodeDir);
        data[n++] = arraySize(this.gssEdgeDir);
        data[n++] = arraySize(this.reusablePaths);
        data[n++] = arraySize(this.pathIterator);
        data[n++] = arraySize(this.pathItems);
        data[n++] = arraySize(this.stater);
        data[n++] = arraySize(this.sppfer);
        data[n++] = arraySize(this.sppfsymhdir);
        data[n++] = arraySize(this.sppfrulehdir);
        data[n++] = arraySize(this.edgeshlink);
        data[n++] = arraySize(this.edgeshdata);
        data[n++] = arraySize(this.edgeshdir);
        data[n++] = arraySize(this.nodeshdir);
        data[n++] = arraySize(this.nodeshlink);
        data[n++] = arraySize(this.encodequeue);
        data[n++] = arraySize(this.etrees);
        data[n++] = arraySize(this.potter);
        data[n++] = arraySize(this.reduceWl);
        data[n++] = arraySize(this.encodetreestack);
        data[n++] = arraySize(this.ruleptrs);
        int res = 0;
        for (int i = 0; i < data.length; i++){
            res += data[i];
        }
        ;
        return res;
    }

}