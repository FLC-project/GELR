/*
 * @(#)CharsRow.java       1.0 99/02/19
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;

/**
 * The <code>CharsRow</code> class provides a means for referring to
 * character string slices.
 *
 * @author  Angelo Borsotti
 * @version 1.0   19 Feb 1999
 */

public class CharsRow implements Serializable, Cloneable {

    /**
     * The buffer holding the data.
     *
     * @serial
     */
    public char[] buffer;

    /**
     * The start offset of the data. 
     *
     * @serial
     */
    public int offset;

    /**
     * The number of data.
     *
     * @serial
     */
    public int length;

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = 8859343378606770873L;

    /** The empty row constant. */
    public static final CharsRow EMPTY = new CharsRow();

    /**
     * Construct a new <code>CharsRow</code> which refers to the
     * slice passed as argument.
     *
     * @param      arr array
     * @param      off offset
     * @param      len slice length
     */

    public CharsRow(char[] buf, int off, int len){
        this.buffer = buf;
        this.offset = off;
        this.length = len;
    }

    /**
     * Construct a new <code>CharsRow</code> which refers to the
     * array passed as argument.
     *
     * @param      arr array
     */

    public CharsRow(char[] buf){
        this.buffer = buf;
        this.offset = 0;
        this.length = buf.length;
    }

    /**
     * Construct a new <code>CharsRow</code> which refers to no
     * slice.
     */

    public CharsRow(){
    }

    /**
     * Clone this object.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        CharsRow t = null;
        try {
            t = (CharsRow)super.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * Determine if this row refers to the same slice as the specified object.
     * It delivers <code>true</code> when the argument is not <code>null</code>
     * and is a <code>CharsRow</code> object that refers to the same array,
     * with the same offset and length.
     *
     * @param   other the object to compare
     * @return  true if equal
     */

    public boolean equals(Object other){
        if (this == other) return true;
        if (other == null) return false;
        if (!(other instanceof CharsRow)) return false;
        CharsRow s = (CharsRow)other;
        if (this.buffer != s.buffer) return false;
        if (this.offset != s.offset) return false;
        if (this.length != s.length) return false;
        return true;
    }

    /**
     * Return the hashcode for this object.
     *
     * @return     hash code value
     */

    public int hashCode(){
        int h = System.identityHashCode(this.buffer) +
            this.offset + this.length;
	return h;
    }

    /**
     * Deliver a String with the contents of the referred slice.
     *
     * @return     string
     */

    public String toString(){
        if (this.buffer == null) return null;
        return String.valueOf(this.buffer,this.offset,this.length);
    }

    /**
     * Deliver an array with the contents of the referred slice.
     *
     * @return     array
     */

    public char[] toArray(){
        if (this.buffer == null) return null;
        char[] cb = new char[this.length];
        System.arraycopy(this.buffer,this.offset,cb,0,this.length);
        return cb;
    }
}
