/*
 * @(#)BufReader.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;

/**
 * The <code>BufReader</code> provides efficient buffered readers with
 * contiguous data in the window.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/**
 * This class provides:
 * <ul>
 * <li>limited random access streams on top of sequential streams with
 *   a restricted window of directly accessible data;
 * <li>non-endless streams (i.e. no data past the end-of-file);
 * <li>methods which are not synchronised to be efficient when that is
 *   not required.
 * <li>contiguous data in the window.
 * </ul>
 */

/* General
 *
 * The general skeme of a reader which supports backwards repositioning
 * into the stream is:
 * 
 *   - to load the buffer when reading
 * 
 *         if eof pending, return
 *         int freePos;
 *         if (markPos < 0){                         // no mark set
 *             freePos = 0;
 *         } else {                                  // mark set
 *             int markedZone = pendPos - markPos;
 *             if (markedZone >= saveLimit){         // beyond limit
 *                 ... error
 *             } else {
 *                 if (saveLimit <= buffer length){  // space for saveLimit present
 *                     ... shift saved data to start
 *                     markPos = 0;
 *                     freePos = markedZone;
 *                 } else {                          // not enough
 *                     ... allocate more buffers
 *                     markPos = 0;
 *                     freePos = markedZone;
 *                 }
 *                 pendPos = markedZone;
 *                 maxPos = markedZone;
 *             }
 *         }
 *         n = ... load data
 *         if an eof found, pendingEof = true;
 *         pendPos = freePos;
 *         maxPos = freePos + n;
 * 
 *    - to deliver characters
 * 
 *         int read(char[] buf, int off, int len){
 *             int n = 0;
 *             do {
 *                 if (pendPos >= maxPos){     // no pending chars
 *                     ... load buffer
 *                 }
 *                 if (pendPos >= maxPos){
 *                     n = -1;
 *                     break;
 *                 }
 *                 int piece = maxPos - pendPos;
 *                 if (len - n < piece) piece = len - n;
 *                 .. move piece data from pendPos
 *                 pendPos += piece;
 *                 if (piece <= 0) break;
 *                 if ((n >= len) || !in.ready()) break;
 *                 n += piece;
 *             } while (true);
 *             return n;
 *         }
 * 
 *    - to mark:
 * 
 *         markPos = pendPos;
 * 
 *    - to reposition (reset)
 * 
 *         if (markPos < 0){  // no mark was set
 *             ...
 *         } else {
 *             pendPos = markPos;
 *         }
 *
 * The buffer is implemented here as a resizable array containing a block
 * of data. This implies resizing when it is not large enough and moving
 * data when refilling it. When the width of the window is small, resizing
 * occurs seldom and the time spent in moving data is lower than that
 * spent in handling strings which cross blocks.
 * Resizing is done by exdending its size with another block.
 * To read a block each time (which spares deblocking), the size of the
 * buffer is that of a block plus half the average of the amount of saved data.
 * When no space is available to read a block, the buffer is resized to hold it.
 * Note that this is different from what java.io.BufferedReader does, which
 * resizes it to hold as many data as the limit. This allows to spare some
 * resizing, but does not allow to support unlimited buffering. Moreover,
 * it allocates space on the hope that it will be used, which is not the case
 * when the limit is set to a large value to protect against extra large
 * buffering which can occur in erroneous cases.
 *
 * This is a picture of the buffer:
 *
 *                saved       pending      free
 *     |......mmmmmmmmmmmmmmmccccccccccccc.......|   buffer
 *            |              |            |       |
 *            markPos        pendPos      maxPos  buffer.length
 *
 * At the beginning there can be some data which have already been delivered
 * and processed. After them, there are the saved data.  At the end there
 * are the data which have not yet been delivered: they are the ones which
 * are delivered if a read() operation is done.
 * The buffer is partially filled when the stream is ended or when it has
 * delivered less data than requested when loading the buffer.
 * Note that BufReader data contiguous, but may move them in the buffer.
 * Callers, like e.g. lexical methods, must transpose all the values of
 * indexes they have got before making a readblock() when they need to
 * operate them with values of indexes they get after a readblock().
 * The amount of traslation is the difference between markPos before and
 * after the execution of readblock().
 * Alternatively, they can keep offsets relative to the marked position,
 * which do not change after a readblock().
 *
 * Wrapped types
 *
 * This class wraps Readers, IoStreams, Strings and char[]. The latter
 * is handled by accessing data directly when a read() is done.
 * Strings are buffered so as to allow direct access to data in all cases.
 * If an array is wrapped, no buffer is ever used.
 * To avoid loading classes of wrapped types which are not used, which
 * is not the case when an Object reference is kept and the type of the
 * referred object tested by means of instanceof, its type is kept in
 * the field kind, and the Obejct reference casted to the actual one
 * (casts which are not executed do not cause the casted class to be loaded).
 *
 * To avoid buffering at several levels of wrapping, the buffered reader
 * reads in blocks.  This allow to keep data move between levels of wrapping
 * at a minimum.  This allows to wrap it with another buffered reader
 * efficiently.
 *
 * The EOF
 *
 * Java.io.BufferedReader when collects data, if it finds an eof it stops and
 * delivers what it has got. Since it does not remember that it has got an eof,
 * the next time it makes another read. This is not seen on a disk file, but it
 * is on a terminal, for which there is a need to enter several ^D.
 * This example shows the problem:
 * 
 *     BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
 *     char[] buf = new char[80];
 *     try {
 *        for (;;){
 *           String line = br.readLine();
 *           if (line == null){
 *               Trc.out.println("EOF");
 *               break;
 *           }
 *           Trc.out.println("line: " + line);
 *        }
 *     } catch (IOExceptions th){
 *     }
 * 
 * When it is run, and a line ended with ^D (in Unix), there is a need to enter
 * two ^D more to make the BufferedReader deliver an EOF.
 * The problem occurs because readLine(), seeing that no data are available,
 * loads the buffer. This is done by reading characters from the terminal.
 * Suppose that characters are entered and terminated with ^D. The characters
 * are delivered, but no indication is returned to readLine() on the fact that
 * the line was ended by an EOF. Alas. The characters are scanned for a \n,
 * which is not found, and thus a second load is done. Suppose a ^D alone
 * is entered now (which is the correct way to indicate an EOF). Now readLine()
 * detects it, and returns the line read, but it does not remember that an
 * eof has been read. Since a line has been got, the loop is iterated again,
 * and readLine() entered. Since it does not remember that it read an eof,
 * it makes another read(), which requires a third ^D.
 * 
 * Now, this problem does not occur with read(buf,off,len) because after
 * the a first load which does not get all the requested characters (as the
 * one in readLine() did not), a second one is not executed, being preceded
 * by a inp.ready(), which returns false (since there are no characters
 * available). This results in returning less characters than requested.
 * At the next read(), a load is done again, which detects the eof.
 * In order not to rely on this mechanism which seems a bit weak, load()
 * remembers the eof which it has got, and the next time it returns immediately
 * without attempting another read.
 *
 * Even if a buffered reader has space to read ahead data, to keep the
 * semantics of the eof the standard one, i.e. that it is known after a
 * read operation only, no read ahead is done. Read operations return
 * an indication that an eof has been encountered.
 *
 * A read with a request of zero chararcters delivers a -1 when the stream
 * is at the end of file. This keep consistent the semantics of the read
 * operation, which in all cases delivers an eof when the stream is placed
 * at the end. This also makes the read operation of zero characters useful
 * to test whether the stream is at the end without eating any data.
 * It cannot be implemented in an unbuffered reader since to know if the
 * stream is really ended, a read of at least one character must be done,
 * but that reader has no space to save it (and not loose it).
 *
 * Endless streams are not supported. The recognizion of the eof is difficult
 * for them, while this class is used for scanning, for which the detection
 * of the eof is useful.
 *
 * The index
 *
 * The index represents the ordinal number of data considering the stream
 * as made by the characters which have been read (i.e. if any change in
 * the actual file occurs which are not seen by what is read, that change
 * is not taken into account by the index.
 * The index is the number of the character which would be read by the next
 * read() operation.
 * To compute it, it is sufficient to roll up all the data read, and update
 * it when a reset() is done.
 * To know the index of the first character transferred by a read() operation,
 * the value of the index should be taken before.
 * The index of a character at offset "off" in the buffer can be computed
 * as: this.index - end + off.
 *
 * Errors
 *
 * After an operation which has caused an error, the stream may still be
 * used by making correct requests.
 *
 * There is a need to let the caller understand which error occurred.
 * This is done by testing the error code.
 * Indexes out of range, including reset when mark is not set result in
 * an IndexOutOfBoundsException.
 * This to keep is as close as possible to a BufferedReader and keeping
 * it consistent.
 * Note that all IndexOutOfBoundsException here denote programming errors.
 * Java BufferedReader throws IOException when the stream is not open
 * and when a reset is done with no mark, which makes then difficult
 * to distinguish real io errors from programming errors.
 * Since exceptions inhibit the passing of return values, nothing is
 * returned when, e.g. a read() is made for a number of characters that
 * makes the limit exceed; an exception is thrown no matter how many the
 * characters that would have been read are.
 *
 * Termination
 *
 * BufReader objects which had been closed may not be reused since in a
 * previous use they could have wrapped a char[] and have the buffers
 * mapping it. There would be a need to allocate a buffer when they would
 * then wrap something else. Since this is not much useful, it is not
 * implemented.
 *
 * The save limit
 *
 * The purpose of a limit is twofold: to specify the minimum number of data
 * that the reader guarantees to retain, and conversely the maximum number
 * of data that the reader should guarantee.  It serves mainly to guarantee
 * that the reader does not allocate too much memory.
 * A reader can hold more data than the limit, but if it is implemented well
 * it does not hold much more.
 * This semantics allows to build readers which wrap strings and arrays
 * mapping them all at once and never issuing errors.
 * Read() issues an error only after having passed by the limit, i.e.,
 * when it can not guarantee the success of a reset(). This allows
 * to read a block when the limit has not yet been passed, which would be
 * a legal operation even if it could read more characters than the requested
 * ones.
 * This means also that applications which use a reader without errors
 * continue to do so even when they enlarge the block size of the reader.
 *
 * Note that this is different from jav.io.BufferedReader. In the latter,
 * when that many characters have beed read and the mark is in effect,
 * a reset() might return an error. I.e. sometimes it does, and sometimes not.
 * Here it is the read() which returns an error when the limit has been
 * passed.
 * BufferedReader lets the user read past the limit (sometimes) and rejects
 * a reset(). It is then up to the user to rekon the data read so as not
 * to make a reset() when it is too late. It is preferable to be more sure
 * about what can be done: if a read() returns success, then a reset()
 * should also succeed.
 *
 * The semantics of read(row) is that it returns a row to a buffer large
 * as the configured size, but when the reader wraps a char[], the buffer
 * could also be larger.  It would be meaningless to let it return an
 * error when a limit is set and the array is larger than it.
 *
 * To allow to make a correct read() after one which has requested more
 * data than the limit and has returned an error, when such an error is
 * detected, read() does not return any character (i.e. it restores the
 * pending position to the value it had upon entry) and it does not move
 * the index.
 *
 * Pushback
 *
 * A BufReader acts as a pushback reader which reads data from the uderlying
 * stream in blocks to avoid deblocking and is able to "unread" data by
 * repositioning back in the stream.
 * Note that a pushback reader is able to accept also data which have not been
 * got from the stream. This, however, makes difficult to reconstruct the
 * input with the inserted characters should there be a need to process
 * it again, like e.g. when a listing needs be produced.
 *
 * Sequence of files
 *
 * A buffered reader concatenates the data which it reads from a sequence
 * of files. Even if it would not deliver data belonging to two files
 * when requested to delivers a block, it would effectively concatenate
 * them when a mark is in effect.
 */
       
public class BufReader extends Reader {

    /** The input stream. */
    private Object inp;

    /** The kind of input stream. */
    protected int kind;

    /** The Reader stream kind. */
    protected static final int INP_READER = 0;

    /** The IoStream stream kind. */
    protected static final int INP_IOSTREAM = 1;

    /** The String stream kind. */
    protected static final int INP_STRING = 2;

    /** The char[] stream kind. */
    protected static final int INP_CHARS = 3;

    /** The average size of half the saved data. */
    static int EXTRA_SIZE = 64;

    /** The size of the buffer. */
    static int BUFF_SIZE = 2048;

    /** The marked position. */
    public int markPos = -1;

    /** The pending position. */
    protected int pendPos;

    /** The maximum position. */
    protected int maxPos;

    /** The index. */
    public long index;

    /** The limit on the characters saved. */
    private int saveLimit = Integer.MAX_VALUE;

    /** Whether an eof is pending. */
    private boolean pendingEof;

    /** Whether the last read operation detected an eof. */
    private boolean atEof;

    /** The reference to the buffer. */
    public char[] buffer;

    /** The index in the buffer. */
    /* Note that it is not the same as pendPos since it is the start
     * of the block after a readBlock(), while pendPos is the end, being
     * the data in the block considered as delivered.
     */
    public int cursor;

    /** The end index in the buffer. */
    /* It has the same value as maxPos. It is kept to provide an API
     * which is the same as that of other classes.
     */
    public int end;

    /** The read index when wrapping Strings. */
    private int strIndex;

    /** The maximum read index when wrapping Strings. */
    private int strEnd;

    /** The filespec of the stream for error reporting (implcit for IoStream). */
    public String path;

    /** The trace flags. */
    private int trc;

    /** The out of memory error. */
    private static int ERR_NOCORE = 1;

    /** The io error. */
    private static int ERR_IOERR = 2;

    /** The file not open error. */
    private static int ERR_NOTOPEN = 3;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   input operations trace
     *    b   input operations detail
     * </pre></blockquote><p>
     */

    private static final int FL_A = 1 << ('a'-0x60);
    private static final int FL_B = 1 << ('b'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a buffered reader.
     */

    public BufReader(){
        this.buffer = new char[BUFF_SIZE + EXTRA_SIZE];
    }

    /**
     * Construct a buffered reader on the specified stream and with
     * the specified buffer size (rounded to the next higher power of 2).
     *
     * @param      in stream
     * @param      bs buffer size
     */

    public BufReader(Object in, int size){
        int blockBits = 0;                // determine index of highest bit
        int s = size;
        do {
            s >>>= 1;
            blockBits++;
        } while (s != 0);
        blockBits--;
        int blockSize = 1 << blockBits;
        if (blockSize < size){
            blockBits++;
            blockSize = 1 << blockBits;
        }
        BUFF_SIZE = blockSize;
        if (blockSize <= 8){              // for testing
            EXTRA_SIZE = 4;
        }
        this.inp = in;
        if (!(in instanceof char[])){
            this.buffer = new char[BUFF_SIZE + EXTRA_SIZE];
        }
        if (in instanceof String){        // classes already loaded first
            this.kind = INP_STRING;
            this.strEnd = ((String)in).length();
        } else if (in instanceof char[]){
            this.buffer = (char[])in;
            this.maxPos = this.buffer.length;
            this.kind = INP_CHARS;
        } else if (in instanceof Reader){
            this.kind = INP_READER;
        }
    }

    /**
     * Construct a buffered reader on the specified stream and with
     * the specified buffer size (rounded to the next higher power of 2).
     *
     * @param      in stream
     * @param      off offset in input, if string
     * @param      len of input, if string
     * @param      bs buffer size
     */

    public BufReader(Object in, int off, int len, int size){
        this(in,size);
        switch (this.kind){
        case INP_STRING:
            String s = (String)this.inp;
            if ((off < 0) || (len < 0) || ((off + len) < 0) ||
                ((off + len) > s.length())){
                throw new IndexOutOfBoundsException();
            }
            this.strIndex = off;
            this.strEnd = off + len;
            break;
        case INP_CHARS:
            char[] arr = (char[])this.inp;
            if ((off < 0) || (len < 0) || ((off + len) < 0) ||
                ((off + len) > arr.length)){
                throw new IndexOutOfBoundsException();
            }
            this.pendPos = off;
            this.maxPos = off + len;
            break;
        }
    }

    /**
     * Construct a buffered reader on a Reader.
     *
     * @param      in reader
     */

    public BufReader(Reader in){
        this();
        this.inp = in;
        this.kind = INP_READER;
    }

    /**
     * Construct a buffered reader on a String.
     *
     * @param      in string
     */

    public BufReader(String in){
        this();
        this.inp = in;
        this.kind = INP_STRING;
        this.strEnd = in.length();
    }

    /**
     * Construct a buffered reader on an array of characters.
     *
     * @param      in array
     */

    public BufReader(char[] in){
        this.buffer = in;
        this.maxPos = in.length;
        this.inp = in;             // otherwise, stream is not open
        this.kind = INP_CHARS;
    }

    /**
     * Trace this object.
     */

    public void trace(){
        if (this.kind <= INP_STRING){
            Trc.out.print("buffer: |");
            Trc.literalize(buffer);
            Trc.out.println("|");
        }
        Trc.out.println(
            "mark: " + this.markPos +
            " pend: " + this.pendPos +
            " max: " + this.maxPos +
            " strIndex: " + this.strIndex +
            " strEnd: " + this.strEnd);
        Trc.out.println(
            "index: " + this.index +
            " limit: " + this.saveLimit +
            " pendingEof: " + this.pendingEof +
            " atEof: " + this.atEof +
            " kind: " + this.kind);
        Trc.out.println(
            "cursor: " + this.cursor +
            " end: " + this.end);
    }

    /**
     * Set the limit to the amount of saved characters.
     * The limit is inclusive: an attempt to read a number of characters
     * which is greater or equal to <code>n</code> delivers an error.
     * Setting a limit has effect from then onwards: i.e. if the (new)
     * limit exceeds the number of characters already saved, no error occurs
     * as a result of <code>setLimit()</code> or <code>mark()</code>, but
     * it does at the first <code>read()</code>.
     *
     * @param      n limit, no limit if negative
     */

    public void setLimit(int n){
        if (n >= 0) this.saveLimit = n;
        else this.saveLimit = Integer.MAX_VALUE;
    }

    /**
     * Make a consistency check on the values contained in this object.
     *
     * @param      str string representing the caller
     */
    private void check(String str){
    }

    /**
     * Trow an error.
     *
     * @param      code error code
     * @param      exc exception
     */

    private void error(int code, Throwable exc){
        throw new IOError(exc);
    }

    /**
     * Load a block of characters into the buffer.
     *
     * @returns    <code>true</code> when the limit has not caused an error
     */

    private boolean load(){
        if ((FL_B & this.trc) != 0){
            Trc.out.println(
                "load mark: " + this.markPos +
                " pend: " + this.pendPos +
                " max: " + this.maxPos +
                " pendingEof: " + this.pendingEof);
        }
        if (this.pendingEof) return true;
        int freePos;                            // write position in buffer
        if (this.markPos < 0){                  // no mark set, fill it
            freePos = 0;
        } else {                                // mark set
            int markedZone =
                this.pendPos - this.markPos;
            if (markedZone >= this.saveLimit){  // beyond limit
                return false;
            }
            char buf[] = this.buffer;
            if (this.buffer.length -            // resize buffer
                markedZone < BUFF_SIZE){
                int newlen = this.buffer.length + BUFF_SIZE;
                if (newlen < 0){
                    error(ERR_NOCORE,null);
                }
                if ((FL_A & this.trc) != 0){
                    Trc.out.println("buffer extended to: " + newlen);
                }
                try {
                    this.buffer = new char[newlen];
                } catch (OutOfMemoryError exc){
                    this.buffer = null;
                    error(ERR_NOCORE,exc);
                }
            }
            if (markedZone > 0){                // move saved piece at beginning
                System.arraycopy(buf,this.markPos,
                    this.buffer,0,markedZone);
            }
            freePos = markedZone;
            this.pendPos = freePos;
            this.maxPos = freePos;
            this.markPos = 0;
        }
        int n = 0;
        do {                                    // load block
            switch (this.kind){
            case INP_READER:
                try {
                    n = ((Reader)(this.inp))
                        .read(this.buffer,freePos,BUFF_SIZE);
                } catch (IOException exc){
                    error(ERR_IOERR,exc);
                }
                break;
            case INP_STRING:
                String s = (String)(this.inp);
                if (this.strIndex == this.strEnd){
                    n = -1;
                    break;
                }
                n = this.strEnd;
                if (n - this.strIndex > BUFF_SIZE){
                    n = this.strIndex + BUFF_SIZE;
                }
                s.getChars(this.strIndex,n,
                    this.buffer,freePos);
                n -= this.strIndex;
                this.strIndex += n;
                break;
            }
            if (n < 0) this.pendingEof = true;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("loaded: " + n);
            }
        } while (n == 0);                       // no data, retry
        if (n > 0){
            this.pendPos = freePos;
            this.maxPos = freePos + n;          // no overflow here
        }
        if ((FL_B & this.trc) != 0){
            Trc.out.println("load end:");
            trace();
        }
        return true;
    }

    /**
     * Read characters into an array.  If a limit has been set on the
     * amount of saved characters, an attempt to exceed that limit
     * may result into an error. However, if the operation completes
     * successfully, a <code>reset()</code> will also succeed.
     * Note that an eof is returned in all cases (even when <code>len</code>
     * is zero) when the stream is at the end.
     *
     * @param      buf reference to the array
     * @param      off offset in it
     * @param      len number of characters requested
     * @returns    number of data read, -1 if eof
     */

    /* When an error occurs because of the saving of an amount of data
     * which exceeds the limit, the reader is restored to a state which
     * allows to process correct requests. Since a load() could have
     * be executed, which has moved the saved piece at the beginning of
     * the buffer, it is not possible to restore pendPos to the value
     * it had upon entry. It is restored to the end of the saved zone
     * instead.
     */

    public int read(char[] buf, int off, int len){
        boolean err = false;
        if ((FL_A & this.trc) != 0){
            Trc.out.println("read " + len + " chars");
        }
        if ((off < 0) || (len < 0) || ((off + len) < 0) ||
            ((off + len) > buf.length)){
            throw new IndexOutOfBoundsException();
        }
        if (this.inp == null) error(ERR_NOTOPEN,null);
        int n = 0;
        int start = 0;
        if (this.markPos >= 0){
            start = this.pendPos - this.markPos;
        }
        loop: do {
            if (this.atEof){                    // already at eof
                n = -1;
                break loop;
            }
            int piece = 0;
            get: {
                fill: if (this.pendPos >= this.maxPos){   // no pending chars
                    if (this.kind >= INP_CHARS){          // no more
                        if (n == 0) n = -1;               // eof only if none
                        break;
                    }
                    if ((this.markPos < 0) &&             // no mark
                        ((len - n) >= BUFF_SIZE)){        // direct read in array
                        if (this.pendingEof) break fill;
                        switch (this.kind){
                        case INP_READER:
                            try {
                                piece = ((Reader)(this.inp))
                                    .read(buf,off + n,len - n);
                            } catch (IOException exc){
                                error(ERR_IOERR,exc);
                            }
                            break;
                        case INP_STRING:
                            String s = (String)(this.inp);
                            if (this.strIndex == this.strEnd){
                                piece = -1;
                                break;
                            }
                            piece = this.strEnd;
                            if (piece - this.strIndex > len - n){
                                piece = this.strIndex + len - n;
                            }
                            s.getChars(this.strIndex,piece,
                                buf,off + n);
                            piece -= this.strIndex;
                            this.strIndex += piece;
                            break;
                        }
                        if ((FL_B & this.trc) != 0){
                            Trc.out.println("direct read: " +
                                piece + " " + (off + n) + " " +
                                (len - n));
                        }
                        if (piece <= 0){              // no data obtained
                            this.pendingEof = true;
                            if (n == 0) n = -1;       // eof only if none
                            break;
                        }
                        break get;
                    }
                    if (!load()){                     // load buffer
                        err = true;
                        break loop;
                    }
                }
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("read move data");
                    trace();
                }
                piece = this.maxPos - this.pendPos;
                if (piece <= 0){                      // no data obtained
                    if (n == 0) n = -1;               // eof only if none
                    break;
                }
                if (len - n < piece) piece = len - n; // no more than requested
                System.arraycopy(this.buffer,
                    this.pendPos,buf,off + n,piece);  // move into user buf
                this.pendPos += piece;                // advance pending pos
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("moved pend: " +
                        this.pendPos + " mark: " +
                        this.markPos);
                }
            } // get
            n += piece;
            switch (this.kind){
            case INP_READER:
                try {
                    if (!((Reader)(this.inp)).ready()) break loop;
                } catch (IOException exc){
                    error(ERR_IOERR,exc);
                }
                break;
            case INP_STRING: break;
            case INP_CHARS: break loop;               // all data already got
            }
        } while (n < len);
        if (!err){
            if (n > 0) this.index += n;               // update index
            if (n < 0) this.atEof = true;
        } else {
            this.pendPos = this.markPos + start;      // restore initial state
            n = 0;
        }
        check("read");
        if ((FL_A & this.trc) != 0){
            Trc.out.print("read: |");
            Trc.literalize(buf,off,n);
            Trc.out.println("| " + n + " chars, err: " +
                err + " index: " + this.index);
        }
        if (err) throw new IndexOutOfBoundsException();
        return n;
    }

    /**
     * Deliver a reference to a slice of characters which lies at the
     * current index.  If they are in the buffer, a reference to them is
     * returned, otherwise they are read in the buffer first.
     * If a limit has been set on the amount of saved characters, an attempt
     * to exceed that limit may result into an error. However, if the
     * operation completes successfully, a <code>reset()</code> will also
     * succeed.
     * The reference to the buffer is <code>buffer</code>, the index of
     * the first delivered character in it is <code>cursor</code>, and
     * the index of the character past the last is <code>end</code>.
     *
     * @return     number of delivered characters, -1 if eof
     */

    public int readBlock(){
        boolean err = false;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("readBlock");
            trace();
        }
        if (this.inp == null) error(ERR_NOTOPEN,null);
        int n = 0;
        int piece = 0;
        int start = 0;
        if (this.markPos >= 0){
            start = this.pendPos - this.markPos;
        }
        this.cursor = this.pendPos;
        this.end = this.pendPos;
        get: {
            if (this.atEof){                    // already at eof
                n = -1;
                break get;
            }
            if (this.pendPos >= this.maxPos){   // no pending chars
                if (this.kind >= INP_CHARS){    // no more
                    n = -1;
                    break get;
                }
                if (!load()){                   // load buffer
                    err = true;
                    break get;
                }
                this.cursor = this.pendPos;
                this.end = this.pendPos;
            }
            if ((FL_B & this.trc) != 0){
                Trc.out.println("read seek data");
                trace();
            }
            piece = this.maxPos - this.pendPos;
            if (piece <= 0){                    // no data obtained
                if (n == 0) n = -1;             // eof only if none
                break get;
            }
            switch (this.kind){
            case INP_READER:
            case INP_STRING:
                this.cursor = this.pendPos;
                this.end = this.maxPos;
                break;
            case INP_CHARS:                     // map slice
                this.cursor = this.pendPos;
                this.end = this.maxPos;
                break;
            }
            this.pendPos += piece;              // update pending position
            if ((FL_B & this.trc) != 0){
                Trc.out.println("pend: " +
                    this.pendPos + " mark: " +
                    this.markPos);
            }
        }
        if (!err){
            n += piece;
            if (n > 0) this.index += n;            // update index
            if (n < 0) this.atEof = true;
        } else {
            this.pendPos = this.markPos + start;   // restore initial state
            n = 0;
        }
        check("read");
        if ((FL_A & this.trc) != 0){
            Trc.out.print("read: |");
            Trc.literalize(this.buffer,this.cursor,this.end-this.cursor);
            Trc.out.println("| " + n + " chars, err: " +
                err + " index: " + this.index);
        }
        if (err) throw new IndexOutOfBoundsException();
        return n;
    }

    /**
     * Copy saved data into a user buffer.  A mark must have been
     * set before. The requested characters must not exceed the
     * saved ones.
     *
     * @param      pos relative position of data ahead of the first saved one
     * @param      buf reference to the buffer
     * @param      off offset in it
     * @param      len number of characters requested
     */

    public void copy(int pos, char[] buf, int off, int len){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("copy from: " + pos + " len: " + len);
            trace();
        }
        if ((off < 0) || (len < 0) || ((off + len) < 0) ||
            ((off + len) > buf.length)){
            throw new IndexOutOfBoundsException();
        }
        if (this.markPos < 0){          // no mark was set
            throw new IndexOutOfBoundsException();
        }
        pos = this.markPos + pos;       // actual position
        if (pos < 0){
            throw new IndexOutOfBoundsException();
        }
        if ((pos < this.markPos) ||     // pos is not in it
            (this.pendPos < pos)){
            throw new IndexOutOfBoundsException(); 
        }
        int end = pos + len;
        if ((end < 0) || (this.pendPos < end)){
            throw new IndexOutOfBoundsException();
        }
        System.arraycopy(this.buffer,pos,buf,off,len);
    }

    /**
     * Copy saved data into a user buffer without making any checks.
     * A mark must have been set before. The requested characters must
     * not exceed the saved ones.
     *
     * @param      pos relative position of data ahead of the first saved one
     * @param      buf reference to the buffer
     * @param      off offset in it
     * @param      len number of characters requested
     */

    public void getChars(int pos, char[] buf, int off, int len){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("getChars: " + pos + " " + len);
            trace();
        }
        System.arraycopy(this.buffer,this.markPos + pos,buf,off,len);
    }

    /**
     * Set the mark to the specified number of characters before
     * the index and set the limit. If no mark is set before calling,
     * the mark can only be set at the index position, otherwise to any
     * position between the marked one and the index one.
     *
     * @param      lim limit of characters to read, negative if no limit
     * @param      pos position relative to the index
     */

    /* Since the caller is not aware of positions except the marked
     * one and the current one (the index), the position argument
     * is relative to the index, which is always defined even when there
     * is no mark.  Note that <code>mark()</code> sets the mark at the
     * index.
     */

    public void mark(int lim, int pos){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("mark " + lim + " at: " + pos);
            trace();
        }
        pos = this.pendPos - pos;          // actual position
        if (pos < 0){
            throw new IndexOutOfBoundsException();
        }
        if (this.inp == null) error(ERR_NOTOPEN,null);
        if (this.markPos < 0){             // no mark was set
            if (pos != this.pendPos){
                throw new IndexOutOfBoundsException();
            }
        } else {
            if ((pos < this.markPos) ||
                (this.pendPos < pos)){
                throw new IndexOutOfBoundsException();
            }
        }
        this.markPos = pos;
        if (lim < 0) lim = Integer.MAX_VALUE;
        this.saveLimit = lim;
        check("mark");
        if ((FL_A & this.trc) != 0){
            Trc.out.println("mark done");
            trace();
        }
    }

    /**
     * Mark the position at the index and set the limit.
     *
     * @param      lim limit of characters to read, negative if no limit
     * @exception  IOException
     */

    public void mark(int lim){
        mark(lim,0);
    }

    /**
     * Mark the position at the index.
     */

    public void mark(){
        mark(this.saveLimit,0);
    }

    /**
     * Remove the mark, if any.
     */

    public void unmark(){
        if (this.inp == null) error(ERR_NOTOPEN,null);
        this.markPos = -1;
        check("unmark");
        if ((FL_A & this.trc) != 0){
            Trc.out.println("unmark");
            trace();
        }
    }

    /**
     * Move the index to the specified relative position ahead of the mark.
     * A mark must have been set before.
     * Note that a <code>reset(pos)</code> to a position has not the same
     * effect as a <code>mark()</code> to it followed by a <code>reset()</code>
     * since it makes <code>read()</code> restart delivering characters from
     * the reset position.
     * Note also that <code>reset(pos)</code> repositions only the stream.
     * To get any data, a <code>read()</code> or <code>readBlock()</code>
     * must be executed afterwards. I.e. it does not remap any buffer, and
     * does not update the <code>cursor</code>.
     *
     * @param      pos relative position
     */

    public void reset(int pos){
        if ((FL_A & this.trc) != 0){
            Trc.out.println("reset to: " + pos);
            trace();
        }
        if (this.inp == null) error(ERR_NOTOPEN,null);
        if (this.markPos < 0){          // no mark was set
            throw new IndexOutOfBoundsException();
        }
        pos = this.markPos + pos;       // actual position
        if (pos < 0){
            throw new IndexOutOfBoundsException();
        }
        if ((pos < this.markPos) ||
            (this.pendPos < pos)){
            throw new IndexOutOfBoundsException();
        }
        this.index -= this.pendPos - pos;
        this.pendPos = pos;
        this.atEof = false;
        check("reset");
        if ((FL_A & this.trc) != 0){
            Trc.out.println("reset to");
            trace();
        }
    }

    /**
     * Move the index to the marked position.  A mark must have been set
     * before.
     */

    public void reset(){
        reset(0);
    }

    /**
     * Tell if the stream is ready to deliver data.
     *
     * @return     <code>true</code> if the stream is ready,
     *             <code>false</code> otherwise
     */

    public boolean ready(){
        if (this.inp == null) error(ERR_NOTOPEN,null);
        if (this.pendPos < this.maxPos){    // ready if some pending
            return true;
        }
        if (this.kind >= INP_STRING){       // all data already got
            return false;
        }
        boolean ready = false;
        switch (this.kind){
        case INP_READER:
            try {
                ready = ((Reader)(this.inp)).ready();
            } catch (IOException exc){
                error(ERR_IOERR,exc);
            }
            break;
        }
        return ready;
    }

    /**
     * Tell if buffering is supported, which is <code>true</code>
     *
     * @return     <code>true</code>
     */

    public boolean markSupported(){
        return true;
    }

    /**
     * Tell if the last read operation occurred at the end-of-file.
     * A <code>reset()</code> sets it to false. Note that after a
     * <code>read()</code> which detects an end-of-file, a subsequent
     * one returns again an end-of-file, unless preceded by a
     * <code>reset()</code>.
     *
     * @return     <code>true</code> if eof
     */

    public boolean eof(){
        return this.atEof;
    }

    /**
     * Close the stream.
     */

    public void close(){
        if (this.inp != null){
            switch (this.kind){     // close the uderlying stream
            case INP_READER:
                try {
                    ((Reader)(this.inp)).close();
                } catch (IOException exc){
                    error(ERR_IOERR,exc);
                }
                break;
            }
            this.inp = null;        // remember now that it is closed
            this.buffer = null;     // release all memory
            this.markPos = -1;
            this.pendPos = 0;
            this.cursor = 0;
            this.end = 0;
        }
    }
}
