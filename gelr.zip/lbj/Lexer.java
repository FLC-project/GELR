/*
 * @(#)Lexer.java       1.0 2008/05/01
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.text.*;
import java.util.*;

/**
 * The <code>Lexer</code> class provides lexical analysis.
 * Lexemes are mainly made of ASCII characters.
 *
 * @author  Angelo Borsotti
 * @version 1.0   01 May 2008
 */

/* Techniques for implementing a hand-written lexer
 *
 * The API of Lexer has a CharsRow, extended with a start, cursor, end
 * and point.
 * A lexical method accesses those fields, scans characters, and leaves
 * the cursor past the lexeme, and returns a boolean value telling success
 * or failure. If it needs to scan past the end of the buffer (the piece
 * of text which is available, or a line), it calls a load().
 * When processing text line by line, load() would call a readln()
 * method. All indexes are on a same buffer, and thus they are simple to
 * handle.
 * When processing text in blocks, a buffered reader delivers a block of
 * characters each time it is called, and provides a reference to it and
 * the start and end indexes in it.
 * Note that conceptually, lexical methods advance an index in the stream
 * when they succeed. That index has a similar meaning as that of the index
 * in streams: it is the position of the character which is accessed by the
 * next lexical method.
 *
 * There are the following needs in a lexer:
 *
 *  - to have it scan only the text provided, or also get new text when it is
 *    exhausted. This is done by having lexical methods call a load()
 *    method (or some others built on it) which by default provides no text,
 *    while in subclasses it can deliver some more.
 *  - to get all characters of a lexeme and return them to the caller.
 *    For some tokens, like e.g. strings, not all characters are returned
 *    (in strings the delimiters are removed and the escape sequences reduced).
 *    This is done here by storing them in a Str.
 *    Callers need to access the recognized lexemes to store them, create
 *    objects, search, etc..
 *  - to test again some characters already scanned. It is possible to
 *    keep memory of the presence of some particular character in some
 *    specific position, but at times it is simpler to test them again,
 *    e.g. that the first character of a lexeme was a given one.
 *    This can be easily done by remembering the start of the lexeme
 *    and relocating it when making the test.
 *  - to compute the length of a lexeme. It is mainly used to tell if
 *    some characters have been matched, which means that a lexeme has
 *    been recognised.  It can be computed ad the end as cursor - start
 *  - to have the start index (the point) of the last lexeme.
 *  - to backup to a previous position of the same lexeme. It can be done by
 *    setting: position = cursor - start, and to backup: cursor = start +
 *    position.
 *  - to call different lexical methods at a same position to detect which
 *    lexeme is present. To avoid to rescan comments more than once in this
 *    case, either lexical methods reporting failure leave the cursor past
 *    comments, or applications should be allowed to call a lexical methods
 *    which scans comments explicitly.
 *  - to allow to process the non-lexed characters with some other method.
 *    E.g. the user could need to skip a defined number of characters or lines.
 *  - to have a skip operation, to be used to recover lexical errors which
 *    occur when at the current position no lexeme can be recognised.
 *    The skip operation can be provided in subclasses.
 *    It should be similar to a gsep(), but skip up to some defined delimiter.
 *    When statements are fully contained in lines, it is sufficient to
 *    read the next line in case of errors and continue parsing. It is
 *    equivalent to skip up to a newline.
 *
 * Implementation details:
 *
 *  - when making loops which are executed several times, keep references
 *    and indexes in variables instead of using the ones in fields.
 *    This is done only when such values are accessed several times.
 *  - two basic techniques can be used to match characters with what is
 *    expected: ch = buffer[cursor++] and ch = buffer[cursor]. The first
 *    one requires to decrement the cursor when recognizion stops because
 *    an unmatched character is found (i.e. not when the text is exhausted).
 *    The second requires to advance the cursor when a character is matched.
 *  - it is possible to have a stream field and a BufReader object in this
 *    class, but it seems a nonsense: when a char[] is passed, the lexer is
 *    told to scan it, and therefore it is inefficient (and space consuming)
 *    to have a reader. The benefits to have a reader is to use the cursor
 *    and the mark which are in it, which are not much.
 *    Lexer performs lexing on a char[] array.
 *  - before a character can be got from the buffer, a test must be done
 *    that the buffer is not exhausted:
 *
 *              if (cursor >= end){
 *                  if (append() < 0) return ...
 *              }
 *              c = buffer[cursor];
 *
 *  - it is not possible to compare, subtract, etc. cursor values when a
 *    append() could have been executed in the meantime. It is with what is
 *    contained in cursor and start since they are transposed at append().
 *  - the characters past the cursor might not be available all at once.
 *    This makes difficult the use of existing parsing methods such as the
 *    java ones which work on a string because it is difficult to figure out
 *    how match of the input to take to make up that string.
 *  - when scanning comments there is no need to keep the scanned characters.
 *    In so doing, the buffer is not enlarged when the lexer is built on
 *    a buffered reader. Methods like gsep() use load() to refill the buffer,
 *    The LexerStream implementation of load() removes the mark before
 *    reloading the buffer since the mark is usually set when it is called.
 *    When a load() is done which returns -1, cursor, start, etc., are not
 *    changed (i.e. local variables containing them are not updated since
 *    the assumption is that load() in such a case does not change the
 *    corresponding fields. This is so to keep simple the default load().
 *    However, when comments are started by a character combination, and
 *    a sequence of characters is found that matches it partly, then gsep()
 *    must backup to the beginning of it. To do it, it has to mark the buffer,
 *    and then it must use fill() instead of load().
 *  - it is possible to support composite lexemes: when SKIPWS is not present,
 *    no whitespace is skipped, and when CONCAT is present the characters
 *    are appended to the existing ones in the return string. Note that
 *    SKIPWS must be set so as to disable the calling of gsep() which could
 *    remove the mark and loose the previous lexeme.
 *  - the mark is set by append() when a buffered reader is used and the
 *    current buffer is exhausted.
 *  - when the lexeme is not recognised, a restore() is done, which it removes
 *    the mark when a buffered reader is used.
 *  - when reading a stream in blocks, and generating the listing during the
 *    processing of the text (as opposite to generating it at the end of the
 *    processing), Listing.print() must be called to print the part of
 *    the current block which has been processed and errors found, which
 *    is not the entire block. It must be called from within a redefined
 *    load() in a subclass.
 *  - when defining lexemes which can contain any character, there is a
 *    need to decide if they can contain format effectors. This is usually
 *    not the case. Therefore, there is a need to test for the presence
 *    of \n, \r, etc., and in such a case terminate the lexeme.
 *  - as a rule, lexical methods except gsep() must not change the field
 *    start because it is managed by load() which makes the assumption
 *    that it refers to the beginning of the current lexeme.
 *  - a backup of more than one lexeme is not simple in a lexer because either
 *    backup is done by repositioning the cursor (and the other fields) in
 *    the buffer, which requires some special technique to avoid to store
 *    the intermediate comments (which can be indefinetely long), or lexemes
 *    must be stored in a shift buffer, but then there is a need to interpret
 *    them according to the new lexemes requested to the lexer. When a lexeme
 *    is matched for the first time, it should be stored in the shift buffer
 *    with its meaning. When the lexer is backed up, it can be requested to
 *    deliver a different kind of lexeme, which could match the same
 *    characters. There is then a need to check if the stored lexeme could
 *    match the new interpretation. Moreover, the index of the lexemes must
 *    be stored in the shift buffer as well so as to deliver it.
 *  - to return the start index of lexemes, Lexer has a field for it, which
 *    is updated by the implementations of load() and append().
 *    LexerStream uses stream.index instead. This allows to retrieve the index
 *    also when the stream has been partly processed by other lexers or
 *    user methods.
 *  - indexes in a stream may in general not be mapped onto byte positions
 *    in files. Even if that was the case, it would be of little use in
 *    general because when the encoding used is a stateful one, a byte position
 *    does not allow to determine the offending charater by a random access.
 *    There is in general a need to rescan the input, which can be spared in
 *    some notable case, like e.g. all the fixed length encodings.
 *  - to allow other methods to take over processing, reposition() must be
 *    called before takeover. To resume processing with Lexer (LexerStream
 *    indeed since Lexer has no stream), nothing needs be done since
 *    reposition() leaves cursor = end, which forces the lexer to start over.
 *    Subclasses may need some deeper actions, like e.g. updating a line
 *    number counter, resetting internal state fields, etc.
 *    This is necessary because Lexer provides basic lexical methods which
 *    work on a buffer with no stream. To make them work when characters are
 *    provided by a stream, calls have been inserted in methods to get
 *    characters, which are defined in subclasses.
 *    To perform some actions at the end there would be a need to insert a call
 *    to a completion method at the end of each, which is redefined in a
 *    wrapper subclass. E.g. a restore() could be called at the end of each
 *    method, which, e.g. resets cursor to start when the lexeme has not
 *    been matched, and in subclasses can reset the stream.
 *    However, it is not efficient to do it each time just in case a takeover 
 *    can occur.
 *  - when there is a need to call a lexical method from within another,
 *    the INTER mode should be set, which makes the effect of gsep() null.
 *    This, besides not skipping whitespace, allows to retain the mode
 *    and start index of the caller. Note that the start index must not
 *    be changed in the middle of a lexeme otherwise it will not reflect
 *    the start of it, and might make the preceding characters lost when
 *    the buffer is refilled.
 *
 * Returning lexemes strings
 *
 * To return the lexemes to callers, there are three alternatives:  1. to
 * transfer the characters into a return string in one shot at the end of a
 * lexer method, 2. to do it inline during lexing, and 3. to return
 * (implicitly) a row to the input buffer. Tradeoffs:
 *
 *  1. it requires to buffer the input so as to scan the characters of a
 *     lexeme a second time, i.e. a test, branch and move for each character
 *     of the lexeme. This, however, has a good chance to be optimized by
 *     the compiler or the pipeline.
 *  2. it does not require to buffer the input (which is buffered anyway
 *     to some extent because reading is never done one character at a
 *     time). It releaves from the second scan, but it requires to store
 *     the characters into a temporary or final buffer, which means to test
 *     for space and to move data. If a temporary buffer is used, there is then
 *     a need for a transfer into a final one. If a final one is used,
 *     there is a good chance to loose space (which is important here if
 *     the lexemes are all kept to be delivered to the application).
 *  3. it is the fastest, but has the drawback that when another lexical
 *     method is called, the previous lexeme might be no longer accessible.
 *     Therefore, there is a need to store, or make immediate use of the
 *     lexeme. This is burdensome at times for callers.
 *
 * In HP it the first solution is 10% faster than the second, in a PC it
 * is the same. The tradeoff between copying inline and copying at the end
 * is between making a test on the return string space and scanning again
 * the characters.
 *
 * Note that with a return string provided by the caller it is possible to
 * return something which is different from the bare characters of a lexeme.
 * However, to be precise, a lexeme is the sequence of characters which
 * matches a token rule. For a quoted string it includes the quotes.
 * Any transformation of it is a representation in another space of values
 * of lexemes. E.g. numbers can be represented as binary values, strings as
 * sequences of characters (without quotes, with escape sequences reduced,
 * etc.).
 *
 * A solution could be not to store when the reference to the return string
 * is null. After a call to a lexical method, the caller can access the
 * lexeme and use it immediately, or store it for later use, or in the case
 * of quoted strings, pass a return string. However, this is faster only
 * when the caller does not pass the return string (which is seldom the
 * case). The current, inline loading of the return string is thus kept.
 * However, the the start cursor of lexemes is made available to allow
 * caller to access the characters of lexemes direclty in the buffer.
 *
 * In the input buffer a lexeme is identified by the start and end (last+1)
 * indexes. This is the normal way to identify a character slice and does
 * not cause problems even when the end index denotes a position which is
 * not in the buffer.
 */

public class Lexer extends CharsRow {

    /** The current lexing position. */
    public int cursor;

    /** The last+1 index of the buffer. */
    public int end;

    /** The index at which the current lexeme begins. */
    public int start;

    /** The mode and status. */
    public int mode;

    /** The internal call mode. */
    protected static final int INTER = 1 << 0;

    /** The lexical error status. */
    public static final int ERROR = 1 << 1;

    /** The overflow error status. */
    public static final int OVERFLOW = 1 << 2;

    /** The lexical concatenation mode. */
    public static final int CONCAT = 1 << 3;

    /** The skip white space mode. */
    public static final int SKIPWS = 1 << 4;

    /** The extended white space mode. */
    public static final int WHITESPACE = 1 << 5;

    /** The explicit base for numbers mode. */
    public static final int BASE = 1 << 6;

    /** The kilo/mega/giga suffixes for numbers mode. */
    public static final int MEGA = 1 << 7;

    /** The unsigned numbers mode. */
    public static final int UNSIGNED = 1 << 8;

    /** The monetary numbers mode. */
    public static final int MONETA = 1 << 9;

    /** The exact keyword case match mode. */
    public static final int EXACT = 1 << 10;

    /** The return integral value. */
    public long integral;

    /** The return real value. */
    public double real;

    /** The return date value. */
    public Date date;

    /** The trace flags. */
    public int trc;

    /** The position of the first character in the text. */
    public long point;

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    v   values
     * </pre></blockquote><p>
     */

    protected static final int FL_V = 1 << ('v'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Trace the text and the cursor.
     *
     * @param      s comment string
     */

    public void trace(String s){
        Trc.out.print(s + ": ");
        if (this.buffer != null){
            int len = this.end - this.cursor;
            if (len > 20) len = 20;
            Trc.out.print("|");
            Trc.literalize(this.buffer,this.cursor,len);
            Trc.out.print("|");
        }
        Trc.out.println("  length: " + this.length);
        Trc.out.println("cursor: " + this.cursor + " end: " + this.end +
            " offset: " + this.offset + " point: " + this.point);
    }

    /**
     * Trace the text and the cursor.
     *
     * @param      s comment string
     * @param      res boolean value to trace
     */

    public void trace(String s, boolean res){
        trace(s + " " + res);
    }

    /**
     * Deliver the position in the source.
     *
     * @param      n relative position
     * @return     absolute position
     */

    public long getPoint(int n){
        n -= this.offset;             // number of chars after point
        long pos = this.point;
        if (pos != Long.MAX_VALUE) pos += n;
        return pos;
    }

    /*
     * The table of the character categories.
     */

    /** The CH_ALF ASCII alphabetic character class */

    public static final int CH_ALF = 0;

    /** The CH_NUM ASCII digits character class */

    public static final int CH_NUM = 1;

    /** The CH_DOT ASCII extra identifier character class */

    public static final int CH_DOT = 2;

    /** The CH_SEP ASCII white space separator character class */

    public static final int CH_SEP = 3;

    /** The CH_NOR ASCII graphic printable character class */

    public static final int CH_NOR = 4;

    /** The CH_DEL ASCII punctuation delimiters character class */

    public static final int CH_DEL = 5;

    /** The CH_CNT ASCII control character class */

    public static final int CH_CNT = 6;

    /** The CH_ERR ASCII disallowed character class */

    public static final int CH_ERR = 7;

    /** The CH_MAX ASCII maximum character number */

    public static final int CH_MAX = 127;

    /** The CH_CAT ASCII character class array */

    public static final int[] CH_CAT = new int[CH_MAX+1];

    /* Initialise the table of character categories. */

    static {
        char c;

        for (c = 0x0; c <= 0x8; c++)
            CH_CAT[c] = CH_ERR;               // error
        CH_CAT[0x9] = CH_SEP;                 // separators: tab
        CH_CAT[0xa] = CH_CNT;                 // control: line feed
        CH_CAT[0xb] = CH_ERR;                 // error: VT
        CH_CAT[0xc] = CH_CNT;                 // control: form feed
        CH_CAT[0xd] = CH_CNT;                 // control: return
        for (c = 0xe; c <= 0x1f; c++)
            CH_CAT[c] = CH_ERR;               // error
        CH_CAT[' '] = CH_SEP;                 // separators: blank
        CH_CAT['!'] = CH_DEL;                 // delimiters: excl. mark
        CH_CAT['"'] = CH_NOR;                 // normal: double quote
        CH_CAT['#'] = CH_DEL;                 // delimiters: sharp
        CH_CAT['$'] = CH_DOT;                 // dot chars: dollar
        CH_CAT['%'] = CH_NOR;                 // normal: percent
        for (c = '&'; c <= '-'; c++)
            CH_CAT[c] = CH_DEL;               // delimiters
        CH_CAT['.'] = CH_DOT;                 // dot ch: dot
        CH_CAT['/'] = CH_DEL;                 // delimiters
        for (c = '0'; c <= '9'; c++)
            CH_CAT[c] = CH_NUM;               // numeric
        CH_CAT[':'] = CH_DEL;                 // delimiters: colon
        CH_CAT[';'] = CH_CNT;                 // control: semicolon
        for (c = '<'; c <= '>'; c++)
            CH_CAT[c] = CH_DEL;               // delimiters
        CH_CAT['?'] = CH_NOR;                 // normal: question mark
        CH_CAT['@'] = CH_DEL;                 // delimiters: at sign
        for (c = 'A'; c <= 'Z'; c++)
            CH_CAT[c] = CH_ALF;               // alphabetics
        CH_CAT['['] = CH_NOR;                 // normal: open bracket
        CH_CAT['\\'] = CH_DEL;                // delimiters: backslash
        for (c = ']'; c <= '^'; c++)
            CH_CAT[c] = CH_NOR;               // normal
        CH_CAT['_'] = CH_DOT;                 // dot ch: underline
        CH_CAT['`'] = CH_NOR;                 // normal: grave accent
        for (c = 'a'; c <= 'z'; c++)
            CH_CAT[c] = CH_ALF;               // alphabetics
        for (c = '{'; c <= '~'; c++)
            CH_CAT[c] = CH_NOR;               // normal
        CH_CAT[CH_MAX] = CH_ERR;              // error: del and following
    }

    /** 
     * Load the lexer buffer. The standard implementation delivers an
     * empty buffer.
     *
     * @return     -1
     */

    protected int load(){
        return -1;
    }

    /** 
     * Append data to the lexer buffer. The standard implementation
     * appends no data.
     *
     * @return     -1
     */

    protected int append(){
        return -1;
    }

    /** 
     * Restore the lexer to the start of the current, non-recognised, lexeme.
     */

    protected void restore(){
        this.cursor = this.start;
    }

    /** 
     * Skip all separator spaces (Unicode) / TAB. Make the lexer refer to
     * the first non separator character. Upon return, <code>cursor</code>
     * indicates the first non separator character.
     * If <code>SKIPWS</code> is not present, set the <code>start</code>
     * index only.
     */

    /* When a lexical method is called from within another lexical method,
     * it performs no action.
     */

    public void gsep(){
        if ((INTER & this.mode) != 0) return;      // internal call
        if ((SKIPWS & this.mode) == 0){
            this.start = this.cursor;
            return;
        }
        if ((FL_V & this.trc) != 0){
            trace("gsep start");
        }
        char[] buffer = this.buffer;
        int cursor = this.cursor - 1;
        int end = this.end;
        char c;
        if ((WHITESPACE & this.mode) == 0){
            do {
                if (++cursor == end){               // no data
                    int ch = load();
                    if (ch < 0) break;
                    end = this.end;
                    buffer = this.buffer;
                    cursor = this.cursor;
                }
                c = buffer[cursor];
            } while ((c == ' ') || (c == '\t'));
        } else {
            scan: for (;;){
                if (++cursor == end){               // no data
                    int ch = load();
                    if (ch < 0) break;
                    end = this.end;
                    buffer = this.buffer;
                    cursor = this.cursor;
                }
                c = buffer[cursor];
                white:{                             // test whitespace
                    if (c == 0x0009) break white;   // HT
                    if (c == 0x0020) break white;   // SP
                    if (c <  0x00A0) break scan;    // shortcut for ASCII
                    if (c == 0x00A0) break white;   // no-break space
                    if (c <  0x2000) break scan;
                    if (c <= 0x200B) break white;   // en, em, etc.
                    if (c == 0x3000) break white;   // ideographic space
                    break scan;
                }
            }                                       // end skip
        }
        this.cursor = cursor;
        this.start = cursor;                        // start of next token
        this.mode &= ~ERROR;                        // no errors
        if ((FL_V & this.trc) != 0){
            trace("gsep return: " + cursor);
        }
        return;
    }

    /**
     * Get a comment or the end of the line.
     * Skip the separators. The comment indicator is the one configured in
     * <code>lineEndComment</code>.
     *
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token. <code>false</code> if not found (if in the line there
     *             are other characters which are not separators or comments).
     */

    public boolean gcom(){
        if ((FL_V & this.trc) != 0){
            trace("gcom start");
        }
        gsep();                                     // skip separators
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (load() < 0){
                    found = true;                   // end of text
                    break doit;
                }
            }
            char c = this.buffer[this.cursor];
            if ((c == '\r') || (c == '\n')){        // end of line
                found = true;
                break doit;
            }
            char[] le = lineEndComment;
            if (le == null) break doit;
            for (int i = 0; i < le.length; i++, this.cursor++){
                if (this.cursor >= this.end){
                    if (append() < 0) break doit;   // end of data
                }
                if (this.buffer[this.cursor] != le[i]){
                    break doit;
                }
            }
            this.cursor = this.start;
            found = true;
        }
        if (!found) restore();                      // back up
        if ((FL_V & this.trc) != 0){
            trace("gcom return",found);
        }
        return found;
    }

    /** The line-end comment indicator. */
    public char[] lineEndComment;

    /**
     * Test the presence of a comment or end of line. It checks if the curent
     * position is at the end of the line or at a separator (white space)
     * character, or at the beginning of a comment. If white space is at
     * the current position, it skips it.
     *
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which is not a separator.
     */

    public boolean gcomsep(){
        if ((FL_V & this.trc) != 0){
            trace("gcomsep start");
        }
        boolean found = false;
        char c;
        if ((WHITESPACE & this.mode) == 0){
            do {
                if (this.cursor == this.end){       // no data
                    if (load() < 0) break;
                }
                c = buffer[this.cursor];
                if ((c != ' ') && (c != '\t')) break;
                this.cursor++;
                found = true;
            } while (true);
        } else {
            scan: do {
                if (this.cursor == this.end){       // no data
                    if (load() < 0) break;
                }
                c = buffer[this.cursor];
                white:{                             // test whitespace
                    if (c == 0x0009) break white;   // HT
                    if (c == 0x0020) break white;   // SP
                    if (c <  0x00A0) break scan;    // shortcut for ASCII
                    if (c == 0x00A0) break white;   // no-break space
                    if (c <  0x2000) break scan;
                    if (c <= 0x200B) break white;   // en, em, etc.
                    if (c == 0x3000) break white;   // ideographic space
                    break scan;
                }
                this.cursor++;
                found = true;
            } while (true);
        }
        this.start = cursor;                        // start of next token
        this.mode &= ~ERROR;                        // no errors
        if (!found){                                // white space found or
            found = gcom();                         // .. comment or end line
        }
        if ((FL_V & this.trc) != 0){
            trace("gcomsep return",found);
        }
        return found;
    }

    /**
     * Get a delimiter.
     *
     * @param      d delimiter
     * @return     </code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gdel(char d){
        if ((FL_V & this.trc) != 0){
            trace("gdel start");
        }
        gsep();                                  // skip separators
        boolean found = false;
        del: {
            if (this.cursor >= this.end){
                if (append() < 0) break del;     // end of data
            }
            if (this.buffer[this.cursor] != d){
                break del;                       // not found
            }
            this.cursor++;                       // skip delimiter
            found = true;
        }
        if ((FL_V & this.trc) != 0){
            trace("gdel return",found);
        }
        return found;
    }

    /**
     * Get an identifier. It has the syntax:
     * <p><blockquote><pre>
     *     {A|...|Z|a|...|z} {A|...|Z|a|...|z|0...|9}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the token.
     */

    public boolean gidn(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gidn start");
        }
        boolean found = giden(s,0);
        if ((FL_V & this.trc) != 0){
            trace("gidn return",found);
        }
        return found;
    }

    /**
     * Get an identifier. It has the syntax:
     * <p><blockquote><pre>
     *     {A|...|Z|a|...|z} {A|...|Z|a|...|z|0...|9|_}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the token.
     */

    public boolean gidj(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gidj start");
        }
        boolean found = giden(s,1);
        if ((FL_V & this.trc) != 0){
            trace("gidj return",found);
        }
        return found;
    }

    /**
     * Get an identifier. It has the syntax:
     * <p><blockquote><pre>
     *     {A|...|Z|a|...|z} {A|...|Z|a|...|z|0...|9|_|$}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gidu(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gidu start");
        }
        boolean found = giden(s,2);
        if ((FL_V & this.trc) != 0){
            trace("gidu return",found);
        }
        return found;
    }

    /**
     * Get an identifier. It has the syntax:
     * <p><blockquote><pre>
     *     {.|$|_|A|...|Z|a|...|z} {.|$|_|A|...|Z|a|...|z|0...|9}*
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */
        
    public boolean gsma(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gsma start");
        }
        boolean found = giden(s,3);
        if ((FL_V & this.trc) != 0){
            trace("gsma return",found);
        }
        return found;
    }

    /**
     * Get an identifier made of an initial character and continuation
     * characters.
     *
     * @param      s string in which the token is returned
     * @param      z character sets accepted: 0 see <code>gidn</code>,
     *             1 see <code>gidj</code>, 2 see <code>gidu</code>
     *             3 see <code>gsma</code>
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    protected boolean giden(Str s, int z){
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        char c = this.buffer[this.cursor];
        if (c >= CH_MAX) return false;
        first: {
            if (CH_CAT[c] == CH_ALF) break first;
            if (z >= 3){
                if ((c == '_') || (c == '$') || (c == '.'))
                    break first;
            }
            return false;
        }
        scan: for (;;){
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;         // append
            this.cursor++;                    // step to next
            if (this.cursor >= this.end){     // end of block
                if (append() < 0) break;      // end of data
            }
            c = this.buffer[this.cursor];
            if (c >= CH_MAX) break;           // end of token
            cont: {
                if (CH_CAT[c] <= CH_NUM) break cont;
                if (z >= 1){
                    if (c == '_') break cont;
                }
                if (z >= 2){
                    if (c == '$') break cont;
                }
                if (z >= 3){
                    if (c == '.') break cont;
                }
                break scan;
            }
        }
        return true;
    }

    /**
     * Get a qualifier. It has the syntax:
     * <p><blockquote><pre>
     *      {A|...|Z|a|...|z|0...|9|$}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gsnd(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gsnd start");
        }
        boolean found = gnzrep(s,0);
        if ((FL_V & this.trc) != 0){
            trace("gsnd return",found);
        }
        return found;
    }

    /**
     * Get a qualifier. It has the syntax:
     * <p><blockquote><pre>
     *      {A|...|Z|a|...|z|0...|9|$|_}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gsmn(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gsmn start");
        }
        boolean found = gnzrep(s,1);
        if ((FL_V & this.trc) != 0){
            trace("gsmn return",found);
        }
        return found;
    }

    /**
     * Get a qualifier. It has the syntax:
     * <p><blockquote><pre>
     *     {.|$|_|A|..|Z|a|..|z|0|..|9|%|*|-}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gquv(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gquv start");
        }
        boolean found = gnzrep(s,2);
        if ((FL_V & this.trc) != 0){
            trace("gquv return",found);
        }
        return found;
    }

    /**
     * Get a sequence of characters.
     *
     * @param      s string in which the token is returned
     * @param      z character sets accepted: 0 see <code>gsnd</code>,
     *             1 see <code>gsmn</code>, 2 see <code>gquv</code>
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    private boolean gnzrep(Str s, int z){
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        scan: for (;;){
            char c = this.buffer[this.cursor];
            app: {
                if (((c >= '0') && (c <= '9')) ||
                    ((c >= 'A') && (c <= 'Z')) ||
                    ((c >= 'a') && (c <= 'z')) ||
                    (c == '$'))
                    break app;
                if (z >= 1){
                    if (c == '_') break app;
                }
                if (z >= 2){
                    if ((c == '.') || (c == '%') ||
                        (c == '*') || (c == '-'))
                    break app;
                }
                break scan;
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] =            // append
                this.buffer[this.cursor];
            this.cursor++;                    // step to next
            if (this.cursor >= this.end){
                if (append() < 0) break;      // end of data
            }
        }
        return (this.cursor - this.start > 0);
    }

    /**
     * Get a keyword. It has the syntax:
     * <p><blockquote><pre>
     *     {any except .|$|_|A|..|Z|a|..|z}+
     * </pre></blockquote><p>
     * It checks that the keyword is equal to that passed ad argument.
     * It should be taken into account that it is intended to search
     * keywords, and thus:
     * <ul>
     * <li>makes no distinction between uppercase and lowercase (unless
     *    EXACT is set in the mode)
     * <li>trailing blanks in the argument are discarded
     * <li>the token terminates with a character that does not
     *     belong to it, as defined above.
     * </ol>
     * The argument must not be made of blanks only, and be in uppercase.
     *
     * @param      s keyword
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gkey(String s){
        if ((FL_V & this.trc) != 0){
            trace("gkey start " + s);
        }
        gsep();                                      // skip separators
        boolean ins = (EXACT & this.mode) == 0;
        boolean found = false;
        scan: {
            for (int i = 0; i < s.length(); i++, this.cursor++){
                char k = s.charAt(i);
                if (k == ' ') break;                 // key with trailing blanks
                if (this.cursor >= this.end){
                    if (append() < 0) break scan;    // end of data
                }
                char c = this.buffer[this.cursor];
                if (c == k) continue;
                if (!ins) break scan;
                c = (c < 128) ? Str.UPPER[c] :       // check if lowercase
                    Character.toUpperCase(c);
                k = (k < 128) ? Str.UPPER[k] :
                    Character.toUpperCase(k);
                if (c == k) continue;
                c = (c < 128) ? Str.LOWER[c] :
                    Character.toLowerCase(c);
                k = (k < 128) ? Str.LOWER[k] :
                    Character.toLowerCase(k);
                if (c != k) break scan;              // for Georgian
            }
            suc: if ((this.cursor < this.end) ||     // check that token terminates
                (append() >= 0)){                    // .. with a non alphanum char
                char c = this.buffer[this.cursor];
                if (c >= CH_MAX) break suc;
                if (CH_CAT[c] <= CH_DOT) break scan;
            }
            found = true;                            // found
            break scan;
        }
        if (!found) restore();                       // back up
        if ((FL_V & this.trc) != 0){
            trace("gkey end",found);
        }
        return found;
    }

    /**
     * Get a character combination. It checks that in the input the character
     * combination passed as argument is present.
     *
     * @param      s character combination
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gcmb(String s){
        if ((FL_V & this.trc) != 0){
            trace("gcmb start");
        }
        gsep();                                  // skip separators
        boolean found = false;
        ck: {
            for (int i = 0; i < s.length(); i++){
                if (this.cursor >= this.end){
                    if (append() < 0) break ck;  // end of data
                }
                if (this.buffer[this.cursor] !=
                    s.charAt(i)) break ck;
                this.cursor++;                   // step to next
            }
            found = true;                        // found
        }
        if (!found) restore();
        if ((FL_V & this.trc) != 0){
            trace("gcmb return",found);
        }
        return found;
    }

    /**
     * Get a string literal. It has the syntax:
     * <p><blockquote><pre>
     *     "{char|""}*"
     * </pre></blockquote><p>
     * The string must be contained in only one line of text and must not
     * contain format effectors.
     * The delimiter of the string (e.g. ") is passed as an argument.
     *
     * @param      s string in which the token is returned without the initial
     *             and final delimiters and with the duplicated intermediate
     *             delimiters reduced to one
     * @param d    delimiter
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated by the delimiter
     */

    public boolean gstr(Str s, char d){
        if ((FL_V & this.trc) != 0){
            trace("gstr start");
        }
        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;     // end of data
            }
            if (this.buffer[this.cursor] != d){
                break doit;                       // not found
            }
            this.cursor++;                        // skip delimiter
            l: {
                do {
                    if (this.cursor >= this.end){
                        if (append() < 0) break;        // end of data
                    }
                    char c = this.buffer[this.cursor];
                    if (('\b' <= c) && (c <= '\r')){
                        break;
                    }
                    if (c == d){                        // check double delimiter
                        this.cursor++;                  // step to next
                        if (this.cursor >= this.end){
                            if (append() < 0) break l;  // end of data
                        }
                        if (this.buffer[this.cursor] != d)
                            break l;                    // second delimiter
                    }
                    if (s.length == s.buffer.length){
                        s.extend();
                    }
                    s.buffer[s.length++] =
                        this.buffer[this.cursor++];     // append
               } while (true);
               this.mode |= ERROR;                      // error
            }
            found = true;
        }
        if ((FL_V & this.trc) != 0){
            trace("gstr return",found);
        }
        return found;
    }

    /**
     * Get a string literal. It has the syntax:
     * <p><blockquote><pre>
     *     "{char | escape}*"
     * </pre></blockquote><p>
     * The escapes are \n, \t, \b, \r, \f, \\, \', \", \ooo, &#92;uhhhh,
     * where `o' is an octal digit, and `h' an hexadecimal one.
     * The string must be contained in only one line of text and must not
     * contain format effectors other than HT.
     *
     * @param      s string in which the token is returned without the initial
     *             and final delimiters and with the duplicated intermediate
     *             delimiters reduced to one
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated by the delimiter
     */

    public boolean gjstr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gjstr start");
        }
        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;     // end of data
            }
            if (this.buffer[this.cursor] != '\"'){
                break doit;
            }
            this.cursor++;                        // skip delimiter
            boolean ok = false;
            l: do {
                if (this.cursor >= this.end){
                    if (append() < 0) break;      // end of data
                }
                char c = this.buffer[this.cursor];
                if (('\b' <= c) && (c <= '\r') && (c != '\t')){
                    break;
                }
                this.cursor++;
                esc: if (c == '\\'){                   // match escape
                    if (this.cursor >= this.end){
                        if (append() < 0) break esc;   // end of data
                    }
                    char ch = this.buffer[this.cursor++];
                    if (this.cursor >= this.end){
                        if (append() < 0){
                            this.cursor--;
                            break esc;                 // end of data
                        }
                    }
                    switch (ch){
                    case 'n': c = '\n'; break;
                    case 't': c = '\t'; break;
                    case 'b': c = '\b'; break;
                    case 'r': c = '\r'; break;
                    case 'f': c = '\f'; break;
                    case '\\': c = '\\'; break;
                    case '\'': c = '\''; break;
                    case '\"': c = '\"'; break;
                    case 'u': case 'U':
                        int u = 0;
                        int ini = this.cursor - 1;
                        for (int i = 0; i < 4; i++){
                            if (this.cursor >= this.end){
                                if (append() < 0){  // end of data
                                    this.cursor = ini;
                                    break esc;
                                }
                            }
                            ch = this.buffer[this.cursor++];
                            int d = 0;
                            if (('A' <= ch) && (ch <= 'F')){
                                d = ch - 'A' + 10;
                            } else if (('a' <= ch) && (ch <= 'f')){
                                d = ch - 'a' + 10;
                            } else if (('0' <= ch) && (ch <= '9')){
                                d = ch - '0';
                            } else {
                                this.cursor = ini;
                                break esc;
                            }
                            u = u * 16 + d;
                        }
                        c = (char)u;
                        break;
                    default:
                        this.cursor--;
                        u = 0;
                        ini = this.cursor;
                        boolean first = true;
                        for (int i = 0; i < 3; i++){
                            if (this.cursor >= this.end){
                                if (append() < 0){  // end of data
                                    if (first){
                                        this.cursor = ini;
                                        break esc;
                                    }
                                    this.cursor--;
                                    break;
                                }
                            }
                            ch = this.buffer[this.cursor++];
                            int d = 0;
                            if (('0' <= ch) && (ch <= '7')){
                                d = ch - '0';
                            } else {
                                if (first){
                                    this.cursor = ini;
                                    break esc;
                                }
                                this.cursor--;
                                break;
                            }
                            int uu = u * 8 + d;
                            if (uu >= 0x377){
                                if (first){
                                    this.cursor = ini;
                                    break esc;
                                }
                                this.cursor--;
                                break;
                            }
                            u = uu;
                            first = false;
                        }
                        c = (char)u;
                    }
                } else if (c == '\"'){
                    ok = true;
                    break l;
                } // esc
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] = c;              // append
            } while (true); // l
            if (!ok) this.mode |= ERROR;               // error
            found = true;
        }
        if ((FL_V & this.trc) != 0){
            trace("gjstr return",found);
        }
        return found;
    }

    /**
     * Get an html string. It has the syntax:
     * <p><blockquote><pre>
     *  &lt;html string&gt;  ::= &quot;{&lt;elem&gt;}*&quot; | '{&lt;elem&gt;}*'
     *  &lt;elem&gt;         ::= &lt;char&gt; | &lt;entity&gt; | #{x|X}&lt;h&gt;&lt;h&gt;
     * </pre></blockquote><p>
     * Where &lt;entity&gt is an HTML entity, and &lt;h&gt; is a hexadecimal digit.
     * The string must be contained in only one line of text.
     *
     * @param      s string in which the token is returned without the initial
     *             and final delimiters and with the html character entities
     *             reduced
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated by the delimiter
     */

    public boolean gHtmlStr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gHtmlStr start");
        }
        gsep();                                    // skip separators
        if ((CONCAT & this.mode) == 0)             // do not concatenate
            s.length = 0;
        int k = s.length;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;      // end of data
            }
            char d = this.buffer[this.cursor++];
            scan: {
                do {
                    if (this.cursor >= this.end){
                        if (append() < 0) break;   // end of data
                    }
                    char c = this.buffer[this.cursor++];
                    if (c == d){
                        found = true;
                        break scan;
                    }
                    if (s.length == s.buffer.length){
                        s.extend();
                    }
                    s.buffer[s.length++] = c;      // append
                } while (true);
                s.length = k;
                this.mode |= ERROR;                // error
            }
        }
        s.length = reduceHtml(s.buffer,k,s.length);
        if ((FL_V & this.trc) != 0){
            trace("gHtmlStr return",found);
        }
        return found;
    }

    /**
     * Reduce the html character entities. The search for the (symbolic)
     * references is done sequentially in strings which contain all the
     * references with the same length because that turns out to be faster
     * since it is done entirely inside a String method than using e.g.
     * a binary search which needs to access the characters with several
     * calls to charAt.
     *
     * @param      str string to be reduced
     * @param      init index at which reduction starts
     * @param      len length of string
     * @return     length of reduced string
     */

    public static int reduceHtml(char[] str, int ini, int len){
        int p = 0;
        for (int i = 0; i < len; i++){
            char c = str[i];
            ent: if ((len - i >= 4) &&            // &#n; or &aa;
                (c == '&')){
                if (str[i+1] == '#'){
                    int base = 10;
                    int j = i+2;
                    char t = str[j];
                    if ((t == 'x') || (t == 'X')){
                        j++;
                        base = 16;
                    }
                    int u = 0;
                    num: for (; j < len; j++){
                        char ch = str[j];
                        int d = 0;
                        if (('A' <= ch) && (ch <= 'F')){
                            d = ch - 'A' + 10;
                        } else if (('a' <= ch) && (ch <= 'f')){
                            d = ch - 'a' + 10;
                        } else if (('0' <= ch) && (ch <= '9')){
                            d = ch - '0';
                        } else {
                            break num;
                        }
                        if (d >= base) break ent;
                        u = u*base + d;
                        if (u > Character.MAX_VALUE) break ent;
                    }
                    if (j >= len) break ent;
                    if (str[j] != ';') break ent;
                    c = (char)u;
                    i = j;
                } else {
                    int j = i+1;
                    for (; j < len; j++){
                        if (str[j] == ';') break;
                    }
                    if (j >= len) break ent;
                    if (str[j] != ';') break ent;
                    int le = j - i -1;
                    if (le > 8) break ent;
                    String st = String.valueOf(str,i+1,le);
                    int ind = HTML_ENT[le-2].indexOf(st);
                    if (ind < 0) break ent;
                    c = HTML_ENT[le-2].charAt(ind+le);
                    i = j;
                }
            }
            str[p++] = c;
        }
        return p;
    }

    /** The html character entities. */
    private static final String HTML2 =
        "Mu\u039CNu\u039DPi\u03A0Xi\u039Ege\u2265gt\u003Ele\u2264" +
        "lt\u003Cmu\u03BCne\u2260ni\u220Bnu\u03BDor\u2228pi\u03C0" +
        "xi\u03BE";
    private static final String HTML3 =
        "Chi\u03A7ETH\u00D0Eta\u0397Phi\u03A6Psi\u03A8Rho\u03A1" +
        "Tau\u03A4amp\u0026and\u2227ang\u2220cap\u2229chi\u03C7" +
        "cup\u222Adeg\u00B0eta\u03B7eth\u00F0int\u222Bloz\u25CA" +
        "lrm\u200Enot\u00ACphi\u03C6piv\u03D6psi\u03C8reg\u00AE" +
        "rho\u03C1rlm\u200Fshy\u00ADsim\u223Csub\u2282sum\u2211" +
        "sup\u2283tau\u03C4uml\u00A8yen\u00A5zwj\u200D";
    private static final String HTML4 =
        "Auml\u00C4Beta\u0392Euml\u00CBIota\u0399Iuml\u00CFOuml\u00D6" +
        "Uuml\u00DCYuml\u0178Zeta\u0396auml\u00E4beta\u03B2bull\u2022" +
        "cent\u00A2circ\u02C6cong\u2245copy\u00A9dArr\u21D3darr\u2193" +
        "emsp\u2003ensp\u2002euml\u00EBeuro\u20ACfnof\u0192hArr\u21D4" +
        "harr\u2194iota\u03B9isin\u2208iuml\u00EFlArr\u21D0lang\u2329" +
        "larr\u2190macr\u00AFnbsp\u00A0nsub\u2284ordf\u00AAordm\u00BA" +
        "ouml\u00F6para\u00B6part\u2202perp\u22A5prod\u220Fprop\u221D" +
        "quot\"rArr\u21D2rang\u232Ararr\u2192real\u211Csdot\u22C5" +
        "sect\u00A7sube\u2286sup1\u00B9sup2\u00B2sup3\u00B3supe\u2287" +
        "uArr\u21D1uarr\u2191uuml\u00FCyuml\u00FFzeta\u03B6zwnj\u200C";
    private static final String HTML5 =
        "AElig\u00C6Acirc\u00C2Alpha\u0391Aring\u00C5Delta\u0394" +
        "Ecirc\u00CAGamma\u0393Icirc\u00CEKappa\u039AOElig\u0152" +
        "Ocirc\u00D4Omega\u03A9Prime\u2033Sigma\u03A3THORN\u00DE" +
        "Theta\u0398Ucirc\u00DBacirc\u00E2acute\u00B4aelig\u00E6" +
        "alpha\u03B1aring\u00E5asymp\u2248bdquo\u201Ecedil\u00B8" +
        "clubs\u2663crarr\u21B5delta\u03B4diams\u2666ecirc\u00EA" +
        "empty\u2205equiv\u2261exist\u2203frasl\u2044gamma\u03B3" +
        "icirc\u00EEiexcl\u00A1image\u2111infin\u221Ekappa\u03BA" +
        "laquo\u00ABlceil\u2308ldquo\u201Clsquo\u2018mdash\u2014" +
        "micro\u00B5minus\u2212nabla\u2207ndash\u2013notin\u2209" +
        "ocirc\u00F4oelig\u0153oline\u203Eomega\u03C9oplus\u2295" +
        "pound\u00A3prime\u2032radic\u221Araquo\u00BBrceil\u2309" +
        "rdquo\u201Drsquo\u2019sbquo\u201Asigma\u03C3szlig\u00DF" +
        "theta\u03B8thorn\u00FEtilde\u02DCtimes\u00D7trade\u2122" +
        "ucirc\u00FBupsih\u03D2";
    private static final String HTML6 =
        "Aacute\u00C1Agrave\u00C0Atilde\u00C3Ccedil\u00C7Dagger\u2021" +
        "Eacute\u00C9Egrave\u00C8Iacute\u00CDIgrave\u00CCLambda\u039B" +
        "Ntilde\u00D1Oacute\u00D3Ograve\u00D2Oslash\u00D8Otilde\u00D5" +
        "Scaron\u0160Uacute\u00DAUgrave\u00D9Yacute\u00DDaacute\u00E1" +
        "agrave\u00E0atilde\u00E3brvbar\u00A6ccedil\u00E7curren\u00A4" +
        "dagger\u2020divide\u00F7eacute\u00E9egrave\u00E8forall\u2200" +
        "frac12\u00BDfrac14\u00BCfrac34\u00BEhearts\u2665hellip\u2026" +
        "iacute\u00EDigrave\u00ECiquest\u00BFlambda\u03BBlfloor\u230A" +
        "lowast\u2217lsaquo\u2039middot\u00B7ntilde\u00F1oacute\u00F3" +
        "ograve\u00F2oslash\u00F8otilde\u00F5otimes\u2297permil\u2030" +
        "plusmn\u00B1rfloor\u230Brsaquo\u203Ascaron\u0161sigmaf\u03C2" +
        "spades\u2660there4\u2234thinsp\u2009uacute\u00FAugrave\u00F9" +
        "weierp\u2118yacute\u00FD";
    private static final String HTML7 =
        "Epsilon\u0395Omicron\u039FUpsilon\u03A5alefsym\u2135" +
        "epsilon\u03B5omicron\u03BFupsilon\u03C5";
    private static final String HTML8 =
        "thetasym\u03D1";
    private static final String[] HTML_ENT =
         {HTML2,HTML3,HTML4,HTML5,HTML6,HTML7,HTML8};

    /**
     * Reduce the Unicode escapes.
     *
     * @param      str string to be reduced
     * @param      init index at which reduction starts
     * @param      len length of string
     * @return     length of reduced string
     */

    public static int reduceUnicode(char[] str, int ini, int len){
        int p = 0;
        len += ini;
        for (int i = 0; i < len; i++){
            char c = str[i];
            if ((len - i >= 2) &&
                (c == '\\') &&
                ((str[i+1] == 'u') ||
                (str[i+1] == 'U'))){
                if (len - i < 6){
                    return -1;
                }
                c = 0;
                for (int j = i+2; j < i+6; j++){
                    c <<= 4;
                    char ch = str[j];
                    if (('A' <= ch) && (ch <= 'F')){
                        c += ch - 'A' + 10;
                    } else if (('a' <= ch) && (ch <= 'f')){
                        c += ch - 'a' + 10;
                    } else if (('0' <= ch) && (ch <= '9')){
                        c += ch - '0';
                    } else {
                        return -1;
                    }
                }
                i += 5;
            }
            str[p++] = c;
        }
        p -= ini;
        return p;
    }

    /**
     * Get a non-terminal. It has the syntax:
     * <p><blockquote><pre>
     *     &lt; {char | string}+ &gt;   in which char is neither a &gt; nor a format effector
     * </pre></blockquote><p>
     * When a &gt; or format effector need be introduced as part of the
     * nonterminal, the syntax of strings (<code>gjstr()</code> method) should
     * be used.
     * Note that a nonterminal cannot cross line boundaries. When a newline
     * need be part of a nonterminal, the syntax of strings must be used.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gntr(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gntr start");
        }
        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;     // end of data
            }
            if (this.buffer[this.cursor] != '<'){
                break doit;                       // not found
            }
            int t = s.length;
            this.cursor++;                        // step to next
            boolean skip = false;
            char c = ' ';
            do {
                if (this.cursor >= this.end){
                    if (append() < 0) break;      // end of data
                }
                c = this.buffer[this.cursor++];
                if (c == '('){
                    skip = true;
                } else if (c == ')'){
                    skip = false;
                } else if (c == '>'){
                    break;
                } else if (('\b' <= c) && (c <= '\r')){
                    this.cursor--;
                    break;
                } else if (c == '\"'){
                    this.cursor--;                    // back to "
                    int saveMode = this.mode;
                    this.mode |= CONCAT | INTER;
                    gjstr(s);                         // string part
                    if ((ERROR & this.mode) != 0){    // error
                        this.mode = saveMode | ERROR;
                        break;
                    }
                    this.mode = saveMode;
                } else {
                    if (!skip){
                        if (s.length == s.buffer.length){
                            s.extend();
                        }
                        s.buffer[s.length++] = c;     // append
                    }
                }
            } while (true);
            if (this.cursor - this.start <= 1){       // < alone or <>
                this.cursor = this.start;
                s.length = t;
                break doit;
            } else if (c == '>'){
                if (this.cursor - this.start == 2){   // <>
                    this.cursor = this.start;
                    s.length = t;
                    break doit;
                }
            } else {
                this.mode |= ERROR;                   // error
            }
            found = true;
        } // doit
        if ((FL_V & this.trc) != 0){
            trace("gntr return",found);
        }
        return found;
    }

    /**
     * Get a decimal number. It has the syntax:
     * <p><blockquote><pre>
     *     {0|...|9}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gnum(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gnum start");
        }
        boolean found = gnumber(s,10);
        if ((FL_V & this.trc) != 0){
            trace("gnum return",found);
        }
        return found;
    }

    /**
     * Get an octal number. It has the syntax:
     * <p><blockquote><pre>
     *     {0|...|7}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean goct(Str s){
        if ((FL_V & this.trc) != 0){
            trace("goct start");
        }
        boolean found = gnumber(s,8);
        if ((FL_V & this.trc) != 0){
            trace("goct return",found);
        }
        return found;
    }

    /**
     * Get a hexadecimal number. It has the syntax:
     * <p><blockquote><pre>
     *     {0|...|9|A|..|F|a|...|f}+
     * </pre></blockquote><p>
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean ghex(Str s){
        if ((FL_V & this.trc) != 0){
            trace("ghex start");
        }
        boolean found = gnumber(s,16);
        if ((FL_V & this.trc) != 0){
            trace("ghex return",found);
        }
        return found;
    }

    /**
     * Get a number.
     *
     * @param      s string in which the token is returned
     * @param      base base of the number
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    private boolean gnumber(Str s, int base){
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        scan: for (;;){
            char c = this.buffer[this.cursor];
            cont: {
                if ((c >= '0') && (c <= '7'))
                    break cont;
                if (base >= 10){
                    if ((c >= '8') && (c <= '9'))
                        break cont;
                }
                if (base == 16){
                    if (((c >= 'A') && (c <= 'F')) ||
                        ((c >= 'a') && (c <= 'f')))
                        break cont;
                }
                break scan;                   // not found
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] =
                this.buffer[this.cursor];     // append
            this.cursor++;                    // step to next
            if (this.cursor >= this.end){
                if (append() < 0) break;      // end of data
            }
        }
        return (this.cursor - this.start > 0);
    }

    /**
     * Get and convert a decimal number. It has the same syntax as
     * <code>gnum</code>.
     * It converts it into a binary number. The accepted range is 0:2**31-1.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>integral</code> contains the number.
     *             Otherwise <code>mode</code> contains <code>OVERFLOW</code
     *             if the number is out of the allowed range, or
     *             <code>ERROR</code> if its syntax is incorrect, and
     *             <code>integral</code> contains 0.
     */
        
    public boolean gdec(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gdec start");
        }
        boolean found = convnum(s,10);
        if ((FL_V & this.trc) != 0){
            trace("gdec return",found);
        }
        return found;
    }

    /**
     * Get and convert an octal number. It has the same syntax as
     * <code>goct</code>.
     * It converts it into a binary number. The accepted range is 0:2**31-1.
     *
     * @see        #gdec(Str)
     */
        
    public boolean gnoct(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gnoct start");
        }
        boolean found = convnum(s,8);
        if ((FL_V & this.trc) != 0){
            trace("gnoct return",found);
        }
        return found;
    }

    /**
     * Get and convert a hexadecimal number. It has the same syntax as
     * <code>ghex</code>.
     * It converts it into a binary number. The accepted range is 0:2**31-1.
     *
     * @see        #gdec(Str)
     */
        
    public boolean gnhex(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gnhex start");
        }
        boolean found = convnum(s,16);
        if ((FL_V & this.trc) != 0){
            trace("gnhex return",found);
        }
        return found;
    }

    /**
     * Get and convert a number.
     *
     * @param      s string in which the token is returned
     * @param      base base of the number
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>integral</code> contains the number.
     *             Otherwise <code>mode</code> contains <code>OVERFLOW</code
     *             if the number is out of the allowed range, or
     *             <code>ERROR</code> if its syntax is incorrect, and
     *             <code>integral</code> contains 0.
     */

    private boolean convnum(Str s, int base){
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }
        int k = s.length;                     // start of string
        int r = 0;                            // init result number
        if (gnumber(s,base)){                 // get number
            this.mode &= ~OVERFLOW;
            for (; k < s.length; k++){        // scan digits
                char c = s.buffer[k];
                char b = '0';
                if (c >= 'A') b = 'A' - 10;
                if (c >= 'a') b = 'a' - 10;
                int j = (int)c - b;                     // value of digit
                if (j > Integer.MAX_VALUE - r*base){    // overflow
                    r = 0;
                    this.mode |= OVERFLOW;
                } else {
                    r = r*base + j;
                }
            }
        } else {
            this.integral = 0;
            return false;                     // not found
        }
        if ((OVERFLOW & this.mode) != 0){
            r = 0;
        }
        this.integral = r;
        return true;                          // found
    }

    /**
     * Get and convert an integer number. The allowed values are -2**31..2**31-1.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>integral</code> contains the number.
     *             Otherwise <code>mode</code> contains <code>OVERFLOW</code
     *             if the number is out of the allowed range, or
     *             <code>ERROR</code> if its syntax is incorrect, and
     *             <code>integral</code> contains 0.
     */

    public boolean gint(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gint start");
        }
        gsep();                               // skip separators
        if ((CONCAT & this.mode) == 0)        // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return false;   // end of data
        }

        boolean negative = false;
        this.mode &= ~OVERFLOW;
        char ch = this.buffer[this.cursor];
        sign: {
            if (ch == '-'){
                negative = true;
            } else if (ch != '+'){
                break sign;
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] =
                this.buffer[this.cursor];     // append
            this.cursor++;
        }
        int res = 0;
        boolean found = false;
        scan: for (;;){
            if (this.cursor >= this.end){
                if (append() < 0) break;      // end of data
            }
            char c = this.buffer[this.cursor];
            if ((c < '0') || ('9' < c)) break scan;
            res *= 10;
            if (res > 0){
                this.mode |= OVERFLOW;
            }
            int digit = (int)c - '0';
            res -= digit;                     // use negative accumulators, ..
            if (res > 0){                     // .. which is larger than a ..
                this.mode |= OVERFLOW;        // .. positive one
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] =
                this.buffer[this.cursor];     // append
            this.cursor++;                    // step to next
            found = true;
        }
        if (!negative){
            res = -res;
            if (res < 0){
                this.mode |= OVERFLOW;
            }
        }
        if ((OVERFLOW & this.mode) != 0){
            res = 0;
        }
        this.integral = res;
        if ((FL_V & this.trc) != 0){
            trace("gint return",found);
        }
        return found;
    }

    /**
     * Parse a roman numeral value.
     */

    public int parseRoman(){
        if ((FL_V & this.trc) != 0){
            Trc.out.println("parseRoman start");
        }
        int next;
        int rem, base;

        this.mode &= ~(OVERFLOW | ERROR);
        if ((this.buffer == null) || 
            (this.cursor >= this.end)){
            if (append() < 0){               // end of data
                this.mode |= ERROR;
                return 0;
            }
        }
        int n = 0;
        base = 100000;
        int i = 0;
        int ini = this.cursor - this.start;
        loop: while (i < romanLetter.length){
            if ((FL_V & this.trc) != 0){
                Trc.out.println("cursor: " + this.cursor +
                    " n: " + n + " base: " + base + " i: " + i +
                    " letter: " + romanLetter[i]);
            }
            next = i + 1;
            rem = base / romanBase[i];
            if ((FL_V & this.trc) != 0){
                Trc.out.println("rem: " + rem + " base: " +
                    base + " romanBase: " + romanBase[i] +
                    " next: " + next);
            }
            if ((next < romanLetter.length) && (romanBase[i] == 2)){
                rem = rem / romanBase[next++];
            }
            int l1 = 0;
            if (next < romanLetter.length){
                l1 = romanLetter[next].length();
            }
            int l2 = romanLetter[i].length();
            int begin = this.cursor - this.start;
            match:
            if ((next < romanLetter.length) &&
                matchString(romanLetter[next]) &&
                matchString(romanLetter[i])){
                n -= rem;                            // subtractive form
                n += base;                           // .. at beginning
                if ((FL_V & this.trc) != 0){
                    Trc.out.println("matched sub n:" + n);
                }
                if (n < 0){
                    this.mode |= OVERFLOW;
                    restore();
                    return 0;
                }
                base = base / romanBase[i++];
            } else {
                this.cursor = this.start + begin;
                int rep = romanBase[i+1]-1;
                if (i == 0) rep = Integer.MAX_VALUE;
                for (int k = 0; k < rep; k++){
                    if (this.cursor == this.end){
                        if (append() < 0){           // end of data
                            break loop;
                        }
                    }
                    if (!matchString(romanLetter[i])){
                        break;
                    } else {
                        begin = this.cursor - this.start;
                    }
                    n += base;
                    if ((FL_V & this.trc) != 0){
                        Trc.out.println("matched n:" + n);
                    }
                    if (n < 0){
                        this.mode |= OVERFLOW;
                        restore();
                        return 0;
                    }
                }
                begin = this.cursor - this.start;
                if ((next < romanLetter.length) &&   // subtractive at end
                    matchString(romanLetter[next]) &&
                    matchString(romanLetter[i])){
                    if ((FL_V & this.trc) != 0){
                        Trc.out.println("matched sub end");
                    }
                    this.cursor = this.start + begin;
                    break match;
                } else {
                    this.cursor = this.start + begin;
                }
                base = base / romanBase[i++];
            } // match
        }
        if ((FL_V & this.trc) != 0){
            Trc.out.println("roman_int: " + this.cursor +
                " " + this.end + " " + n + " " + this.start + " " + ini);
        }
        if (this.cursor - this.start > ini){
            return n;
        } else {
            this.mode |= ERROR;
            restore();
            return 0;
        }
    }

    /**
     * Matches a string at the current position in a case insensitive way.
     *
     * @param      s string
     * @return     <code>true</code> if found
     */

    private boolean matchString(String s){
        if ((FL_V & this.trc) != 0){
            Trc.out.println("matchString: " + s + " " + this.cursor);
        }
        int l1 = 0;
        int l2 = s.length();
        boolean found = false;
        int ini = this.cursor - this.start;
        doit: {
            for (int i2 = 0; i2 < l2; i2++, l1++){
                if (this.cursor >= this.end){
                    if (append() < 0) break doit;  // end of data
                }
                char c1 = this.buffer[this.cursor++];
                char c2 = s.charAt(i2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? Str.UPPER[c1] :
                    Character.toUpperCase(c1);
                c2 = (c2 < 128) ? Str.UPPER[c2] :
                    Character.toUpperCase(c2);
                if (c1 == c2) continue;
                c1 = (c1 < 128) ? Str.LOWER[c1] :
                    Character.toLowerCase(c1);
                c2 = (c2 < 128) ? Str.LOWER[c2] :
                    Character.toLowerCase(c2);
                if (c1 != c2){                     // for Georgian
                    this.cursor--;
                    break doit;
                }
            }
            found = true;
        } // doit
        if (!found) this.cursor = this.start + ini;
        if ((FL_V & this.trc) != 0){
            Trc.out.println("matchString: " + found + " " + this.cursor);
        }
        return found;
    }

    /* The roman digits.*/
    private static final String[] romanLetter =
        {"(((i)))","i)))","((i))","i))","m","d","c","l","x","v","i"};

    /* The relative base of the digits. N.B. it has an additional entry at end. */
    private static final int[] romanBase  = {2,5,2,5,2,5,2,5,2,5,2,5};

    /**
     * The table of currency symbols and numeric codes. Each currency
     * symbol is made of three characters, and it is followed by a
     * character whose numeric value is the code of the currency and
     * by a space so as to make sure that there are no ambiguous
     * matches and to allow to use indexOf to search it.
     */

    private static final String currency = 
        "ADP\u0014 AED\u0310 AFA\u0004 ALL\u0008 AMD\u0033 ANG\u0214 AON\u0002 " +
        "AOR\u03d6 ARS\u0020 ATS\u0028 AUD\u0024 AWG\u0215 AZM\u001f BAM\u03d1 " +
        "BBD\u0034 BDT\u0032 BEF\u0038 BGL\u0064 BHD\u0030 BIF\u006c BMD\u003c " +
        "BND\u0060 BOB\u0044 BOV\u03d8 BRL\u03da BSD\u002c BTN\u0040 BWP\u0048 " +
        "BYB\u0070 BZD\u0054 CAD\u007c CDF\u03d0 CHF\u02f4 CLF\u03de CLP\u0098 " +
        "CNY\u009c COP\u00aa CRC\u00bc CUP\u00c0 CVE\u0084 CYP\u00c4 CZK\u00cb " +
        "DEM\u0118 DJF\u0106 DKK\u00d0 DOP\u00d6 DZD\u0001 ECS\u00da ECV\u03d7 " +
        "EEK\u00e9 EGP\u0332 ERN\u00e8 ESP\u02d4 ETB\u00e6 EUR\u03d2 FIM\u00f6 " +
        "FJD\u00f2 FKP\u00ee FRF\u00fa GBP\u033a GEL\u03d5 GHC\u0120 GIP\u0124 " +
        "GMD\u010e GNF\u0144 GRD\u012c GTQ\u0140 GWP\u0270 GYD\u0148 HKD\u0158 " +
        "HNL\u0154 HRK\u00bf HTG\u014c HUF\u015c IDR\u0168 IEP\u0174 ILS\u0178 " +
        "INR\u0164 IQD\u0170 IRR\u016c ISK\u0160 ITL\u017c JMD\u0184 JOD\u0190 " +
        "JPY\u0188 KES\u0194 KGS\u01a1 KHR\u0074 KMF\u00ae KPW\u0198 KRW\u019a " +
        "KWD\u019e KYD\u0088 KZT\u018e LAK\u01a2 LBP\u01a6 LKR\u0090 LRD\u01ae " +
        "LSL\u01aa LTL\u01b8 LUF\u01ba LVL\u01ac LYD\u01b2 MAD\u01f8 MDL\u01f2 " +
        "MGF\u01c2 MKD\u0327 MMK\u0068 MNT\u01f0 MOP\u01be MRO\u01de MTL\u01d6 " +
        "MUR\u01e0 MVR\u01ce MWK\u01c6 MXN\u01e4 MXV\u03d3 MYR\u01ca MZM\u01fc " +
        "NAD\u0204 NGN\u0236 NIO\u022e NLG\u0210 NOK\u0242 NPR\u020c NZD\u022a " +
        "OMR\u0200 PAB\u024e PEN\u025c PGK\u0256 PHP\u0260 PKR\u024a PLN\u03d9 " +
        "PTE\u026c PYG\u0258 QAR\u027a ROL\u0282 RUB\u0283 RUR\u032a RWF\u0286 " +
        "SAR\u02aa SBD\u005a SCR\u02b2 SDD\u02e0 SEK\u02f0 SGD\u02be SHP\u028e " +
        "SIT\u02c1 SKK\u02bf SLL\u02b6 SOS\u02c2 SRG\u02e4 STD\u02a6 SVC\u00de " +
        "SYP\u02f8 SZL\u02ec THB\u02fc TJR\u02fa TMM\u031b TND\u0314 TOP\u0308 " +
        "TPE\u0272 TRL\u0318 TTD\u030c TWD\u0385 TZS\u0342 UAH\u03d4 UGX\u0320 " +
        "USD\u0348 USN\u03e5 USS\u03e6 UYU\u035a UZS\u035c VEB\u035e VND\u02c0 " +
        "VUV\u0224 WST\u0372 XAF\u03b6 XAG\u03c1 XAU\u03bf XBA\u03bb XBB\u03bc " +
        "XBC\u03bd XBD\u03be XCD\u03b7 XDR\u03c0 XFO\u03e7 XFU\u03e7 XOF\u03b8 " +
        "XPD\u03c4 XPF\u03b9 XPT\u03c2 XTS\u03c3 XXX\u03e7 YER\u0376 YUM\u037b " +
        "ZAL\u03df ZAR\u02c6 ZMK\u037e ZRN\u00b4 ZWD\u02cc ";

    /**
     * Get a date. The syntax is the one defined for the DateFormat class.
     *
     * @param      loc locale
     * @param      s string in which the token is returned.
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    /* Since it is not possible to force the java DateFormat.parse()
     * to parse progressively text, 256 characters (or the text which is
     * available) are read and passed to it.
     */

    public boolean gdate(Locale loc, Str s){
        if ((FL_V & this.trc) != 0){
            trace("gdate start");
        }
        DateFormat    df;
        Date          result = null;
        ParsePosition pos;

        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;     // end of data
            }
            int k = s.length;                     // start of string
            do {
                int len = this.end - this.start;
                if (len >= 256) break;
            } while (append() >= 0);
            String str = String.valueOf(this.buffer,this.start,
                this.end - this.start);
            df = DateFormat.getDateTimeInstance(DateFormat.DEFAULT,
                DateFormat.DEFAULT,loc);
            pos = new ParsePosition(0);
            result = df.parse(str,pos);
            if ((FL_V & this.trc) != 0){
                Trc.out.println("gdate: " + str + " " + pos.getIndex());
            }
            this.cursor = this.start + pos.getIndex();
            this.date = result;
            if (result == null){
                break doit;
            }
            s.cutInsert(k,0,this.buffer,this.end,this.start,
                this.cursor - this.start);
            found = this.cursor > this.start;
        } // doit
        if ((FL_V & this.trc) != 0){
            trace("gdate return",found);
        }
        return found;
    }

    /**
     * Get a date with a given format.
     *
     * @param      form format, see SimpleDateFormat
     * @param      s string in which the token is returned.
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gdate(String form, Str s){
        if ((FL_V & this.trc) != 0){
            trace("gdate start");
        }
        SimpleDateFormat df;
        Date             result = null;
        ParsePosition    pos;

        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;     // end of data
            }
            int k = s.length;                     // start of string
            do {
                int len = this.end - this.start;
                if (len >= 256) break;
            } while (append() >= 0);
            String str = String.valueOf(this.buffer,this.start,
                this.end - this.start);
            df = new SimpleDateFormat(form);
            pos = new ParsePosition(0);
            result = df.parse(str,pos);
            if ((FL_V & this.trc) != 0){
                Trc.out.println("gdate: " + str + " " + pos.getIndex());
            }
            this.cursor = this.start + pos.getIndex();
            this.date = result;
            if (result == null){
                break doit;
            }
            s.cutInsert(k,0,this.buffer,this.end,this.start,
                this.cursor - this.start);
            found = this.cursor > this.start;
        } // doit
        if ((FL_V & this.trc) != 0){
            trace("gdate return",found);
        }
        return found;
    }

    /**
     * Get a VMS logical name. It has the syntax:
     * <p><blockquote><pre>
     *    &lt;l.name&gt;    ::= {&lt;alphan&gt;}+ [:]
     *    &lt;alphan&gt;    ::= 0|..|9|a|..|z|A|..|Z|$|_
     * </pre></blockquote><p>
     * The final ':' (if any) is always eliminated.
     *
     * @param      s string in which the token is returned, in uppercase if
     *             running on host vms
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean glog(Str s){
        if ((FL_V & this.trc) != 0){
            trace("glog start");
        }
        gsep();                                     // skip separators
        if ((CONCAT & this.mode) == 0)              // do not concatenate
            s.length = 0;
        int k = s.length;
        boolean found = false;
        doit: {
            if (this.cursor >= this.end){
                if (append() < 0) break doit;       // end of data
            }
            while ((this.buffer[this.cursor] < CH_MAX) &&
                (CH_CAT[this.buffer[this.cursor]] <= CH_DOT) &&
                (this.buffer[this.cursor] != '.')){ // search logical name
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] =              // append
                    this.buffer[this.cursor];
                this.cursor++;                      // step to next
                if (this.cursor >= this.end){
                    if (append() < 0) break;        // end of data
                }
            }
            if (this.cursor == this.start) break doit;   // not found
            colon: {
                if (this.cursor >= this.end){
                    if (append() < 0) break colon;       // end of data
                }
                if (this.buffer[this.cursor] == ':'){    // skip the :
                     this.cursor++;                      // step to next
                }
            }
            found = true;
        } // doit
        if ((FL_V & this.trc) != 0){
            trace("glog return",found);
        }
        return found;
    }

    /* Directory constants */

    static final int LEV_L = 8;            // max number of levels
    static final int DRN_L = 12;           // max name length

    /**
     * Get a VMS directory path. It converts it into a string
     * by replacing lowercase characters with the corresponding uppercase
     * ones and removing leading zeroes of group and owner. The token
     * has the syntax:
     * <p><blockquote><pre>
     *  &lt;directory&gt; ::= "&lt;" | "["  &lt;lev&gt; | &lt;uic&gt; "&gt;" | "]"
     *  &lt;lev&gt;       ::= &lt;name&gt; {"." &lt;name&gt; }*
     *  &lt;name&gt;      ::= (&lt;alphan&gt;)+
     *  &lt;alphan&gt;    ::= 0|..|9|A|..|Z|a|..|z
     *  &lt;uic&gt;       ::= &lt;num&gt; "," &lt;num&gt;
     *  &lt;num&gt;       ::= &lt;oct&gt; [ &lt;oct&gt; [ &lt;oct&gt; ]]
     *  &lt;oct&gt;       ::= 0 | .. | 7
     * </pre></blockquote><p>
     * No spaces or other separators are allowed in the token.
     * At most LEV_L names are allowed, and each of them can contain
     * at most DRN_L characters. In the uic case &lt;num&gt; may not exceed
     * the octal value 377.  
     * The parentheses that delimit the token must be of the same kind:
     * both angular or square.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated
     */

    public boolean gdir(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gdir start");
        }
        boolean found = gdirec(s,false);
        if ((FL_V & this.trc) != 0){
            trace("gdir return",found);
        }
        return found;
    }

    /**
     * Get a VMS directory path. It converts it into a string
     * by replacing lowercase characters with the corresponding uppercase
     * ones and removing leading zeroes of group and owner. The token
     * has the syntax:
     * <p><blockquote><pre>
     *  &lt;directory&gt; ::= "&lt;" | "["  &lt;lev&gt; | &lt;uic&gt; "&gt;" | "]"
     *  &lt;lev&gt;       ::= &lt;name&gt; {"." &lt;name&gt; }*
     *  &lt;name&gt;      ::= (&lt;sma&gt;)+
     *  &lt;uic&gt;       ::= &lt;num&gt; "," &lt;num&gt;
     *  &lt;num&gt;       ::= &lt;oct&gt; [ &lt;oct&gt; [ &lt;oct&gt; ]]
     *  &lt;oct&gt;       ::= 0 | .. | 7
     * </pre></blockquote><p>
     * No spaces or other separators are allowed in the token.
     * At most LEV_L names are allowed, and each of them can contain
     * at most DRN_L characters. In the uic case &lt;num&gt; may not exceed
     * the octal value 377.  
     * The parentheses that delimit the token must be of the same kind:
     * both angular or square.
     *
     * @param      s string in which the token is returned
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token, and <code>mode</code> contains <code>ERROR</code>
     *             if the string is not terminated
     */

    public boolean gdire(Str s){
        if ((FL_V & this.trc) != 0){
            trace("gdirec start");
        }
        boolean found = gdirec(s,true);
        if ((FL_V & this.trc) != 0){
            trace("gdirec return",found);
        }
        return found;
    }

    /**
     * Get a directory.
     *
     * @param      s string in which the token is returned
     * @param      ext true if extended syntax accepted, see
     *             <code>gdire</code>
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    private boolean gdirec(Str s, boolean ext){
        int     nrlev;                            // number of levels
        int     start;                            // start of name
        int     nrcma;                            // number of commas
        int     i;
        boolean zero;
        boolean terr;
        char    close;
        char    c, t;

        gsep();                                   // skip separators
        terr = false;                             // error flag
        boolean found = false;
        l: {
            if ((CONCAT & this.mode) == 0)        // do not concatenate
                s.length = 0;
            if (this.cursor >= this.end){
                if (append() < 0) break l;        // end of data
            }
            if ((this.buffer[this.cursor] != '[') &&
                (this.buffer[this.cursor] != '<')){
                break l;                          // search [ or >
            }
            found = true;
            close = ']';
            if (this.buffer[this.cursor] == '<') close = '>';
            nrcma = nrlev = 0;
            lev: for (;;){                        // first syntax check
                this.cursor++;                    // step to next
                if (this.cursor >= this.end){
                    if (append() < 0){            // end of data, error
                        terr = true;
                        break l;
                    }
                }
                c = this.buffer[this.cursor];
                switch (c){
                    case '.': nrlev += 1; break;  // rekon the .
                    case ',': nrcma += 1; break;  // rekon the ,
                    case ']':
                    case '>': break;
                    default:
                        if (ext && ((c == '$') || (c == '_')))
                            break;
                        if ((c >= CH_MAX) ||
                            (CH_CAT[c] > CH_NUM)){
                            terr = true;
                            break l;
                        }
                }
                if ((c == ']') || (c == '>')) break lev;
            }
            this.cursor++;                        // skip the ]
            if (c != close){
                terr = true;
                break l;
            }
            if ((nrlev > (LEV_L-1)) ||            // check nr. of levels
                (nrcma > 1) ||                    // check nr. of ,
                ((nrlev > 0) && (nrcma > 0))){    // . and , together
                terr = true;
                break l;
            }
            i = this.start;
            scan: for (;;){
                if (s.length == s.buffer.length){
                    s.extend();
                }
                s.buffer[s.length++] = this.buffer[i];    // append
                i++;                                      // step on
                start = i;                                // start name or num
                if (nrcma == 0){                          // level directory notation
                    while ((this.buffer[i] < CH_MAX) &&   // analise name
                        ((CH_CAT[this.buffer[i]] <= CH_NUM) ||
                        (ext && ((this.buffer[i] == '$') ||
                        (this.buffer[i] == '_'))))){ 
                        t = this.buffer[i];
                        t = (t < 128) ? Str.UPPER[t] :
                            Character.toUpperCase(t);
                        if (s.length == s.buffer.length){
                            s.extend();
                        }
                        s.buffer[s.length++] = t;         // append
                        i++;
                    }
                    if ((start == i) ||                   // name not present
                        (i-start > DRN_L))                // name too long
                        terr = true;                      // error
                } else {                                  // uic
                    zero = true;                          // flag of firts digit > 0
                    while ((this.buffer[i] < CH_MAX) &&
                        ((CH_CAT[this.buffer[i]] <= CH_NUM) ||
                        (ext && ((this.buffer[i] == '$') ||
                        (this.buffer[i] == '_'))))){ 
                        if ((this.buffer[i] < '0') ||
                            (this.buffer[i] > '7')){
                            terr = true;
                            break l;
                        }
                        if (this.buffer[i] != '0'){  // first digit > 0
                            zero = false;
                            start = i;
                        }
                        if (!zero){
                            if (s.length == s.buffer.length){
                                s.extend();
                            }
                            s.buffer[s.length++] = this.buffer[i];  // append
                        }
                        i++;                                 // step on
                    }
                    if ((i > start) && zero){                // num = 0
                        if (s.length == s.buffer.length){
                             s.extend();
                        }
                        s.buffer[s.length++] = '0';          // append
                    } else {
                        if ((start == i) ||                  // number not present
                             ((i - start) > 3) ||            // more than 3 digits
                             ((i - start == 3) &&
                             (this.buffer[start] > '3'))){   // overflow
                             terr = true;
                             break l;
                        }
                    }
                }
                if ((this.buffer[i] == ']') || (this.buffer[i] == '>'))
                    break scan;
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = close;          // ]
        } // l
        if (terr){                                 // error
            this.mode |= ERROR;
            s.length = 0;
        }
        return found;
    }

    /** The number of bits per byte */
    private static final int BITSBYTE = 8;

    /** The mask to take the bit index part */
    private static final int MASK = 0x7;

    /** The number of shifts to take the byte index */
    private static final int NSHIFT = 3;

    /**
     * The <code>CharSet</code> represent restricted character sets.
     */

    public class CharSet {
        byte[]  sc;
        boolean negated;

        /**
         * Insert an element into this set.
         *
         * @param      u element
         */

        void set(char u){
            this.sc[u >>> NSHIFT] |= (1 << (u & MASK));
        }

        /**
         * Determine if an element is present in this set.
         *
         * @param      u element
         * @return     <code>true</code> if present
         */

        boolean get(char u){
            return (this.sc[u >>> NSHIFT] & (1 << (u & MASK))) != 0;
        }

        /**
         * Replace this set with its complement.
         */

        void complement(){
            for (int i = 0; i < this.sc.length; i++){
                this.sc[i] = (byte)~sc[i];
            }
        }

        /**
         * Assign this set. 
         *
         * @param      b false if the empty set, true if the full set
         */

        void assign(boolean b){
            if (b) {
                for (int i = 0; i < this.sc.length; i++){
                    this.sc[i] = -1;
                }
            } else {
                for (int i = 0; i < this.sc.length; i++){
                    this.sc[i] = 0;
                }
            }
        }

        /**
         * Create a CharSet.
         */

        CharSet(){
            this.sc = new byte[(CH_MAX + BITSBYTE - 1) / BITSBYTE];
            this.negated = false;
        }
    }

    /**
     * Assign a character set. It transforms a string denoting a set of
     * characters in the set. The string has the same syntax as the
     * set in the regexp, with the elimination of the enclosing square
     * brackets.
     *
     * @param      s string denoting the set.
     * @param      sc set to be assigned.
     */

    public static void setch(String s, CharSet sc){
        char    lower, upper;
        int     i, k;
        boolean neg;

        neg = false;
        k = 0;
        sc.assign(false);                             // empty the set
        if (s.length() == 0) return;
        if (s.charAt(0) == '^'){
            k++;
            neg = true;
        }
        if ((k < s.length()) && (s.charAt(k) == '-')) // real -
            sc.set(s.charAt(k++));
        if ((k < s.length()) && (s.charAt(k) == ']')) // real ]
            sc.set(s.charAt(k++));
        while ((k < s.length()) && (s.charAt(k) != ']')){
            if ((s.charAt(k) == '-') &&
                (s.length() > 2) &&
                (s.charAt(1) != ']')){                // range x-y
                k++;
                lower = (char)(s.charAt(k-2) + 1);    // x+1, x already stored
                upper = s.charAt(k++);                // y
                while (lower <= upper){
                    sc.set(lower++);                  // all character in range
                }
            } else if ((s.charAt(k) == '\\') &&
                (s.length() > 2)){                    // escaped char
                k++;
                sc.set(s.charAt(k++));
            } else sc.set(s.charAt(k++));
        }
        if (neg) sc.complement();                     // complement the  set
        sc.negated = neg;
    }

    /**
     * Get a token made of a set of characters. It gets a token made of
     * characters belonging to a set passed as argument.
     *
     * @param      s string denoting the set
     * @param      sc set of allowed characters
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gset(Str s, CharSet sc){
        return gsetn(s,sc,0);             // no restrictions on the length
    }

    /**
     * Get a bounded token made of a set of characters. It gets a token made
     * of characters belonging to a set passed as argument and not wider than
     * the number of characters passed as argument. 
     *
     * @param      s string denoting the set
     * @param      sc set of allowed characters
     * @param      max maximum length of token, 0: unlimited
     * @return     <code>true</code> if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token.
     */

    public boolean gsetn(Str s, CharSet sc, int max){
        gsep();                                   // skip separators
        if ((CONCAT & this.mode) == 0)            // do not concatenate
            s.length = 0;
        doit: do {
            if (this.cursor >= this.end){
                if (append() < 0){                // end of data
                    break doit;
                }
            }
            if ((this.cursor >= this.start + max) // max not yet reached
                && (max != 0)){                   // undefined max
                break doit;
            }
            char c = (this.buffer[this.cursor]);
            if (c > (char)CH_MAX){                // out of set
                if (!sc.negated) break;
            } else {
                if (!sc.get(c)) break;            // character not in the set
            }
            if (s.length == s.buffer.length){
                s.extend();
            }
            s.buffer[s.length++] = c;             // ]
            this.cursor++;                        // step to next
        } while (true);
        return this.cursor > this.start;          // true if token found
    }

    /**
     * Search a keyword in a (portion of) keytable. The keytable must be
     * ordered.
     *
     * @param      ktb keytable
     * @param      lo lower index, inclusive
     * @param      hi higher index, exclusive
     * @param      buf array containing the string to be searched
     * @param      off start index of the string in it
     * @param      len lenght of the string
     * @param      ign <code>true</code> to denote case insensitive search
     * @return     index of the key, -1 if not found
     */

    public static int searchKey(String[] ktb, int lo, int hi,
        char[] buf, int off, int len, boolean ign){

        int k = 0;
        int res = -1;
        hi--;
        while (lo <= hi){                    // binary search
            k = lo + (hi - lo ) / 2;         // middle index
            int ln = ktb[k].length();
            int i = Str.compareSlices(buf,buf.length,off,len,
                ktb[k],ln,0,ln,ign,false);
            if (i <= 0) hi = k-1;            // it is above
            if (i >= 0) lo = k+1;            // it is below
        }
        if (lo-1 > hi){                      // found
            res = k;
        }
        return res;
    }

    /**
     * Search a keyword in a (portion of) keytable. The keytable must be
     * ordered.
     *
     * @param      ktb keytable
     * @param      lo lower index, inclusive
     * @param      hi higher index, exclusive
     * @param      s string to be searched
     * @param      ign <code>true</code> to denote case insensitive search
     * @return     index of the key, -1 if not found
     */

    public static int searchKey(String[] ktb, int lo, int hi, Str s,
        boolean ign){
        return searchKey(ktb,lo,hi,
            s.buffer,0,(s.buffer == null) ? 0 : s.length,ign);
    }

    /**
     * Get one of the specified strings. The longest matched (if any) is returned.
     * If there are duplicates in the key array, return the last matched.
     * If the specified strings are identifiers, then the caller may want to check
     * that a successful match is not followed by characters that can belong to
     * identifiers (e.g. alphanumerics).
     *
     * @param      key array of strings
     * @param      s string in which the token is returned
     * @return     index in the key array if found. In this case <code>cursor</code>
     *             indicates the first character which does not belong to the
     *             token. Otherwise: -1
     */

    /* It is lengthy to generate a trie. Tries would need to be generated and then
     * remembered to be used several times. It uses instead the return string to hold the
     * indexes of the strings that matched some chars, and therefore are valid candidates
     * to test for further matching.
     */

    public int goneOf(String[] key, Str s){
        if ((FL_V & this.trc) != 0){
            trace("goneOf start");
        }
        gsep();                                     // skip separators
        int found = -1;
        if ((CONCAT & this.mode) == 0)              // do not concatenate
            s.length = 0;
        if (this.cursor >= this.end){
            if (append() < 0) return -1;            // end of data
        }
        int slength = s.length;
        s.enlarge(s.length+key.length);             // ensure there is space for key indexes
        boolean first = true;
        scan: for (int k = 0;;k++){                 // index in keys to match
            boolean match = false;
            char c = this.buffer[this.cursor];
            if (first){                             // first char: scan keys
                first = false;
                int j = slength;
                for (int i = 0; i < key.length; i++){
                    int len = key[i].length();
                    if (len == 0) continue;         // discard empty strings
                    if (key[i].charAt(0) == c){
                        match = true;
                        if (len == 1){
                            found = i;
                        } else {                    // remember string with first char matched
                            s.buffer[j++] = (char)i;
                        }
                    }
                }
                s.length = j;                       // remember end of indexes
            } else {
                int j = slength;
                for (int i = slength; i < s.length; i++){
                    int n = s.buffer[i];
                    if (key[n].charAt(k) == c){
                        match = true;
                        if (key[n].length() == k+1){
                            found = n;
                        } else {                    // remember string with char matched
                            s.buffer[j++] = (char)n;
                        }
                    }
                }
                s.length = j;                       // remember end of indexes
            }
            if ((FL_V & this.trc) != 0){
                Trc.out.printf("matching %d-th:",k);
                for (int i = slength; i < s.length; i++){
                    Trc.out.printf(" %d",(int)s.buffer[i]);
                }
                Trc.out.printf("%n");
            }
            if (match) this.cursor++;               // step to next
            if (s.length == slength){               // no more keys to match
                break;
            }
            if (!match) break;
            if (this.cursor >= this.end){
                if (append() < 0) break;            // end of data
            }
        }
        s.length = slength;                         // restore return string
        if (found < 0){
            restore();
        } else {
            s.cutInsert(slength,slength,this.buffer,this.end,   // copy return string
                this.start,this.cursor - this.start);
        }
        if ((FL_V & this.trc) != 0){
            trace("goneOf return",found >= 0);
        }
        return found;
    }
}
