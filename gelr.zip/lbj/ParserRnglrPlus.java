/*
 * @(#)ParserRnglrPlus.jpp       1.0 2000/07/01
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLRTables.*;
import lbj.ParserGLRengine;

/**
 * The <code>ParserRnglrPlus</code> class provides the RNGLR for EBNF structyred parsing algorithm.
 *
 * @author  Angelo Borsotti
 * @version 1.0   1 Jul 2020
 */

class ParserRnglrPlus extends ParserGLRengine {

    // Access to GSS nodes and edges
    private static final int NODE_EDGES = QUANTUM;
    private static final int EDGE_TO = 1;
    private static final int EDGE_SPPF = 2;

    /** 
     * Construct a parser for the specified grammar and lexicon.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    public ParserRnglrPlus(ParserTables tab, Object inp, String flags, String algo){
        setParserData(tab,inp,flags,algo);
    }

    /** 
     * Construct a parser for the specified grammar and lexicon.
     */

    public ParserRnglrPlus(){
    }

    /** 
     * Set the specified parser data.
     *
     * @param      tab reference to the general parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo kind of parser
     */

    @Override
    protected void setParserData(ParserTables tab, Object inp, String flags, String algo){
        this.tab = tab;
        this.tablr = (ParserLRTables.LALRRNFAtables)this.tab.pilot.lrTables;
        this.lex = new ParserLex(tab,inp);
        this.algo = algo;
        settrc(flags);
        EOF = this.tab.numOfToks;
    }

    /**
     * Deliver a string representing the specified GSS node.
     *
     * @param      itm index of the node
     * @return     string
     */

    @Override
    protected String itemToString(int itm){
        int dt = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)];
        StringBuilder sb = new StringBuilder();
        java.util.Formatter f = new java.util.Formatter(sb);
        f.format("%s [%s]",itm,dt);
        int tok = 0;
        for (int e = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES]; e != 0; e = gssEdgeDir[(e)>>>NSHF][((e)&MSK)]){
            f.format(", %d%s",e,edgeToString(e,tok));
        }
        return sb.toString();
    }

    /**
     * Deliver a string representing the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    @Override
    protected String edgeToString(int edge, int tok){
        if (edge == 0){
            return "";
        }
        int le = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        String sbs = esToString(edge,tok,true);
        return String.format("(to: %d s: %s)",le,sbs);
    }

    /**
     * Deliver a string representing the sppf of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @return     string
     */

    private String esToString(int edge, int tok){
        return esToString(edge,tok,false);
    }

    /**
     * Deliver a string representing the sppf of the specified GSS edge.
     *
     * @param      edge index of the edge
     * @param      tok number of the token, if the GSS edge is labelled with EOF
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    private String esToString(int edge, int tok, boolean full){
        if (edge == 0){
            return "";
        }
        return sToString(gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],tok,full);
    }

    /**
     * Deliver a string representing the sppf of the specified edge.
     *
     * @param      edge edge
     */

    protected String edgeSppfToString(int edge){
        return String.format("[%d %s]",gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],sToString(gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)],0,false));
    }

    /**
     * Deliver a string representing the specified sppf.
     *
     * @param      su sppf
     * @param      tok number of the token, if the sppf represents the EOF
     * @param      full <code>true</code> to have a more verbose string, </code>false</code>
     *             otherwise
     * @return     string
     */

    private String sToString(int su, int tok, boolean full){
        if (su == 0) return "";
        String sbs = Integer.toString(su);
        if (su < 0){                           // token
            int tn = 0;
            int ln = 0;
            if (tok == tab.numOfToks){ // eof
                tn = tab.numOfToks;
                ln = tab.numOfToks;
            } else {
                tn = getTokNr(su);
                ln = getLexNr(su);
            }
            sbs = tab.tokLitName(tn);
            if (ln != tn) sbs += "," + getLexeme(ln);
            long pt = getPoint(su);
            if (pt >= 0) sbs += "," + pt;
        } else if (su == 0){      // nullable nt
            sbs = "e-nt";
        } else {
            sbs = "" + (su & ~HEADF);
            if (full){
                if ((su & HEADF) != 0){          // already encoded
                    su &= ~HEADF;
                    sbs += "t";
                    if (isAlt(su)){
                        int nru = this.tree[(su)>>>NSHF][((su)&MSK)] & ~HEADSYM;
                        for (int i = 0; i < nru; i++){
                            sbs += i == 0 ? "" : "|";
                            // this should be derToString(i+su ?
                            sbs += " " + derToString(i,0,null);
                        }
                    } else {
                        sbs += " " + derToString(su,0,null);
                    }
                } else {                         // sppf gss
                    boolean first = true;
                    for (int i = su & ~HEADSYM;;){
                        if (!first) sbs += " |";
                        first = false;
                        int len = gssEdgeDir[(i+1)>>>NSHF][((i+1)&MSK)] & ~HEADF;          // length of phrase of derivation
                        int nt = len & ELR_TREE_NT;
                        sbs += " " + this.tab.gramSymToString(nt) +
                            " ::= " + sppfRuleToString(i,false);
                        i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)] & ~HEADSYM;
                        if (i == 0) break;
                    }
                }
            } else {
                if ((su & HEADF) != 0){          // already encoded
                    su &= ~HEADF;
                    if (isAlt(su)){
                        sbs = getLitName(this.tree[(su+1)>>>NSHF][((su+1)&MSK)]);
                    } else {
                        sbs = getLitName(su);
                    }
                } else {                         // sppf gss
                    int len = gssEdgeDir[(su+1)>>>NSHF][((su+1)&MSK)] & ~HEADF;
                    int nt = len & ELR_TREE_NT;
                    sbs = this.tab.gramSymToString(nt) + "/" + su;
                }
            }
        }
        return sbs;
    }

    /**
     * Add a GSS node if none exist in the current level with the specified state,
     * and possibly an edge to the specified node, if none exists, with the specified sppf.
     *
     * @param      st pilot state
     * @param      le to node, 0 if none
     * @param      sppf sppf of the edge
     * @param      dupl 0: do not check if another node with the same state is present
     * @return     length
     */

    /* N.b. with dupl = 0 it keeps note of the added node in the stater, i.e. it does not
     * use the hash table, and this is used in the lr dyn mode avoiding to reinitialize
     * // then the hash table should it instead have been used
     */

    @Override
    protected int addNode(int st, int le, int sppf, int dupl){
        ;
        addNodeNr++;
        ;

        ;
        this.addedEdge = -1;
        int itm = 0;
        int hfunct = 0;
        int l = 0;
        boolean found = false;
        search: {
            if (dupl == 0){
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm = this.stater[st];
            if (itm < this.absLevelGss){   // an item with the same dot not present
                this.stater[st] = this.gssNodeNr + this.delta;  // remember the first one
                break search;
            }
            itm -= this.delta;
            found = true;
        } // search
        boolean pedfound = false;
        boolean tohash = false;
        ;
        add: if (found){
            ;
            if (le == 0) break add;
            // add the new pedigree if not already there
            int prev = searchNodeEdge(itm,le);
            if (prev == -1){            // found
                pedfound = true;
                break add;
            } else if (prev == -2){     // not found, to be hashed
                tohash = true;
                prev = 0;
            }
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
            gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = sppf;
            this.gssEdgeNr = l + EDGE_FIELDS;
            // prepend new edge
            if (prev == 0){
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] & 0x7fffffff;
                gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] = tohash ? (l | 0x80000000) : l;
            } else {
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)];
                gssEdgeDir[(prev)>>>NSHF][((prev)&MSK)] = l;
            }
            ;
            this.addedEdge = l;
        } else {
            l = 0;
            addedge: {
                if (le == 0) break addedge;
                // create new node and edge
                if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                    enlargeGSS(1);
                }
                l = this.gssEdgeNr;
                gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
                gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = le;
                gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = sppf;
                this.gssEdgeNr = l + EDGE_FIELDS;
                this.addedEdge = l;
            }
            if (this.gssNodeNr >= this.gssNodeLength){
                enlargeGSS(0);
            }
            int n = this.gssNodeNr++;
            int[] block = this.gssNodeDir[n >>> NSHF];
            int off = n & MSK;
            block[off] = st;
            block[off+NODE_EDGES] = l;
            itm = n;
            ;
            this.items++;
        }
        if (!pedfound && tohash){
            hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                int newlen = this.edgeshlink.length << 1;
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = itm;
        }
        if (found) itm = -itm;
        return itm;
    }

    /**
     * Search an edge from the specified GSS node to the other specified GSS node.
     *
     * @param      itm  from node
     * @param      le   to node
     * @return     index of the edge
     */

    @Override
    protected int searchNodeEdge(int itm, int le){
        int hfunct = 0;
        int prev = 0;                
        add: {
            int edg = gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES];
            if (edg >= 0){     // >= 0 when a node is created with no edges, ..
                               // and then an edge is added it must not be hashed
                ;
                int len = 0;
                for (int i = edg; i != 0;
                    i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)],
                    len++){
                    int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                    if (lef == le){
                        ;
                        prev = -1;                
                        this.addedEdge = -i;
                        break add;
                    } else if (lef > le){     // (A) keep pedigrees in ascending left ordering to speed search
                        break;
                    }
                    prev = i;
                }
                if (len > 20){
                    //nrsearchNodeEdgerehash++;
                    // put the list in the hash table
                    for (int i = edg; i != 0;
                        i = gssEdgeDir[(i)>>>NSHF][((i)&MSK)]){
                        int lef = gssEdgeDir[(i+EDGE_TO)>>>NSHF][((i+EDGE_TO)&MSK)];
                        hfunct = (itm*31 + lef) & (this.edgeshdir.length - 1);
                        int z = i - this.levelEdgeGss;      // relative to level
                        if (z >= this.edgeshlink.length){
                            int newlen = this.edgeshlink.length << 1;
                            if (z > newlen) newlen = z + 1;
                            this.edgeshlink = Arrays.copyOf(this.edgeshlink,newlen);
                            this.edgeshdata = Arrays.copyOf(this.edgeshdata,newlen);
                        }
                        this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
                        this.edgeshdir[hfunct] = i + this.deltaEdges;
                        // use edgeshdata[] to hold the start node
                        this.edgeshdata[z] = itm;
                    }

                    prev = -2;         // to hash
                    gssNodeDir[(itm)>>>NSHF][((itm)&MSK)+NODE_EDGES] |= 0x80000000;
                }
            } else {      // < 0: it has a long list
                hfunct = (itm*31 + le) & (this.edgeshdir.length - 1);
                for (int z = this.edgeshdir[hfunct];
                    z >= this.absLevelGssEdges; z = this.edgeshlink[z-this.absLevelGssEdges]){
                    int edge = z - this.deltaEdges;
                    if (this.edgeshdata[z-this.absLevelGssEdges] == itm &&
                        gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)] == le){
                        prev = -1;                
                        this.addedEdge = -edge;
                        break add;
                    }
                }
                prev = -2;         // to hash
            }
        } // add
        ;
        return prev;
    }

    /**
     * Create a new GSS node for the specified state in the current level, and possibly an
     * edge to another node with the specified sppf.
     *
     * @param      state pilot state for the node
     * @param      to to node, 0 if none
     * @param      tree sppf
     * @return     index of the node
     */

    @Override
    protected int newGSSENode(int state, int to, int tree){
        ;
        int l = 0;
        if (to != 0){
            if (this.gssEdgeNr+EDGE_FIELDS > this.gssEdgeLength){
                enlargeGSS(1);
                /*
                TRACE(M,"newGSSENode enlarged %d blocks: %s\n",
                    this.gssEdgeNr,gssBlocksToString());
                */
            }
            l = this.gssEdgeNr;
            gssEdgeDir[(l)>>>NSHF][((l)&MSK)] = 0;
            gssEdgeDir[(l+EDGE_TO)>>>NSHF][((l+EDGE_TO)&MSK)] = to;
            gssEdgeDir[(l+EDGE_SPPF)>>>NSHF][((l+EDGE_SPPF)&MSK)] = tree;
            this.gssEdgeNr = l + EDGE_FIELDS;
        }

        if (this.gssNodeNr >= this.gssNodeLength){
            enlargeGSS(0);
        }
        int n = this.gssNodeNr++;
        int[] block = this.gssNodeDir[n >>> NSHF];
        int off = n & MSK;
        block[off] = state;
        block[off+NODE_EDGES] = l;

        if (to != 0){
            int hfunct = (n*31 + to) & (this.edgeshdir.length - 1);
            int z = l - this.levelEdgeGss;      // relative to level
            if (z >= this.edgeshlink.length){
                this.edgeshlink = Arrays.copyOf(this.edgeshlink,this.edgeshlink.length << 1);
                this.edgeshdata = Arrays.copyOf(this.edgeshdata,this.edgeshdata.length << 1);
            }
            this.edgeshlink[z] = this.edgeshdir[hfunct];  // insert at beginning
            this.edgeshdir[hfunct] = l + this.deltaEdges;
            // use edgeshdata[] to hold the start node
            this.edgeshdata[z] = n;
        }

        this.stater[state] = n + this.delta;
        ;
        // nrOfNodes++;
        this.items++;
        ;
        return n;
    }

    /**
     * Print the statistics.
     *
     * @param   print stream
     */

    @Override
    public void statistics(PrintWriter trc){
        trc.printf("lrsmode %s lrsmode1 %s lrdmode %s ndetmode %s mloopnr %s\n",
            lrsmode,lrsmode1,lrdmode,ndetmode,mloopnr);
        trc.printf("mode tokens: %s mode reductions %s\n",
            Arrays.toString(modetoks),Arrays.toString(modereds));
    }

    /** The reference to the LR parse tables. */
    ParserLRTables.LALRRNFAtables tablr;

    /**
     * Parse the input from the lexer that was specified at object construction
     * time.  Return whether the parsing ended successfully.
     *
     * @return <code>true</code> if the parsing succeeds, and <code>false</code> otherwise.
     */

    public boolean parse(){
        ;
        ;
        enlargeGSS(0);                        // create first gss blocks
        enlargeGSS(1);
        this.levelGss = 2;                    // this serves to make makeSentinel below work
        this.gssNodeNr = 0;
        this.gssEdgeNr = 1;                   // for edges hash: 0 = null
        makeSentinel();                       // create a sentinel
        this.loc = 1;

        this.stater = new int[this.tablr.stateNr]; // what states are already in the current level
        boolean res = false;
        this.level = 1;
        this.levelGss = this.gssNodeNr;
        this.absLevelGss = this.levelGss;
        this.delta = 0;
        this.levelEdgeGss = this.gssEdgeNr;
        this.deltaEdges = 0;
        this.absLevelGssEdges = this.levelEdgeGss;
        this.levelEdgeGss = this.gssEdgeNr;
        this.etrees = new int[this.tab.numOfNts];
        this.reduceWl = new int[400];
        this.reduceWli = 0;

        this.encodetreestack = new int[this.tablr.longestRule];

        // create an initial ParseTop with grammar-initial-state,
        // set active-parsers to contain just this
        int first = newGSSENode(0,0,0);         // create a node for the start state
        ;

        this.potter = new int[60];

        this.currentToken = tokenizer();
        int potlen = 0;

        // for each input symbol
        mainloop: for (;;){
            ;
            if (this.currentToken < 0) break;

            int topmostParsers = this.gssNodeNr - this.levelGss;
            int newNode = 0;
            int parser = 0;
            int oldparser = 0;

            if (this.tablr.lr1kind == 1){            // lr modes on
                tryDeterministic: while (topmostParsers == 1){   // same as if ()for(;;)

                    // see if static lr mode applicable
                    parser = this.gssNodeNr - 1;
                    int spar = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)];
                    boolean isfront = ((this.tablr.isFrontierStates[(spar)>>>ParserTables.NSHIFTB] & (1 << (spar& ParserTables.MASKB))) != 0);
                    ;
                    if (isfront){
                        // there is only one gss node = one parser, and it has a frontier state
                        ;
                        int edge = gssNodeDir[(parser)>>>NSHF][((parser)&MSK)+NODE_EDGES];
                        edge &= ~0x80000000;
                        if (gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)] == 0){
                            int lev = this.level;
                            int prevedge = this.gssEdgeNr;
                            int lrstate = parseLR();
                            if (lrstate < 0){
                                this.gssNodeNr = this.levelGss;  // make it fail
                                break mainloop;
                            }
                            ;
                            if (this.level > lev && this.gssNodeNr > this.levelGss){ // new level needed
                                this.level--;
                                makeSentinel();
                                this.level++;
                                this.levelGss = this.gssNodeNr;
                                this.absLevelGss = this.levelGss + this.delta;
                                this.levelEdgeGss = this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                            } else {
                                // replace the node
                                this.stater[gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)]] = 0;   // remove the pointer to the node
                                this.gssNodeNr--;
                                int curEdgeNr = this.gssEdgeNr;
                                this.gssEdgeNr = prevedge;
                                this.delta += 1;       // roll up total delta
                                this.absLevelGss = this.levelGss + this.delta;
                                this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                                // adjust the sentinel
                                gssNodeDir[(this.levelGss-2)>>>NSHF][((this.levelGss-2)&MSK)] = -this.level;
                            }
                            // no need to check for duplicates
                            newNode = addNode(lrstate,gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)],this.LRtree,0);
                            parser = newNode;
                        }
                    }
                    // lr dynamic mode
                    ;
                    int lrres = parseLRdyn();
                    if (lrres == -2) return false;
                    newNode = this.gssNodeNr-1;
                    oldparser = 0;
                    if (lrres == -1) break tryDeterministic;
                    if (lrres == -3) break mainloop;
                    if (lrres == 0){
                        parser = newNode;
                        this.currentToken = tokenizer();
                        continue mainloop;
                    }
                } // tryDeterministic
            } 

            // repeatedly run the reducer, and the scanner to save tokens
            int lexstore = 0;
            potlen = 0;                            // initialise pot for next list
            int start = newNode;
            if (start == 0) start = this.levelGss;
            int i = start;
            this.reduceWldp = 0;
            clo: for (;;){
                boolean advanceList = false;
                cloloop: if (i < this.gssNodeNr){
                    advanceList = true;
                    // process shifts and reductions
                    int state = gssNodeDir[(i)>>>NSHF][((i)&MSK)];
                    int flen = this.tablr.LRbase[state];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                    ;

                    boolean nonZeroReduction = false;
                    // process the empty reductions and save the shifts, if any
                    for (int j = 0; j < flen; j++){
                        int act = this.tablr.LRtable[fstart+j];
                        ;
                        if (act >= ParserLRTables.ISREDUCE){          // reduction
                            int rule = act & ParserLRTables.RULEMASK;
                            int m = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
                            if (m == 0){                          // empty reduction
                                int nt = (act >> ParserLRTables.NTSHIFTS) & ParserLRTables.NTMASK;
                                ;
                                reducer(i,rule,0,0,false);
                            } else {
                                nonZeroReduction = true;
                            }
                        } else {                  // shift
                            // put it in potter
                            if (potlen >= this.potter.length){
                                this.potter = Arrays.copyOf(this.potter,this.potter.length << 1);
                            }
                            // there is no need here to check if there is already such a shift
                            // in potter: at the worst we will try twice the same shift
                            this.potter[potlen++] = act;   // new state
                            this.potter[potlen++] = i;     // item to be advanced
                            lexstore |= act;
                            ;
                        }
                    }
                    // process the nonempty reductions (if any): do them down to
                    // all the edges
                    if (nonZeroReduction){
                        ;
                        for (int edge = gssNodeDir[(i)>>>NSHF][((i)&MSK)+NODE_EDGES]; edge != 0; edge = gssEdgeDir[(edge)>>>NSHF][((edge)&MSK)]){
                            edge &= ~0x80000000;           // remove hash mark
                            ;
                            for (int j = 0; j < flen; j++){
                                int act = this.tablr.LRtable[fstart+j];
                                if (act < ParserLRTables.ISREDUCE) continue; // not a reduction
                                int rule = act & ParserLRTables.RULEMASK;
                                int m = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
                                if (m == 0) continue;                    // empty reduction
                                if (gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)] == 0) continue;
                                reducer(i,rule,m,edge,false);
                            }
                        }
                    }
                } else if (this.reduceWldp != this.reduceWli){
                    ;
                    ;
                    int itm = this.reduceWl[this.reduceWldp++];
                    int ru = this.reduceWl[this.reduceWldp++];
                    int mm = this.reduceWl[this.reduceWldp++];
                    int ed = this.reduceWl[this.reduceWldp++];
                    for (int j = 0; j < mm; j++){
                        // the entry in the compressed table
                        int act = this.tablr.LRtable[ru+j];
                        if (act >= ParserLRTables.ISREDUCE){          // reduction
                            int rule = act & ParserLRTables.RULEMASK;
                            int m = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
                            if (m == 0) continue;                 // empty reduction
                            reducer(itm,rule,m,ed,true);
                        }
                    }
                    this.currentRed = this.reduceWldp;
                } else {
                    break;
                } // cloloop
                if (advanceList){
                    i++;
                }
            } // clo

            this.absReduceWli += this.reduceWli;
            this.reduceWli = 0;
            ;

            ;
            //Trc.out.printf("lev: %d levelGss %d absLevelGss %d\n",
            //    this.level,this.levelGss,this.absLevelGss);
            //tracerItemsList(this.levelGss-2);
            makeSentinel();
            this.level++;
            ;
            ;

            this.levelGss = this.gssNodeNr;
            this.absLevelGss = this.levelGss + this.delta;
            this.levelEdgeGss = this.gssEdgeNr;
            this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
            int z = 0;
            if (this.currentToken != EOF){
                z = saveToken(lexstore);      // eof cannot be encoded
            }
            ;
            for (int k = 0; k < potlen;){             // scan the potter
                int newState = potter[k++] & 0xfffffff;
                int toadvance = potter[k++];
                int w = addNode(newState,toadvance,z,1);
                if (w < 0) w = -w;
                ;
            }
            ;
            if (this.gssNodeNr == this.levelGss){    // kernel empty
                break;
            }
            if (this.currentToken == EOF){
                break;                               // eof
            }
            int nexttoken = tokenizer();
            if (nexttoken < 0) break;

            this.currentToken = nexttoken;
        } // mainloop
        ;
        // we come here either with a token that has not been recognized. i.e.
        // no parsers could shift it, or with an EOF shifted, i.e. a node for the
        // state that has S'-> S EOF .
        ;
        rec: if (this.gssNodeNr - this.levelGss != 1){
            res = false;
        } else {
            if (this.currentToken != EOF){
                res = false;
                break rec;
            }
            res = true;
            int e = gssNodeDir[(this.levelGss)>>>NSHF][((this.levelGss)&MSK)+NODE_EDGES];
            int to = gssEdgeDir[(e+EDGE_TO)>>>NSHF][((e+EDGE_TO)&MSK)];
            ;

            e = gssNodeDir[(to)>>>NSHF][((to)&MSK)+NODE_EDGES];
            ;
            if (gssEdgeDir[(e+EDGE_SPPF)>>>NSHF][((e+EDGE_SPPF)&MSK)] == 0){
                int startnt = this.tab.grammar[this.tab.startRule];
                encodeEtree(startnt);  // return sppf in etrees[startnt]
            } else {
                encodetree(gssEdgeDir[(e+EDGE_SPPF)>>>NSHF][((e+EDGE_SPPF)&MSK)]);     // produce parse tree
            }
        }
        makeSentinel();     // close the gss
        ;

        return res;
    }

    /**
     * Deliver a string representing the specified parser action.
     *
     * @param      act action
     * @return     string
     */

    private String actToString(int act){
        if (act >= ParserLRTables.ISREDUCE){          // reduction
            int rule = act & ParserLRTables.RULEMASK;
            int m = (act >> ParserLRTables.BEFSHIFTS) & ParserLRTables.BEFMASK;
            return "reduction rule " + ruleToString(rule) + " " +
                (m == 0 ? " empty" : m+" elements");
        }
        return "shift to state " + (act & ~(ParserLRTables.SAVELEX | ParserLRTables.SAVEPOS));
    }

    /**
     * Perform all reductions from the specified firstitm GSS node and down
     * the specifed edge, or no edge if the reduction has length zero.
     *
     * @param   firstitm GSS node from which the reduction starts
     * @param   rule rule to reduce
     * @param   m number of elements to reduce
     * @param   start edge of firstitm down which the reduction is made, if
     *          the length of the reduction is not zero, and 0 otherwise.
     * @param   rwl <code>true</code> if the reduction is done from the rwl
     */

    private void reducer(int firstitm, int rule, int m, int start, boolean rwl){
        ;
        int mm = (m != 0) ? m - 1 : 0;
        this.reusablePathsLength = 0;
        // getting the paths from start makes parse times much longer because a lot more paths
        // are found: all the ones that passes for all neighbours of start, and not only from v,
        // so, we get instead the paths starting at v
        int second = firstitm;
        if (m > 0) second = gssEdgeDir[(start+EDGE_TO)>>>NSHF][((start+EDGE_TO)&MSK)];
        ;

        int origitem = second;
        ;

        // allocate pathIterator to the max derlen
        if (this.pathIterator == null || this.pathIterator.length < this.tablr.longestRule){
            this.pathIterator = new int[this.tablr.longestRule];
        }
        int[] pathit = this.pathIterator;
        int lev = 0;
        if (m > 0){
            pathit[lev++] = start;
        }
        boolean first = true;
        int ed = gssNodeDir[(second)>>>NSHF][((second)&MSK)+NODE_EDGES] & 0x7fffffff;
        boolean nullrule = mm == 0;
        // nullrule here means that there are no edges, i.e. the path is empty
        allph: for (;;){                            // visit all paths
            makepath: {
                up: if (first){
                    if (nullrule){
                        ;
                        break makepath;
                    }
                    pathit[lev++] = ed;
                    first = false;
                } else {
                    ;
                    // build next path
                    // go up until it is possible to go sideways
                    while (lev > 1){
                        ed = pathit[--lev];
                        ;
                        ed = gssEdgeDir[(ed)>>>NSHF][((ed)&MSK)];
                        if (ed != 0){
                            pathit[lev++] = ed;
                            break up;
                        }
                    }
                    break allph;               // no more paths
                }
                // go down to bottom
                while (lev < m){
                    int le = gssEdgeDir[(ed+EDGE_TO)>>>NSHF][((ed+EDGE_TO)&MSK)];
                    ;
                    le = gssNodeDir[(le)>>>NSHF][((le)&MSK)+NODE_EDGES] & 0x7fffffff;
                    pathit[lev++] = le;
                    ed = le;
                }
            } // makepath

            // store
            //      length  edge edge ...   end-node start-node rule-nr
            //      0       1    2          length+1 +2         +3
            if (this.reusablePath == null){
                this.reusablePath = new int[this.tablr.longestRule+5];
            }
            int[] dst = this.reusablePath;
            if (m == 0){
                dst[0] = 0;
                dst[1] = origitem;
                dst[2] = origitem;
                dst[3] = rule;
            } else {
                dst[0] = lev;
                int rlen = (int)this.tab.ruleLen[rule];
                if (lev < rlen){                       // there are e-nts
                    int d = rlen;
                    int i = lev-1;
                    for (int r = 0; r < rlen; r++){
                        if (r >= lev){
                            dst[d--] = 0;
                        } else {
                            int el = pathit[i--];
                            dst[d--] = gssEdgeDir[(el+EDGE_SPPF)>>>NSHF][((el+EDGE_SPPF)&MSK)];
                        }
                    }
                    dst[0] = rlen;
                } else {
                    for (int i = 0; i < lev; i++){
                        dst[i+1] = gssEdgeDir[(pathit[i]+EDGE_SPPF)>>>NSHF][((pathit[i]+EDGE_SPPF)&MSK)];
                    }
                }
                dst[rlen+1] = lev == 1 ? origitem : gssEdgeDir[(pathit[lev-1]+EDGE_TO)>>>NSHF][((pathit[lev-1]+EDGE_TO)&MSK)];
                dst[rlen+2] = origitem;
                dst[rlen+3] = rule;
            }
            int[] path = this.reusablePath;
            int len = path[0];
            int u = path[len+1];                   // to node
            int k = gssNodeDir[(u)>>>NSHF][((u)&MSK)];
            int nt = this.tab.ruleToNt[rule];
            int lrbase0= this.tablr.LRbase[k];int pl = this.tablr.LRcheck[lrbase0+nt] == lrbase0 ? this.tablr.LRtable[lrbase0+nt] : 0;;
            ;

            int w = addNode(pl,u,0,1);
            if (this.addedEdge >= 0) edgesize += 6;
            red: if (this.addedEdge >= 0){         // edge added
                gssEdgeDir[(this.addedEdge+EDGE_SPPF)>>>NSHF][((this.addedEdge+EDGE_SPPF)&MSK)] = addSymGSSnode(path,0,true);
                if (w < 0){                        // new node not added, only edge added
                    if (m != 0){
                        w = -w;
                        addred: if (!rwl && w == firstitm){
                            ;
                            if (gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)+NODE_EDGES] >= 0){         // short list
                                if (gssEdgeDir[(this.addedEdge+EDGE_TO)>>>NSHF][((this.addedEdge+EDGE_TO)&MSK)] > gssEdgeDir[(start+EDGE_TO)>>>NSHF][((start+EDGE_TO)&MSK)]) break addred;
                            }                          // long list: new edge prepended
                            int flen = this.tablr.LRbase[gssNodeDir[(firstitm)>>>NSHF][((firstitm)&MSK)]];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                            if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                                ParserLRTables.ISREDUCE){
                                // enqueue only if there are reductions (but there could be only empty ones)
                                addAllReductions(firstitm,fstart,flen,this.addedEdge);
                            }
                        }
                        int curItem = rwl ? this.gssNodeNr : firstitm;
                        if (w >= curItem) break red;  // node not yet processed
                        ;
                        // enqueue only nonempty reductions, i.e., the ones that have the added edge
                        int flen = this.tablr.LRbase[pl];int fstart = flen + this.currentToken+this.tab.tokBase;flen = this.tablr.LRcheck[fstart] == flen ? this.tablr.LRtable[fstart] : 0;if (flen> 0){flen= 1;} else if (flen < 0){fstart= -flen;flen = this.tablr.LRtable[fstart++];};
                        if (flen > 0 && this.tablr.LRtable[fstart+flen-1] >=
                            ParserLRTables.ISREDUCE){
                            // enqueue only if there are reductions (but there could be only empty ones)
                            addAllReductions(w,fstart,flen,this.addedEdge);
                        }
                    }
                }
            } else {
                addSymGSSnode(path,gssEdgeDir[(-this.addedEdge+EDGE_SPPF)>>>NSHF][((-this.addedEdge+EDGE_SPPF)&MSK)],true);
            }
            if (nullrule) break;
        }
        ;
    }

    void traceMutatedPath(int[] path){
        if (path == null){
            Trc.out.printf("no path");
        } else {
            int length = path[0];
            int tonode = path[length+1];
            int from = path[length+2];
            int rule = path[length+3];
            Trc.out.printf("from %d rule %s len: %d to %d\n",
                from,ruleToString(rule),length,tonode);
            for (int i = 1; i < length+1; i++){
                Trc.out.printf("  %d\n",path[i]);
                //... find a better way to trace this
            }
        }
    }

    protected int encodeEtree(int root){
        ;
        if (this.etrees[root] != 0){         // already done
            return this.etrees[root];
        }

        int loc = this.loc;
        int start = loc;
        int visitedNr = 0;                   // nr of nodes visited

        int dp = 0;
        int qp = 0;
        this.encodequeue[qp++] = root;       // enqueue root
        this.etrees[root] = -1;
        while (dp != qp){                        // while queue not empty
            int i = this.encodequeue[dp++];      // dequeue
            visitedNr++;
            ;

            this.etrees[i] = this.loc;           // remapping
            ;

            // get the number of rules
            int nrrules = this.tab.nullableNtRules[i];
            ;
            // store then the symbol node if needed
            int ruleInSym = 0;
            if (nrrules > 1){
                ;
                loc = this.loc;
                this.loc += nrrules + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = nrrules | HEADSYM;
                ruleInSym = loc + 1;
            }
            // visit the rules now
            for (int j = this.tab.ntToRule[i]; j < this.tab.ruleToNt.length; j++){
                if (this.tab.ruleToNt[j] != i) break;
                if (!((this.tab.nullableRules[(j)>>>ParserTables.NSHIFTB] & (1 << (j& ParserTables.MASKB))) != 0)) continue;  // not a nullable rule
                int rule = j;
                int p = this.tab.ruleIndex[rule];
                loc = this.loc;
                if (ruleInSym > 0){
                    this.tree[(ruleInSym)>>>NSHF][((ruleInSym)&MSK)] = loc;
                    ruleInSym++;
                }
                // reserve space in tree for rule
                int len = this.tab.ruleLen[rule];
                this.loc += len + 1;
                if (((this.loc-1) >>> NSHF) >= this.treeBlocks){
                    enlargeTree(this.loc);
                }
                // copy header
                ;
                this.tree[(loc)>>>NSHF][((loc)&MSK)] = rule | HEAD;
                loc++;
                for (int k = 0; k < len; k++){
                    int el = this.tab.grammar[p++];
                    ;
                    if (this.etrees[el] > 0){              // e-nt already encoded
                        el = this.etrees[el] | HEAD;
                    } else if (this.etrees[el] == 0){
                        // add it to queue to visit
                        ;
                        this.etrees[el] = -1;
                        if (qp >= this.encodequeue.length){
                            if (dp > 10){                   // shift down, if worth
                                System.arraycopy(this.encodequeue,dp,this.encodequeue,0,qp-dp);
                                qp -= dp;
                                dp = 0;
                            } else {                        // enlarge
                                this.encodequeue = Arrays.copyOf(this.encodequeue,this.encodequeue.length+100);
                            }
                        }
                        this.encodequeue[qp++] = el;        // enqueue it
                    }
                    this.tree[(loc)>>>NSHF][((loc)&MSK)] = el;
                    loc++;
                }
            }
        }

        // scan the rules stored above in the final parse tree and remap the references to
        // grammar nts to the ones in the parse tree
        ;

        for (int i = start; i < this.loc;){            // scan the tree
            ;
            int h = this.tree[(i)>>>NSHF][((i)&MSK)];
            if ((h & HEADF) == HEADSYM){               // symbol node
                int len = h & ~HEADSYM;
                this.altNum += len;
                i += len + 1;
            } else {
                int len = h & ~HEADF;                  // length of phrase of derivation
                if (this.tab.toOriginRule != null){
                    this.tree[(i)>>>NSHF][((i)&MSK)] = this.tab.toOriginRule[len] | HEAD;
                }
                // if (len < this.tab.numOfRules){     // not a repetition group
                    len = this.tab.ruleLen[len];       // fixed length
                // } else {                            // repetition group
                //     len -= this.tab.numOfRules;     // decode the length
                // }
                i++;
                int end = i + len;
                for (; i < end; i++){
                    int el = this.tree[(i)>>>NSHF][((i)&MSK)];
                    if ((el & HEADF) == HEAD){     // already built
                        el &= ~HEAD;
                    } else if (el >= 0){
                        ;
                        el = this.etrees[el];
                    }
                    this.tree[(i)>>>NSHF][((i)&MSK)] = el;
                }
                this.derNum++;
                this.eleNum += len;
            }
        }

        this.treeLen = this.loc;
        this.treeStart = start;

        return start;
    }

    private int parseLR(){
        int res = 0;
        int node = this.gssNodeNr - 1;       // the one with the frontier state
        ;
        int edge = gssNodeDir[(node)>>>NSHF][((node)&MSK)+NODE_EDGES];
        int state = gssNodeDir[(node)>>>NSHF][((node)&MSK)];           // its state
        state = this.tablr.frontierMap[state];  // go to state in canonical isle
        node = gssEdgeDir[(edge+EDGE_TO)>>>NSHF][((edge+EDGE_TO)&MSK)];
        int startstate = gssNodeDir[(node)>>>NSHF][((node)&MSK)];      // the junction one
        ;
        this.LRstackBottom = this.gssEdgeNr;
        // initialize the stack with the node that starts the LR parsing
        pushLRstack(state,gssEdgeDir[(edge+EDGE_SPPF)>>>NSHF][((edge+EDGE_SPPF)&MSK)]);
        for (;;){
            ;
            int lrbase1= this.tablr.LRbase[state];int action = this.tablr.LRcheck[lrbase1+this.currentToken+this.tab.tokBase] == lrbase1 ? this.tablr.LRtable[lrbase1+this.currentToken+this.tab.tokBase] : 0;;
            if (action <= 0){                 // no action
                // set the cursor in the input one token back because here we come with a token
                // that has been eaten, and is wrong, and the cursor is past to it
                this.lex.stream.reset();
                res = -1;
                break;
            }
            if (action >= ParserLRTables.ISREDUCE){  // reduce
                int rule = action & ParserLRTables.RULEMASK;
                int rhsLen = this.tab.ruleLen[rule];              // length of rule
                ;
                int z = 0;
                // for (b)rnglr no need to treat the case of rule with empty tail: it has a conflict
                z = encodeLRtree(rule);
                this.gssEdgeNr -= this.tab.ruleLen[rule] * 3;   // pop the stack
                // now move from the exposed state with the reduced nonterminal
                int nt = this.tab.ruleToNt[rule];
                int topstack = this.gssEdgeNr - 3;
                ;
                if (topstack < this.LRstackBottom){      // end of LR piece
                    int lrbase2= this.tablr.LRbase[startstate];int newState1 = this.tablr.LRcheck[lrbase2+nt] == lrbase2 ? this.tablr.LRtable[lrbase2+nt] : 0;;
                    ;
                    this.gssEdgeNr = this.LRstackBottom;
                    aga: {
                        int st = this.tablr.frontierMap[newState1];  // go to state in canonical isle
                        ;
                        if (st == 0) break aga;
                        pushLRstack(st,z);
                        state = st;
                        ;
                        continue;
                    }
                    this.LRtree = z | HEAD;
                    res = newState1;
                    break;
                }

                int lrbase3= this.tablr.LRbase[gssEdgeDir[(topstack)>>>NSHF][((topstack)&MSK)]];int newState = this.tablr.LRcheck[lrbase3+nt] == lrbase3 ? this.tablr.LRtable[lrbase3+nt] : 0;;
                pushLRstack(newState,z);
                state = newState;
            } else {                            // shift
                this.level++;
                ;
                int z = 0;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = -1;
                    break;
                }
                z = saveToken(action);          // eof cannot be encoded
                int newState = action & ParserLRTables.STATEMASK;
                pushLRstack(newState,z);
                state = newState;
                modetoks[this.pmode]++;
                this.currentToken = tokenizer();
                if (this.currentToken < 0){
                    res = -1;
                    break;
                }
            }
        }
        ;
        return res;
    }

    private int parseLRdyn(){
        int res = 0;
        int parser = this.gssNodeNr - 1;
        ;
        determin: {
            int lrbase4= this.tablr.LRbase[gssNodeDir[(parser)>>>NSHF][((parser)&MSK)]];int act = this.tablr.LRcheck[lrbase4+this.currentToken+this.tab.tokBase] == lrbase4 ? this.tablr.LRtable[lrbase4+this.currentToken+this.tab.tokBase] : 0;;
            ;
            if (act <= 0){
                ;
                res = -1;
                break determin;
            }
            if (act >= ParserLRTables.ISREDUCE){             // reduce
                int rule = act & ParserLRTables.RULEMASK;
                int rhsLen = this.tab.ruleLen[rule];              // length of rule
                if (((this.tab.cyclic[(this.tab.ruleToNt[rule])>>>ParserTables.NSHIFTB] & (1 << (this.tab.ruleToNt[rule]& ParserTables.MASKB))) != 0)){
                    res = -1;
                    break determin;
                }
                this.pmode = 2;
                modereds[this.pmode]++;
                ;
                int z = 0;
                // for (b)rnglr no need to treat the case of rule with empty tail: it has a conflict
                z = encodeLRdyntree(rule,this.gssNodeNr - 1);
                if (z < 0){
                    res = -1;
                    break determin;
                }
                int lookback = this.LRstackBottom;
                ;
                // pop the levels
                if (lookback < this.levelGss){           // in a level before the current one
                    // find the end of the level
                    int startNodelev = lookback;
                    startNodelev--;
                    while (gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)] >= 0) startNodelev--; 
                    ;
                    int curNodeNr = this.gssNodeNr;
                    int curEdgeNr = this.gssEdgeNr;
                    this.gssNodeNr = -gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)];  // deallocate nodes
                    this.gssEdgeNr = gssNodeDir[(startNodelev)>>>NSHF][((startNodelev)&MSK)+NODE_EDGES];     // and edges
                    this.levelGss = this.gssNodeNr;
                    this.delta += curNodeNr - this.gssNodeNr;       // roll up total delta
                    this.absLevelGss = this.levelGss + this.delta;
                    this.levelEdgeGss = this.gssEdgeNr;
                    this.deltaEdges += curEdgeNr - this.gssEdgeNr;
                    this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;

                    // adjust the sentinel
                    gssNodeDir[(this.gssNodeNr-1)>>>NSHF][((this.gssNodeNr-1)&MSK)] = -1;
                    ;
                } else {
                    // do not pop the current level: empty reduction
                }
                // create the new node
                int nt = this.tab.ruleToNt[rule];
                int lrbase5= this.tablr.LRbase[gssNodeDir[(lookback)>>>NSHF][((lookback)&MSK)]];int newState = this.tablr.LRcheck[lrbase5+nt] == lrbase5 ? this.tablr.LRtable[lrbase5+nt] : 0;;
                ;
                int newNode = addNode(newState,lookback,z|HEAD,0);
                if (newNode < 0) newNode = -newNode;
                if (this.addedEdge >= 0) edgesize += 6;
                res = newNode;
            } else if (act > 0) {
                // can shift unambiguously
                makeSentinel();
                this.level++;
                ;
                ;
                this.levelGss = this.gssNodeNr;
                this.absLevelGss = this.levelGss + this.delta;
                this.levelEdgeGss = this.gssEdgeNr;
                this.absLevelGssEdges = this.levelEdgeGss + this.deltaEdges;
                int z = 0;
                if (this.currentToken != EOF) z = saveToken(act);  // eof cannot be encoded
                int newState = act & ParserLRTables.STATEMASK;
                int newNode = addNode(newState,parser,z,0);
                if (this.addedEdge >= 0) edgesize += 6;
                if (newNode < 0) newNode = -newNode;
                ;
                if (this.currentToken == EOF){  // shifting the EOF: end of parse
                    ;
                    res = -3;
                    break determin;
                }
                // return to mainloop
                res = 0;
            }
        } // determin
        ;
        return res;
    }

    /** A GSS node. */
    private static class Gnode {

        /** The unique serial number of the object. */
        int serialnr;

        /** The level. */
        int level;

        /** The number of the pilot state. */
        int statenr;

        /** The head of the mirror edges. */
        Gedge edges;

        /** The reference to the next node. */
        Gnode next;

        /**
         * Deliver a string representing this object.
         *
         * @return   string
         */

        public String toString(){
            return this.serialnr + ":" + this.level + "/" + this.statenr;
        }
    }

    /** A GSS edge. */
    private static class Gedge {

        /** The reference to the end node. */
        Gnode tonode;

        /** The reference to the next edge. */
        Gedge nextedge;

        /** The label. */
        String sym;

        /**
         * Deliver a string representing this object.
         *
         * @return   string
         */

        public String toString(){
            return "-" + sym + "->" + tonode.serialnr;
        }
    }

    /** The GSS. */
    private static class GSS {

        /** The head of the list of nodes. */
        Gnode head;

        /** The tail of the list of nodes. */
        Gnode tail;

        /** The serial number of the nodes. */
        int serialnr;

        /**
         * Deliver a new node with the specified state.
         *
         * @param    s state
         * @return   node
         */

        Gnode newNode(int s){
            Gnode n = new Gnode();
            n.serialnr = this.serialnr++;
            n.statenr = s;
            return n;
        }

        /**
         * Add the specified node to the specified level.
         *
         * @param    n node
         * @param    l level
         */

        void add(Gnode n, int lev){
            n.level = lev;
            if (this.tail == null){
                this.head = n;
            } else {
                this.tail.next = n;
            }
            this.tail = n;
            Trc.out.printf("GSS add node %s\n",n);
        }

        /**
         * Find a node with the specified state in the specified level.
         *
         * @param    s state
         * @param    l level
         * @return   node, null if not present
         */

        Gnode find(int s, int lev){
            for (Gnode n = this.head; n != null; n = n.next){
                if (n.statenr == s && n.level == lev){
                    return n;
                }
            }
            return null;
        }

        /**
         * Find the edge between the specified nodes.
         *
         * @param    from from node
         * @param    to to node
         * @return   edge
         */

        Gedge findEdge(Gnode from, Gnode to){
            for (Gedge i = from.edges; i != null; i = i.nextedge){
                if (i.tonode == to){
                    return i;
                }
            }
            return null;
        }

        /**
         * Add an edge between the specified nodes.
         *
         * @param    from from node
         * @param    to to node
         * @param    l label
         * @return   edge
         */

        Gedge add(Gnode from, Gnode to, String l){
            Gedge e = new Gedge();
            e.tonode = to;
            e.sym = l;
            if (from.edges == null){
                from.edges = e;
            } else {
                e.nextedge = from.edges;
                from.edges = e;
            }
            Trc.out.printf("GSS add edge %s%s\n",from.serialnr,e);
            return e;
        }

        /**
         * Add all the nodes of the specified level to the specified list.
         *
         * @param    l level
         * @param    list list
         */

        void add(int l, LinkedList<Gnode> list){
            for (Gnode n = this.head; n != null; n = n.next){
                if (n.level == l){
                    list.add(n);
                }
            }
        }
    }

    /** A pair. */
    private static class Pair {

        /** The first element, a Gss node. */
        Gnode node;

        /** The first element, a number. */
        int number;

        /**
         * Deliver a new pair with the specified node and number.
         *
         * @param    n node
         * @param    nr number
         */

        Pair(Gnode n, int nr){
            this.node = n;
            this.number = nr;
        }

        /**
         * Deliver a string representing this object.
         *
         * @return   string
         */

        public String toString(){
            return "(" + this.node + "," + this.number + ")";
        }
    }

}
