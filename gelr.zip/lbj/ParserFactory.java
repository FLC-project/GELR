/*
 * @(#)ParserFactory.java       1.0 2020/06/26
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

/**
 * The <code>ParserFactory</code> class delivers a parser engine that uses the specified algorithm.
 *
 * @author  Angelo Borsotti
 * @version 1.0   26 Jun 2020
 */

class ParserFactory {

    /* This factory class, delivers pilots and parser engines for a given algorithm.
     * It looks up the algorithm and then builds the appropriate pilot and engine.
     * This allows to have some parsers in a dedicated class, and some others in ParserGLR,
     * allowing to move parsers step by step in dedicated classes.
     * Note that ParserLR is also a sort of factory: it creates a new instance of it and
     * then it calls build, that delivers an object with the appropriate lr tables.
     * This is so to keep all the variants of LR tables in a unique file.
     * ParserLR declares the specific ones as nested classes that access some outer data
     * (tab, trc, ...).
     * ParserFactory creates a ParserLR and makes it deliver the proper nested class.
     * However, some LR tables are delivered by ParserLALR. To have in the parser tables
     * a reference to the LR tables ParserLALR is a subclass of ParserLR.
     *
     * To instantiate the proper engine class and to generate the appropriate tables
     * there is a need to know what engine and what tables are associated to a given
     * parser algorithm.
     * They could be encoded in the algotithm name. E.g. ParserRnglrLarn could mean
     * that the rnglr algorithm has the ParserRnglrLarn engine and the larn pilot tables.
     * However, there could still be parsers like, e.g. the lr ones that differ only by
     * the pilot tables, but have the same code. A solution could be to state that the
     * engine class name is the first part of the algorith name, i.e. ParserRnglr in the
     * example above.
     * But there are other data that can hardly be encoded in the name, like, e.g. the
     * the parsergen flags, and the fact that it is a parser or a recognizer.
     * A list of parser data object allows to record a number of data concerning a parser
     * that can hardly be encoded in the name (which would become quite cryptic).
     * Recording for eacn parser the engine class name and the lr class namer, allows
     * to instantiate them without a switch in the factory.
     * Note that some data, like, e.g. the generation flags, are needed before the instantiation
     * of the specific parser class, so if the data were encoded in the parser name, there
     * whould be some means to get them from it.
     */

    /** The data of a parser. */
    private static class ParserData {

        /** The reference to the next object. */
        ParserData next;

        /** The name of the parser. */
        String name;

        /** The parser class. */
        Class parserClass;

        /** The LR class of the parser. */
        Class pilotClass;

        /** The pilot kind. */
        int pilotKind;

        /** The pilot options. */
        String pilotOpt;

        /** The generation flags to be set mandatorily. */
        int prsmode;

        /** The generation flags to be cleared mandatorily. */
        int prsnomode;

        /** Whether the parser generates a forest. */
        boolean forest;
    }

    /** The head of the list of parsers. */
    static ParserData parsersHead;

    /** The tail of the list of parsers. */
    static ParserData parsersTail;

    /**
     * Declare a parser with the specified data.
     *
     * @param      name name of the parser
     * @param      pclass class of the parser implementation
     * @param      lclass class of the lr pilot
     * @param      lkind kind of lr pilot
     * @param      lopt pilot options
     * @param      prsmode generation flags to be set
     * @param      prsnomode generation flags to be cleared
     * @param      forest whether the parser generates a forest
     */

    private static void newparser(String name, Class pclass, Class lclass, int lkind,
        String lopt, int prsmode, int prsnomode, boolean forest){
        ParserData data = new ParserData();
        data.name = name;
        data.parserClass = pclass;
        data.pilotClass = lclass;
        data.pilotOpt = lopt;
        data.pilotKind = lkind;
        data.prsmode = prsmode;
        data.prsnomode = prsnomode;
        data.forest = forest;
        if (parsersHead == null){
            parsersHead = data;
        } else {
            parsersTail.next = data;
        }
        parsersTail = data;
    }

    /**
     * Deliver the parsing mode of the specified parser.
     *
     * @param      name name of the parser
     * @param      mode generation mode, that will be returned modified
     * @return     modified mode
     */

    static int prsmode(String name, int mode){
        for (ParserData i = parsersHead; i != null; i = i.next){
            if (i.name.equals(name)){
                mode |= i.prsmode;
                mode &= ~i.prsnomode;
                return mode;
            }
        }
        Trc.out.printf("!! unknown parser %s\n",name);
        return 0;
    }

    /**
     * Deliver the data of the specified parser.
     *
     * @param      name name of the parser
     * @return     data
     */

    static ParserData findParser(String name){
        for (ParserData i = parsersHead; i != null; i = i.next){
            if (i.name.equals(name)){
                return i;
            }
        }
        Trc.out.printf("!! unknown parser %s\n",name);
        return null;
    }

    /* All the parsers. */
    static {
        newparser("lr0",ParserLeftRight.class,null,0,"",0,0,true);
        newparser("clalr",ParserLeftRight.class,null,0,"",0,0,true);
        newparser("lr1",ParserLeftRight.class,null,0,"",0,0,true);
        newparser("rnglre",ParserRnglrEbnf.class,null,0,"",0,0,true);
        newparser("rnglrp",ParserRnglrPlus.class,null,0,"",0,0,true);
    }

    /**
     * Deliver a parser engine that implements the specified algorithm with the specified arguments.
     *
     * @param      tab reference to the parse tables
     * @param      inp input stream
     * @param      flags trace flags
     * @param      algo name of parser
     * @return     parser engine
     */

    public static ParserEngine getParser(ParserTables tab,
        Object inp, String flags, String algo){
        ParserEngine res = null;
        ParserData pd = findParser(algo);
        if (pd != null){
            try {
                res = (ParserEngine)pd.parserClass.newInstance();
                res.setParserData(tab,inp,flags,algo);
                res.settrc(flags);
            } catch (IllegalAccessException exc){
                // System.err.println(exc);
            } catch (InstantiationException exc){
                // System.err.println(exc);
            }
        }
        return res;
    }
}
