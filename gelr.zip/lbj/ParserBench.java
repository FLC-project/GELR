/*
 * @(#)ParserBench.java       1.0 2020/07/13
 *
 * Copyright (c) 1998-2000 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>ParserBench</code> class provides a benchmark driver for parser engines.
 *
 * @author  Angelo Borsotti
 * @version 1.0   7 Jul 2020
 */

/**
 * This class provides a benchmark driver for parser engines.
 * It is invoked with the following command:
 * <p>
 * <code>java -cp .. -Xmx1g -Xss2m lbj.ParserBench</code> <i>algorithm serializedgrammar texts</i> [ <i>lexer<i>]
 * <p>
 * Where:
 * <dl>
 * <dt>algorithm:<dt>
 *   <dd>the name of the parser algorithm</dd>
 * <dt>serializedgrammar:<dt>
 *   <dd>the name of the file containing the parse table for the grammar, that have been
 *      generated and serialized for the parser algorithm.</dd>
 * <dt>texts:<dt>
 *   <dd>the name of a file containing the list of the files to parse, one for each line.</dd>
 * <dl>
 * <p>
 * The test driver outputs a line containing:
 * <ol>
 * <li> the name of the algorithm </li>
 * <li> the name of the serialized grammar </li>
 * <li> the name of the list of text files </li>
 * <li> the parse time (secs) </li>
 * <li> the lexing time (secs) </li>
 * <li> the footprint (bytes) </li>
 * <li> the average parse speed (tokens/millisecs) </li>
 * <li> the average footprint (bytes/tokens) </li>
 * </ol>
 * N.B. the parse time and speed refer to the parsing, and do not contain the lexing time.
 */

public class ParserBench {

    /**
     * Parse the command line arguments, create the specified parser and use it to
     * parse the files enlisted in the specified command file.
     *
     * @param      args arguments
     */

    public static void main(String[] args){
        long total_lex_time = 0;
        long total_parse_time = 0;
        long total_tokens = 0;
        long total_stack = 0;
        long total_tree = 0;

        if (args.length < 3){
            System.out.printf("missing arguments\n");
        }
        String algo = args[0];
        String gram = args[1];
        String filelist = args[2];
        String enc = null;
        int idx = filelist.indexOf("/");
        if (idx >= 0){
            enc = filelist.substring(idx+1);
            filelist = filelist.substring(0,idx);
        }

        // read the serialized parser tables
        ParserTables tab = null;
        try {
            FileInputStream in = new FileInputStream(gram);
            ObjectInputStream ins = new ObjectInputStream(in);
            tab = (ParserTables)ins.readObject();
            ins.close();
        } catch (ClassNotFoundException th) {
            System.err.println(th);
            return;
        } catch (IOException th){
            System.err.println(th);
            return;
        }

        // for each input file

        BufferedReader b = null;
        try {
            FileInputStream in = new FileInputStream(filelist);
            InputStreamReader ir = null;
            if (enc == null){
                ir = new InputStreamReader(in);
            } else {
                ir = new InputStreamReader(in,enc);
            }
            b = new BufferedReader(ir);
        } catch (IOException th){
            System.err.println(th);
            return;
        }
        for (;;){
            String inpname = null;
            InputStreamReader inp = null;
            try {
                inpname = b.readLine();
                if (inpname == null) break;
                if (inpname.length() == 0) break;
                FileInputStream fi = new FileInputStream(inpname);
                if (fi == null){
                    throw new IOException("no such file: " + inpname);
                }
                if (enc == null){
                    inp = new InputStreamReader(fi);
                } else {
                    inp = new InputStreamReader(fi,enc);
                }
            } catch (IOException th){
                System.err.println(th);
                return;
            }
            ParserEngine eng = null;
            ParserLex lex = null;
            if (args.length >= 4){
                try {
                    Class c = Class.forName(args[3]);
                    lex = (ParserLex)c.newInstance();
                    lex.aut = tab;
                    lex.stream = new BufReader(inp,2048);
                } catch (ClassNotFoundException exc){
                    System.err.println(exc);
                    return;
                } catch (IllegalAccessException exc){
                    System.err.println(exc);
                    return;
                } catch (InstantiationException exc){
                    System.err.println(exc);
                    return;
                }
            } else {
                lex = new ParserLex(tab,inp);
            }
            eng = ParserFactory.getParser(tab,null,"",algo);
            eng.lex = lex;
            eng.settrc("");

            // measure lexing time
            boolean res = true;
            long ti = 0;
            long tli = 0;
            int eof = 0;
            if (eng instanceof ParserGLRengine) eof = eng.tab.numOfToks;
            long tl0 = System.nanoTime();
            while (eng.tokenizer() != eof);
            long tl1 = System.nanoTime();
            tli = tl1 - tl0;
            total_lex_time += tli;
            if (!res){
                System.err.printf("error in lexing run\n");
            }
            try {
                inp.close();
            } catch (IOException th){
                System.err.println(th);
                return;
            }
            // System.err.printf("lex done\n");
 
            // then parse
            try {
                FileInputStream fi = new FileInputStream(inpname);
                if (fi == null){
                    throw new IOException("no such file: " + inpname);
                }
                if (enc == null){
                    inp = new InputStreamReader(fi);
                } else {
                    inp = new InputStreamReader(fi,enc);
                }
            } catch (IOException th){
                System.err.println(th);
                return;
            }
            eng = null;
            lex = null;
            if (args.length >= 4){
                try {
                    Class c = Class.forName(args[3]);
                    lex = (ParserLex)c.newInstance();
                    lex.aut = tab;
                    lex.stream = new BufReader(inp,2048);
                } catch (ClassNotFoundException exc){
                    System.err.println(exc);
                    return;
                } catch (IllegalAccessException exc){
                    System.err.println(exc);
                    return;
                } catch (InstantiationException exc){
                    System.err.println(exc);
                    return;
                }
            } else {
                lex = new ParserLex(tab,inp);
            }
            eng = ParserFactory.getParser(tab,null,"",algo);
            eng.lex = lex;
            eng.settrc("");

            long t0 = System.nanoTime();
            res = eng.parse();
            long t1 = System.nanoTime();
            ti = t1 - t0;
            total_parse_time += ti;
            int stacksize = eng.stackLength();
            total_stack += stacksize;
            total_tokens += eng.numOfTokens;
            //System.err.printf("parse done\n");
            try {
                inp.close();
            } catch (IOException th){
                System.err.println(th);
                return;
            }
        }
        try {
            b.close();
        } catch (IOException th){
            System.err.println(th);
            return;
        }

        // emit the measures
        double totprstime = total_parse_time/1000000.0;
        double totlextime = total_lex_time/1000000.0;
        double avets = (double)total_tokens/((total_parse_time-total_lex_time)/1000000.0);
        double avebs = (double)total_stack/total_tokens;
        System.out.printf("%s %s %s %.1f %.1f %d %.2f %.1f\n",
            algo,gram,args[2],
            totprstime,totlextime,total_stack,avets,avebs);
    }
}