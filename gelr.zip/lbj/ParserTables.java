/*
 * @(#)ParserTables.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>ParserTables</code> represents tables for lexing and
 * parsing. The tables for lexing are the ones of a deterministic
 * finite automaton, and the ones for parsing are the ones for an
 * Earley engine.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

class ParserTables implements Serializable, Cloneable {

    /** SUID form JDK 1.2 */
    private static final long serialVersionUID = -323073874564901224L;

    /** The trace flags. */
    transient int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    r   rule details
     * </pre></blockquote><p>
     */

    private static final int FL_R = 1 << ('r'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /** The generation mode. */
    int mode;

    /** Represent groups with left-recursive rules (instead of right-recursive). */
    public static final int LEFTGROUPS = 1 << 30;

    /**
     * Clone this object. It performs shallow copy.
     *
     * @return     a copy of the object
     */

    public Object clone(){
        ParserTables t = null;
        try {
            t = (ParserTables)super.clone();
        } catch (CloneNotSupportedException e){
        }
        return t;
    }

    /**
     * The table which maps characters into categories.
     *
     * @serial
     */
    char[][] catMap;

    /**
     * The table which maps the first 256 characters into categories.
     *
     * @serial
     */
    char[] catMap0;

    /** The number of bits of category blocks: 2** = size of blocks. */
    static final int CAT_BLK_BITS = 8;

    /**
     * The basic transition table.
     * The move from state s with character of category c is: transTable[s][c].
     * No-state is represented as zero.
     *
     * @serial
     */
    char[][] transTable;

    /**
     * The compressed transition table.
     * The move from state s with character of category c is: transTable[s][c].
     * No-state is represented as zero.
     *
     * @serial
     */
    int[] tabMerged;

    /** The number of shifts to get values from entries of the compressed table. */
    static final int NSHIFT = 16;

    /** The mask to get values from entries of the compressed table. */
    static final int MASK = 0xffff;

    /**
     * The table of the bases at which subtables of states are located in
     * the compressed transition table.
     * It is present only when there is a need to trace state as the
     * original state numbers.
     * States which have no subtable have a negative base.
     *
     * @serial
     */
    int[] stateBase;

    /**
     * The table of the fallback states, represented as state bases.
     * It is present only for testing.
     * No-state is represented as zero.
     *
     * @serial
     */
    char[] fallback;

    /**
     * The attributes of the states. The upper 16 bits of each entry
     * contain the codes of the sets of recognised tokens.
     *
     * @serial
     */
    int[] stateAttrs;

    /** The final state status. */
    /* A state is final if it has a set of recognised tokens attached. */
    static final int FINAL = 0x1fff0000;

    /** The shift to get the tokens set code. */
    static final int TOKCODE_SHIFT = 16;

    /** The maximum token code. */
    static final int MAX_TOKCODE = 8191;

    /** The looping state status. */
    static final int LOOPING = 0x40000000;

    /** The special state status. */
    static final int SPECIAL = 0x80000000;

    /** The maximum token number. */
    static final int MAX_TOKNR = Character.MAX_VALUE;

    /**
     * The number of the initial state.
     *
     * @serial
     */
    char initialState;

    /**
     * The number of the states.
     *
     * @serial
     */
    int numOfStates;

    /**
     * The number of symbols (i.e. categories).
     *
     * @serial
     */
    int numOfSymbs;

    /**
     * The number of tokens sets codes, excluding EOF.
     *
     * @serial
     */
    int numOfToks;

    /**
     * The map from tokens sets codes to the sets of as comb-vector.
     *
     * @serial
     */
    char[] tokMap;

    /**
     * The map from tokens sets codes to the lists of tokens. Each list
     * is an array containing a sequence of token codes. The first element
     * of the map is null since the set code 0 cannot be returned by the
     * lexer.
     *
     * @serial
     */
    char[][] tokLists;

    /**
     * The map from token numbers to indexes in <code>tokStrings</code>.
     *
     * @serial
     */
    char[] tokOrder;

    /**
     * The table of the names of the tokens, ordered by names of
     * terminals first and then nonterminals.
     *
     * @serial
     */
    String[] tokStrings;

    /**
     * The map from <code>tokStrings</code> to token numbers.
     *
     * @serial
     */
    char[] tokNumbers;

    /**
     * The number of terminal tokens.
     *
     * @serial
     */
    int terNum;

    /**
     * The size of the automa.
     *
     * @serial
     */
    public long size;

    /** 
     * Trace the automaton in numeric form.
     */

    public void trace(){
        if (this.transTable != null){
            Trc.out.println("transtable " + this.transTable.length);
            for (int i = 0; i < this.transTable.length; i++){
                char[] t = this.transTable[i];
                Trc.out.println(i + " " + t);
                if (t == null) continue;
                for (int j = 0; j < t.length; j++){
                    Trc.out.println(i + " " + j + " " +
                        (int)this.transTable[i][j]);
                }
            }
        }
        if (this.tabMerged != null){
            Trc.out.println("merged transtable " + this.tabMerged.length);
            for (int i = 0; i < this.tabMerged.length; i++){
                int el = this.tabMerged[i];
                Trc.out.println(i + " " + (el >>> NSHIFT) + " "  + (el & MASK));
            }
        }
        if (this.stateBase != null){
            Trc.out.println("base:");
            for (int i = 0; i < this.stateBase.length; i++){
                Trc.out.println(i + " " + this.stateBase[i]);
            }
        }
        if (this.fallback != null){
            Trc.out.println("fallback " + this.fallback.length);
            for (int i = 0; i < this.fallback.length; i++){
                Trc.out.println(i + " " + (int)this.fallback[i]);
            }
        }

        Trc.out.println("catMap[0]");
        for (int i = 0; i < this.catMap0.length; i++){
            Trc.out.println(i + " " + (int)this.catMap0[i]);
        }
        if (this.stateAttrs != null){
            Trc.out.println("stateAttrs");
            for (int i = 0; i < this.stateAttrs.length; i++){
                Trc.out.println(i + " " + (int)this.stateAttrs[i]);
            }
        }
        Trc.out.println("tokLists");
        for (int i = 0; i < this.tokLists.length; i++){
            Trc.out.println(i + " " + this.tokSetToString(i));
        }
        if (this.tokMap != null){
            Trc.out.println("tokMap");
            for (int i = 0; i < this.tokMap.length; i++){
                Trc.out.println(i + " " + this.tokMap[i]);
            }
        }
        Trc.out.println("initialState: " + (int)this.initialState +
            " numOfSymbs: " + this.numOfSymbs +
            " numOfStates: " + this.numOfStates);
        if (this.tokStrings != null){
            Trc.out.println("terminals: " + this.terNum + " tokens:");
            for (int i = 0; i < this.tokStrings.length; i++){
                Trc.out.println(this.tokStrings[i] + " " +
                (int)this.tokNumbers[i]);
            }
        }
    }

    /**
     * Trace the automaton.
     *
     * @param      trc trace stream
     */

    void trace(PrintWriter trc){
        int tranSize = this.numOfSymbs;         // length of the table of a state
        int numStates = this.numOfStates;

        IntSet[] catTable = new IntSet[tranSize];
        int max = Character.MAX_VALUE;
        int blkBits = CAT_BLK_BITS;
        int mask = (1 << blkBits) - 1;          // rebuild category table
        for (int j = 0; j <= max; j++){
            int cat = 0;
            if (this.catMap == null){
                if (j < 256) cat = this.catMap0[j];
            } else {
                cat = this.catMap[j >> blkBits][j & mask];
            }
            if (catTable[cat] == null){
                catTable[cat] = new IntSet(j);
            } else {
                catTable[cat].add(j);
            }
        }
        //for (int j = 0; j < tranSize; j++){
        //    trc.println(j + ": " + catTable[j].toString(true));
        //}
        
        int[] stateBase = this.stateBase;
        boolean remap = false;
        boolean relo = false;
        int[] stateAttrs = this.stateAttrs;
        char[] fallback = this.fallback;
        if ((this.tabMerged != null) && (this.stateAttrs == null)){
            remap = true;
            relo = true;
            int n = 0;
            boolean nobase = false;
            if (stateBase == null){
                remap = false;                    // print offsets
                nobase = true;
                stateBase = new int[numStates];
                stateBase[n++] = -1;
                stateBase[n++] = (int)this.initialState;
            }
            stateAttrs = new int[numStates];
            fallback = new char[numStates];
            for (int i = 1; i < numStates; i++){  // rebuild table
                int idx = stateBase[i];
                if (idx == 0) continue;
                stateAttrs[i] = this.tabMerged[idx-2] & 0xffff0000;
                fallback[i] = (char)(this.tabMerged[idx-1] >> 16);
                if (!nobase) continue;
                for (int j = -1; j < tranSize; j++){     // fallback also
                    int elem = tabMerged[idx+j];
                    nxt: if ((char)elem == (char)idx){
                        elem = elem >>> 16;
                        for (int k = 0; k < n; k++){
                            if (elem == stateBase[k]){   // present
                                break nxt;
                            }
                        }
                        stateBase[n++] = elem;
                    }
                }
            }
        }
        //if (stateBase != null){
        //    for (int i = 1; i < numStates; i++){    // print the base
        //        trc.println(i + " -> " + stateBase[i]);
        //    }
        //}
        for (int i = 1; i < numStates; i++){    // print the states and edges
            int share = -1;
            if (this.transTable != null){
                char[] tab = this.transTable[i];
                if (tab != null){
                    for (int j = 0; j < i; j++){
                        if (tab == this.transTable[j]){
                            share = j;
                            break;
                        }
                    }
                }
            } else {
                if (stateBase != null){
                    if (stateBase[i] >= 0){
                        for (int j = 0; j < i; j++){
                            if (stateBase[i] == stateBase[j]){
                                share = j;
                                break;
                            }
                        }
                    }
                }
            }
            String shared = "";
            if (share >= 0){
                shared = "<" + Integer.toString(share) + ">";
            }
            if (relo & !remap){
                trc.print(stateBase[i]);
            } else {
                trc.print(i);
            }
            if ((FINAL & stateAttrs[i]) != 0){
                trc.print('*');
            }
            if ((LOOPING & stateAttrs[i]) != 0){
                trc.print('@');
            }
            if (fallback != null){
                if (fallback[i] > 0){
                    int fb = fallback[i];
                    fb = baseToIndex(fb,stateBase);
                    if ((fb != i) && (share < 0)) trc.print("[" + fb + "]");
                }
            }
            trc.print(shared);
            if (share >= 0){
                trc.println();
                continue;
            }
            String del = " ";

            for (int j = 0; j < tranSize; j++){
                int ns = 0;
                if (this.transTable != null){
                    ns = this.transTable[i][j];
                } else if (this.tabMerged != null){
                    int idx = stateBase[i];
                    int elem = this.tabMerged[idx + j];
                    int check = (char)elem;
                    if (check != idx) continue;         // no entry
                    ns = (char)(elem >> 16);
                    if (remap) ns = baseToIndex(ns,stateBase);
                }
                if (ns > 0){
                    trc.print(del);
                    del = ", ";
                    trc.print(catTable[j].toString(true) + "->" + ns);
                }
            }
            trc.println();
        }
        Str st = new Str();
        for (int i = 0; i < numStates; i++){       // recognised lexemes
            int code = (stateAttrs[i] & FINAL) >>> TOKCODE_SHIFT;
            if (code == 0) continue;
            if (relo & !remap){
                trc.print(stateBase[i]);
            } else {
                trc.print(i);
            }
            trc.println(": " + tokSetToString(code));
        }
        trc.println("Table size: " + this.size);
    }

    /**
     * Deliver the state number from a state base.
     *
     * @param      ns state base
     * @param      stateBase reference to the state base table
     * @return     state number
     */

    private char baseToIndex(int ns, int[] stateBase){
        for (int i = 0; i < stateBase.length; i++){
            if (ns == stateBase[i]){
                 ns = i;                     // convert to state nr
                 break;
            }
        }
        return (char)ns;
    }

    /**
     * Trace the category map of the automaton.
     *
     * @param      trc trace stream
     */

    void traceCatMap(PrintWriter trc){
        char[][] table = this.catMap;
        char[] table0 = this.catMap0;

        int blkBits = CAT_BLK_BITS;
        int mask = (1 << blkBits) - 1;

        Str st = new Str();
        IntSet rng = new IntSet();
        int max = Character.MAX_VALUE;
        for (int i = 0; i <= max; i++){
            int r = i;
            int cat = 0;
            if (table == null){
                if (i < 256) cat = table0[i];
            } else {
                cat = table[i >> blkBits][i & mask];
            }
            for (; r <= max; r++){                    // look forward
                int cat1 = 0;
                if (table == null){
                    if (r < 256) cat1 = table0[r];
                } else {
                    cat1 = table[r >> blkBits][r & mask];
                }
                if (cat != cat1){
                   r--;
                   break;
                }
            }
            if (r > max) r--;
            st.length = 0;
            rng.clear();
            rng.add(i,r);
            rng.toString(st,true);
            for (int z = st.length; z < 25; z++){
                st.append(' ');
            }
            trc.println(st + "" + cat);
            i = r;
        }
        int n = 0;
        if (table == null){
            n = table0.length * 2 + 4;
        } else {
            n += table.length * 4 + 4;
            siz: for (int i = 0; i < table.length; i++){   // determine size
                for (int j = 0; j < i; j++){
                    if (table[i] == table[j]) continue siz;
                }
                n += table[i].length * 2 + 4;
            }
        }
        trc.println("size: " + n);
    }

    /**
     * Deliver a string representing a set of tokens.
     *
     * @param      l reference to the list
     * @return     string, null if there is no set
     */

    public String tokSetToString(char[] l){
        Str st = new Str();
        if (l != null){
            for (int i = 0; i < l.length; i++){
                if (st.length > 0) st.append(" ");
                tokLitName(st,l[i]);
            }
            return st.toString();
        }
        return null;
    }

    /**
     * Deliver a string representing a set of tokens.
     *
     * @param      c code representing the set of tokens
     * @return     string, null if there is no set
     */

    public String tokSetToString(int c){
        if (this.tokLists != null){
            return tokSetToString(this.tokLists[c]);
        }
        if (c == 0) return null;
        Str st = new Str();
        for (int i = 0; i < this.numOfToks; i++){
            if (this.tokMap[i+c] != c) continue;
            if (st.length > 0) st.append(" ");
            tokLitName(st,i);
        }
        return st.toString();
    }

    /**
     * Literalizes a name. Empty names, and names which contain non
     * alphanumeric characters are literalized.
     *
     * @param   st string in which it is appended
     * @param   n name
     * @param   nt <code>true</code> not to literalize spaces, hyphens
     *          and ampersands
     */

    private void appendLit(Str st, String n, boolean nt){
        doit: if (n.length() > 0){
            for (int i = 0; i < n.length(); i++){
                char c = n.charAt(i);
                if (('a' <= c) && (c <= 'z')) continue;
                if (('A' <= c) && (c <= 'Z')) continue;
                if (('0' <= c) && (c <= '9')) continue;
                if (nt){
                    if ((c == ' ') || (c == '-') || (c == '&')) continue;
                }
                Str.strQuoted(n,st);
                break doit;
            }
            st.append(n);
        } else {
            st.append("\"\"");
        }
    }

    /* The parse tables. */

    /**
     * The encoded grammar.
     *
     * @serial
     */
    char[] grammar;

    /**
     * The map that tells the tokNr or ntNr in grammar of the symbol at
     * end of singleton chains. It maps also tokens so as to access it
     * directly with grammar elements.
     *
     * @serial
     */
    char[] singmap;

    /**
     * The base for the encoding of ruleNr values in the grammar. I.e. the index after
     * the ones of the tokens (including EOF).
     *
     * @serial
     */
    int ruleBase;

    /**
     * The map from rule numbers and the index of the rule in grammar.
     *
     * @serial
     */
    int[] ruleIndex;

    /**
     * The index of the start rule in the grammar.
     *
     * @serial
     */
    int startRule;

    /** The mask to take the bit index part of directors */
    static final int MASKB = 0x7;

    /** The number of shifts to take the byte index of directors */
    static final int NSHIFTB = 3;

    /**
     * The comb-merged lookup tables.
     *
     * @serial
     */
    int[] latable;

    /**
     * The base vector for the lookup tables.
     *
     * @serial
     */
    int[] labase;

    /**
     * The check vector for the lookup tables.
     *
     * @serial
     */
    char[] lacheck;

    char[] chaintable;
    char[] chainbase;
    char[] chaincheck;
    char[] chainLentable;
    boolean chaingroups;
    boolean[] chaintokens;
    char[] chainClasses;
    int chainClassesNr;

    /**
     * The pilot tables.
     *
     * @serial
     */
    ParserLRTables pilot;

    /**
     * The number of nullable rules for each nonterminal.
     *
     * @serial
     */
    int[] nullableNtRules;

    /**
     * The map of the nullable rules.
     *
     * @serial
     */
    byte[] nullableRules;

    /**
     * The map of the rules that generate only the empty string.
     *
     * @serial
     */
    byte[] eonlyRules;

    /**
     * The number of nonterminals, including the enclosing one.
     *
     * @serial
     */
    int numOfNts;

    /**
     * The number of rules.
     *
     * @serial
     */
    public int numOfRules;

    /**
     * The number of symbols.
     *
     * @serial
     */
    public int numOfSyms;

    /**
     * The map from rule numbers to nonterminal numbers.
     *
     * @serial
     */
    char[] ruleToNt;

    /**
     * The map fom nonterminal numbers to the number of the first rule.
     *
     * @serial
     */
    char[] ntToRule;

    /**
     * The table of nonterminal names.
     *
     * @serial
     */
    String[] ntStrings;

    /**
     * The table of rule lengths.
     *
     * @serial
     */
    char[] ruleLen;

    /**
     * The base index of the encoding of tokens.
     *
     * @serial
     */
    int tokBase;

    /**
     * The nonterminal number of the first group.
     *
     * @serial
     */
    int ntNrGroups;

    /**
     * The table of the kinds of nonterminals.
     *
     * @serial
     */
    byte[] ntKind;

    /* The kinds are ordered as follows:
     *
     *    unlimited     limited
     *    REP RES REL | RER REU REF | 0 GRO OPT BOD OBO BOR BOO
     *    -6..-5..-4....-3..-2..-1..+.0..1...2...3...4...5...6
     *    with repetitions          | without repetitions
     */

    /** A positive Kneene group: {alpha}+. */
    static final int REP = -6;

    /** A Kleene group: {alpha}*. */
    static final int RES = -5;

    /** A lower limited group: {alpha}(l:). */
    static final int REL = -4;

    /** A range group: {alpha}(l:u). */
    static final int RER = -3;

    /** A upper limited group: {alpha}(:u). */
    static final int REU = -2;

    /** A fixed repetition group: {alpha}{l}. */
    static final int REF = -1;

    /** A simple group: {alpha}. */
    static final int GRO = 1;

    /** An optional group: [alpha]. */
    static final int OPT = 2;

    /** A body of a group. */
    static final int BOD = 3;

    /** An optional body of a group. */
    static final int OBO = 4;

    /** A body of a repetition (REP, RES and REL) group. */
    static final int BOR = 5;

    /** A body of an optional group. */
    static final int BOO = 6;

    /** The achronyms of groups. */
    static String[] groupNames = new String[]{
        "REP","RES","REL","RER","REU","REF","","GRO","OPT","BOD","OBO","BOR","BOO"};

    /**
     * Deliver the achronym of the group of the specified nonterminal;
     *
     * @param      num number of the nonterminal
     */

    String ntGroupName(int num){
        num = this.ntKind[num];
        int n = num + 6;
        if (n < groupNames.length){
            return groupNames[n];
        }
        return Integer.toString(num);
    }

    /**
     * The compressed bool array of nullable nonterminals.
     *
     * @serial
     */
    byte[] nullable;
    byte[] chainrules;

    byte[] eonly;
    byte[] epsilon;
    byte[] split;    // bitset of the nts that are splitted

    BitSet[] firsts;
    byte[] cyclic;

    /**
     * The table of the size of the singleton chains of rules.
     *
     * @serial
     */

    char[] singsize;

    /**
     * The compressed bool array of terms which are tokens that require
     * the storing of the lexeme.
     *
     * @serial
     */
    byte[] storeLex;

    /**
     * The compressed bool array of terms which are tokens that require
     * the storing of the point.
     *
     * @serial
     */
    byte[] storePoint;

    /**
     * The ordered table containing the indexes of alternatives and
     * terms which have a priority defined.
     *
     * @serial
     */
    int[] priLocs;

    /**
     * The table containing the corresponding priority values / indexes.
     *
     * @serial
     */
    int[] priVals;

    /**
     * The table containing the priority maps.
     *
     * @serial
     */
    int[] priMaps;

    /**
     * The size of the parsing tables.
     *
     * @serial
     */
    public long prsSize;

    /**
     * The map from rules of the modified grammar to the rules of the origin one.
     *
     * @serial
     */

    int[] toOriginRule;

    /**
     * The tables of the origin grammar.
     *
     * @serial
     */

    ParserTables originTables;

    /**
     * Deliver the literalized name of the specified nonterminal.
     *
     * @param      num number of the nonterminal
     * @return     name, surrounded by angular brackets
     */

    String ntLitName(int num){
        char opn = '<';
        char clo = '>';
        if (num >= this.ntNrGroups){
            opn = '\u00ab';         // left double angle
            clo = '\u00bb';         // right  double angle
        }
        Str st = new Str();
        st.append(opn);
        appendLit(st,this.ntStrings[num],true);
        st.append(clo);
        if (this.epsilon != null){
            if ((this.epsilon[num >>> ParserTables.NSHIFTB] &
                (1 << (num & ParserTables.MASKB))) != 0){
                st.append('\u00b0');   // degree sign
            }
        }
        return st.toString();
    }

    /**
     * Deliver a string representing a symbol of the encoded grammar
     * preceded by an indication of its kind.
     *
     * @param      e index of the rule or tokens in the encoded grammar
     * @return     string
     */

    String symToString(int e){
        String s;
        if (e >= this.tokBase){
            s = "lex: " + (e - this.tokBase);
        } else {
            s = "nt: " + e;
        }
        return s + " " + gramSymToString(e);
    }

    /**
     * Deliver a string representing a symbol of the encoded grammar.
     *
     * @param      e index of the rule or token in the encoded grammar
     * @param      gram encoded grammar
     * @return     string
     */

    String gramSymToString(int e){
        if (e >= this.ruleBase){
            return "rule:" + (e-this.ruleBase);
        } else if (e >= this.tokBase){
            return tokLitName(e - this.tokBase);
        } else {
            return ntLitName(e);
        }
    }

    /**
     * Deliver the literalized name of the specified token.
     *
     * @param      tok token number
     * @return     string
     */

    String tokLitName(int tok){
        Str st = new Str();
        tokLitName(st,tok);
        return st.toString();
    }

    /**
     * Deliver the literalized name of the specified token.
     *
     * @param      st string
     * @param      tok token number
     */

    void tokLitName(Str st, int tok){
        if (tok == this.numOfToks){
            st.append("EOF");
            return;
        }
        if ((tok < 0) || (this.numOfToks < tok)){
            st.append("unknown");
            return;
        }
        int ord = this.tokOrder[tok];
        if (ord >= this.terNum) st.append('<');
        appendLit(st,this.tokStrings[ord],false);
        if (ord >= this.terNum) st.append('>');
    }

    /**
     * Trace the encoded grammar.
     */

    public void traceGrammar(){
        char gram[] = this.grammar;
        for (int i = 1; i < gram.length;){         // trace the rules
            while (gram[i] < this.ruleBase){       // gramRule
                int e = gram[i];
                Trc.out.print(i + " " + symToString(e));
                if ((this.storeLex[i >>> NSHIFTB] &
                    (1 << (i & MASKB))) != 0){
                    Trc.out.print(" storeLex");
                }
                if ((this.storePoint[i >>> NSHIFTB] &
                    (1 << (i & MASKB))) != 0){
                    Trc.out.print(" storePoint");
                }
                Trc.out.println();
                i++;
            }
            int ruleNr = gram[i] - this.ruleBase;
            int nt = this.ruleToNt[ruleNr];
            Trc.out.println(i + " " + (int)gram[i++] +
                " nt: " + ntLitName(nt) + " rule: " + ruleNr);
            Trc.out.println();
        }
        Trc.out.println("ntNr of groups: " + this.ntNrGroups);
        Trc.out.println("-- tokens -- term: " + this.terNum +
            " base: " + this.tokBase + " numOfToks: " + this.numOfToks);
        for (int i = 0; i < this.numOfToks+1; i++){
            int tokNr = i;
            if (i < this.numOfToks){
                tokNr = (int)tokNumbers[i];
            }
            String name = tokLitName(tokNr);
            Trc.out.println(i + " " + name + " nr: " + tokNr +
                " (" + (tokNr+this.tokBase) + ")");
        }
        /*
        Trc.out.println("-- ntToRule --");
        for (int i = 0; i < this.ntToRule.length; i++){
            Trc.out.printf("i: %d %s %d\n",i,gramSymToString(i),(int)this.ntToRule[i]);
        }
        */
        Trc.out.println("-- nonterminals --");
        for (int i = 0; i < this.numOfNts; i++){
            int e = this.singmap[i];
            Trc.out.print(i + " " + ntLitName(i) +
                " k: " + ntGroupName(i) + " r: " + (int)this.ntToRule[i] +
                " -> " + gramSymToString(e));
            if (this.labase != null){
                Trc.out.print(" foll: " + dirSetToStr(this.labase[this.ntToRule[i]+
                    this.ruleBase],this.lacheck));
            }
            Trc.out.println(" epsilon: " + ((this.epsilon[i >>> NSHIFTB] &
                    (1 << (i & MASKB))) != 0) +
                " split: " + ((this.split[i >>> NSHIFTB] &
                    (1 << (i & MASKB))) != 0) +
                " nullable: " + ((this.nullable[i >>> NSHIFTB] &
                    (1 << (i & MASKB))) != 0));
            if (this.labase != null){
                traceLLTable(i,Trc.wrt);
            }
        }
        Trc.out.println("-- rules -- " + this.numOfRules +
            " base: " + this.ruleBase);
        for (int i = 0; i < this.ruleToNt.length; i++){
            Trc.out.print(i + " " + ntLitName(this.ruleToNt[i]) +
                " i: " + this.ruleIndex[i] +
                " " + (int)this.ruleLen[i]);
            if (this.labase != null){
                Trc.out.print(" foll: " + dirSetToStr(this.labase[i+this.ruleBase],
                this.lacheck));
            }
            Trc.out.println();
        }
        Trc.out.println("-- prios --");
        for (int i = 0; i < this.priLocs.length; i++){
            Trc.out.println(this.priLocs[i] + " " + (int)this.priVals[i]);
        }
        for (int i = 0; i < this.ruleIndex.length; i++){
            int t = Arrays.binarySearch(this.priLocs,this.ruleIndex[i]);
            int r = Arrays.binarySearch(this.priLocs,this.ruleIndex[i]+this.ruleLen[i]);
            if (t >= 0 || r >= 0){
                Trc.out.printf("   rule %s",i);
            }
            if (t >= 0){
                for (int k = 0, z = this.priVals[t]; k < this.ruleLen[i]; k++, z++){
                    Trc.out.printf(" %s",this.priMaps[z]);
                }
            }
            if (r >= 0){
                Trc.out.printf(" on alt: %s",this.priVals[r]);
            }
            if (t >= 0 || r >= 0){
                Trc.out.printf("\n");
            }
        }
    }

    /**
     * Deliver a string representing a rule of the encoded grammar.
     *
     * @param      rule index of an element of the rule in the encoded grammar
     * @param      dot <code>true</code> to print the dot
     * @return     string
     */

    String ruleToString(int rule, boolean dot){
        Str st = new Str();

        if ((FL_R & this.trc) != 0){
            Trc.out.println("rule: " + rule);
        }
        char gram[] = this.grammar;
        int end = rule;                             // find the end
        while (gram[end] < this.ruleBase) end++;
        int start = end - this.ruleLen[gram[end]-this.ruleBase];
        if ((FL_R & this.trc) != 0){
            Trc.out.println("rule: " + rule +
               " " + start + " " + end);
        }
        int nt = this.ruleToNt[gram[end] - 
            this.ruleBase];                         // gramRule
        eps: {
            if (this.epsilon == null) break eps;
            for (int p = start; gram[p] <
                this.ruleBase; p++){                // gramRule
                int v = gram[p];
                if (v < this.tokBase){              // nonterminal
                    if ((this.epsilon[v >>> ParserTables.NSHIFTB] &
                        (1 << (v & ParserTables.MASKB))) == 0){
                        break eps;
                    }
                } else {
                    break eps;
                }
            }
        }
        st.append(ntLitName(nt) + " ::= ");

        boolean first = true;
        for (int p = start; gram[p] <
            this.ruleBase; p++){                    // gramRule
            if (!first){
                st.append(" ");
            }
            first = false;
            if (dot && (p == rule)){
                st.append("\u00b7");                // centered dot
            }
            int v = gram[p];
            if ((FL_R & this.trc) != 0){
                Trc.out.println("rule: " + v + " " + p);
            }
            st.append(gramSymToString(v));
            if (!dot){
                boolean lex =
                    (this.storeLex[p >>> NSHIFTB] &    // string to be stored
                    (1 << (p & MASKB))) != 0;
                boolean point =
                    (this.storePoint[p >>> NSHIFTB] &  // point to be stored
                    (1 << (p & MASKB))) != 0;
                if (lex || point) st.append('(');
                if (lex) st.append("lex");
                if (lex && point) st.append(',');
                if (point) st.append("point");
                if (lex || point) st.append(')');
            }
        }
        if (dot && (gram[rule] >= this.ruleBase)){     // dot at the end
            st.append("\u00b7");
        }
        return st.toString();
    }

    /**
     * Deliver the index of the rule that follows the specified one
     * in the grammar.
     *
     * @param      rule index of the rule
     * @return     index of the next rule
     */

    int nextRule(int rule){
        while (this.grammar[rule] < this.ruleBase){
            rule++;
        }
        return ++rule;
    }

    /**
     * Deliver a string that represents a set of terminals.
     *
     * @param      base the base of the set
     * @param      check check vector
     * @return     string
     */

    Str dirSetToStr(int base, char[] check){
        Str s = new Str("{");
        boolean first = true;
        if (base >= 0){
            for (int i = 0; i <= this.numOfToks; i++){
                if (check[base+i] == base){
                    if (!first) s.append(", ");
                    first = false;
                    s.append(tokLitName(i));
                }
            }
        }
        s.append("}");
        return s;
    }

    /**
     * Trace the parse lookup table for a nonterminal.
     *
     * @param      nt number of the nonterminal
     * @param      trc trace stream
     */

    void traceLLTable(int nt, PrintWriter trc){
        int idx = this.labase[nt];
        if (idx != -1){
            for (int j = 0; j <= this.numOfToks; j++){     // scan tokens
                if (this.lacheck[idx+j] != (char)idx) continue;  // no rule
                int ri = this.latable[idx+j];              // rule / ovf zone
                int nru = 1;
                int a;
                if (ri >= 0){                              // rule
                    a = this.ruleIndex[ri];
                } else {                                   // ovf zone
                    ri = idx - ri;
                    nru = this.latable[ri++];
                    a = this.ruleIndex[this.latable[ri++]];
                }
                do {                                       // print rules
                    trc.println(tokLitName(j) + " -> " +
                        ruleToString(a,false));
                    if (--nru == 0) break;
                    a = this.ruleIndex[this.latable[ri++]];
                } while (true);
            }
        }
        if (this.chainbase != null){
            idx = this.chainbase[nt];
            if (idx != Character.MAX_VALUE){
                for (int j = 0; j < this.ruleBase; j++){          // scan symbols
                    if (this.chaincheck[idx+j] != idx) continue;  // no rule
                    int ri = this.chaintable[idx+j];              // rule
                    trc.println(this.gramSymToString(j) + " <- " +
                        this.ruleToString(this.ruleIndex[ri],false));
                }
            }
        }
    }

    /**
     * Deliver the symbol number of the specified name.
     *
     * @param      kind: <code>'t'</code> for a terminal,
     *             <code>'n'</code> for a nonterminal
     * @param      symName name of the terminal or nonterminal
     * @return     symbol number, -1 if not present in the grammar
     */

    public int symNr(char kind, String symName){
        int i = 0;
        switch (kind){
        case 't':                                        // terminal
            i = binarySearch(this.tokStrings,symName,
                0,this.terNum);                          // search in terminals
            if (i >= 0){
                return this.tokNumbers[i];
            }                
            break;
        case 'n':                                        // nonterminal
            i = binarySearch(this.ntStrings,symName,
                0,this.ntNrGroups);                      // search in grammar
            if (i >= 0){
                return i + this.numOfToks;
            }
            i = binarySearch(this.tokStrings,symName,
                this.terNum,this.tokStrings.length);     // search in tokens
            if (i >= 0){
                return this.tokNumbers[i];
            }                
            break;
        default:
            throw new IllegalArgumentException(
                String.valueOf(kind));                   // illegal kind
        }
        return -1;                                       // not present
    }

    /**
     * Search a string in an ordered (piece of) array of strings.
     *
     * @param      arr array of strings
     * @param      key string to search
     * @param      lo start index
     * @param      hi index of the element following the last
     * @return     index in the array, or -1 if not present
     */

    public static int binarySearch(String[] arr, String key,
        int lo, int hi){
        int k = 0;
        int res = -1;
        hi--;
        while (lo <= hi){                    // binary search
            k = lo + (hi - lo ) / 2;         // middle index
            int i = key.compareTo(arr[k]);
            if (i <= 0) hi = k-1;            // it is above
            if (i >= 0) lo = k+1;            // it is below
        }
        if (lo-1 > hi){                      // found
            res = k;
        }
        return res;
    }

    /**
     * Deliver the symbol number of the specified nonterminal name.
     *
     * @param      symName name of the terminal or nonterminal
     * @return     symbol number
     * @return     symbol number, -1 if not present in the grammar
     */

    public int symNr(String symName){
        return symNr('n',symName);
    }

    /**
     * Deliver the symbol number of the specified rule.
     *
     * @param      ruleNr rule number
     * @return     symbol number, -1 if rule of a group
     * @exception  IllegalArgumentException if the rule number is
     *             not valid
     */

    public int symNr(int ruleNr){
        if ((ruleNr < 0) || (this.numOfRules < ruleNr)){
            throw new IllegalArgumentException(
                Integer.toString(ruleNr));           // invalid
        }
        int ntNr = this.ruleToNt[ruleNr];
        if (ntNr >= this.ntNrGroups){                // group
            return -1;
        }
        return ntNr + this.numOfToks;                // symbol number
    }

    /**
     * Deliver the symbol number of the specified term in the specified
     * rule.
     *
     * @param      ruleNr number of the rule
     * @param      termNr number of the term
     * @return     symbol number, -1 if group, -2 if the term does not exist
     * @exception  IllegalArgumentException if there is no such rule
     */

    public int symNr(int ruleNr, int termNr){
        int start = getRule(ruleNr);                 // start of rule, gramRule
        if ((termNr < 0) ||
            (this.ruleLen[ruleNr] <= termNr)){       // no such term
            return -2;
        }
        int n = this.grammar[start + termNr];
        if (n >= this.tokBase){                      // token
            return n - this.tokBase;                 // token number
        } else {
            if (n >= this.ntNrGroups){               // group
                return -1;
            }
            return n + this.numOfToks;               // nonterminal symbol number
        }
    }

    /**
     * Deliver the name corresponding to the specified symbol number.
     *
     * @param      symNr symbol number
     * @return     name
     * @exception  IllegalArgumentException if the symbol number
     *             does not denote a symbol
     */

    public String symName(int symNr){
        if ((symNr < 0) ||
            (this.numOfSyms <= symNr)){
            throw new IllegalArgumentException(
                Integer.toString(symNr));      // out of range
        }
        if (symNr < this.numOfToks){           // token
            int ord = this.tokOrder[symNr];
            return this.tokStrings[ord];
        }
        int ntNr = symNr - this.numOfToks;     // number of the nonterminal
        return this.ntStrings[ntNr];
    }

    /**
     * Deliver the literalised name of the specified symbol number.
     *
     * @param      symNr symbol number
     * @return     literalised name
     * @exception  IllegalArgumentException if the symbol number
     *             does not denote a symbol
     */

    public String symLitName(int symNr){
        if ((symNr < 0) ||
            (this.numOfSyms <= symNr)){
            throw new IllegalArgumentException(
                Integer.toString(symNr));      // out of range
        }
        if (symNr < this.numOfToks){           // token
            return tokLitName(symNr);
        }
        int ntNr = symNr - this.numOfToks;     // number of the nonterminal
        return this.ntLitName(ntNr);
    }

    /**
     * Deliver the rule number of the specified nonterminal name and
     * alternative number.
     *
     * @param      symName nonterminal name
     * @param      altNr alternative number
     * @return     rule number
     * @exception  IllegalArgumentException if the name is not present
     *             in the grammar or if the number of the alternative
     *             exceeds the range of the ones of the nonterminal
     */

    public int ruleNr(String symName, int altNr){
        int ntNr = symNr('n',symName) - numOfToks;   // nonterminal number
        if (ntNr < 0){
            throw new IllegalArgumentException(symName);
        }
        int rn = altNr + this.ntToRule[ntNr];
        if ((altNr < 0) ||
            (altNr >= this.ruleToNt.length) ||
            (this.ruleToNt[rn] != ntNr)){
            throw new IllegalArgumentException(Integer.toString(altNr));
        }
        return rn;
    }

    /**
     * Deliver the rule number of the specified nonterminal number and
     * alternative number.
     *
     * @param      symNr nonterminal number
     * @param      altNr alternative number
     * @return     rule number
     * @exception  IllegalArgumentException if the symbol number is
     *             invalid or if the number of the alternative
     *             exceeds the range of the ones of the nonterminal
     */

    public int ruleNr(int symNr, int altNr){
        if ((symNr < this.numOfToks) ||
            (this.numOfSyms <= symNr)){
            throw new IllegalArgumentException(
                Integer.toString(symNr));       // out of range
        }
        int ntNr = symNr - numOfToks;           // nonterminal number
        int rn = altNr + this.ntToRule[ntNr];
        if ((altNr < 0) ||
            (altNr >= this.ruleToNt.length) ||
            (this.ruleToNt[rn] != ntNr)){
            throw new IllegalArgumentException(Integer.toString(altNr));
        }
        return rn;
    }

    /**
     * Deliver the rule number of the specified term in the specified
     * rule for the specified alternative. If the term is a group, the
     * rule at the specified alternative in the body is delivered.
     *
     * @param      ruleNr number of the rule
     * @param      termNr number of the term
     * @param      altNr number of the alternative
     * @return     rule number, -1 if there is no such term or alternative
     *             or if the term is not a nonterminal or group
     * @exception  IllegalArgumentException if there is no such rule
     */

    public int ruleNr(int ruleNr, int termNr, int altNr){
        if ((FL_R & this.trc) != 0){
            Trc.out.println("ruleNr: " + ruleNr +
                " " + termNr + " " + altNr);
        }
        int start = getRule(ruleNr);                    // start of rule, gramRule
        if ((termNr < 0) ||
            (this.ruleLen[ruleNr] <= termNr)){          // no such term
            return -1;
        }
        int n = this.grammar[start + termNr];
        if (n >= this.tokBase){                         // token
            return -1;                                  // token number
        } else {
            int kind = this.ntKind[n];                  // kind
            switch (kind){
            case REU:                                   // {alpha}(:u)
                n = this.ruleIndex[this.ntToRule[n]];   // &0 ::= &2 .. &2
                n = this.grammar[n];                    // &2, gramRule
                n = this.ruleIndex[this.ntToRule[n]] +  // &2 ::= "" | &1, gramRule
                    this.ruleLen[this.ntToRule[n]] + 1;
                n = this.grammar[n];                    // &1, gramRule
                break;
            case RER:                                   // {alpha}(l:u)
            case REF:                                   // {alpha}(l)
            case OPT:                                   // [alpha]
                n = this.ruleIndex[this.ntToRule[n]];   // &1 ... &1 &2 ... &2
                n = this.grammar[n];                    // gramRule
                break;
            case RES:                                   // {alpha}*, {alpha}(0:)
                n = this.ruleIndex[this.ntToRule[n]] +  // &0 ::= ... | &1 &0 , gramRule
                    this.ruleLen[this.ntToRule[n]] + 1;
                if ((LEFTGROUPS & this.mode) != 0){
                    n++;
                }
                n = this.grammar[n];                    // &1, gramRule
                break;
            case REL:                                   // {alpha}(l:)
            case REP:                                   // {alpha}+
                n = this.ruleIndex[this.ntToRule[n]];   // &1 ...
                n = this.grammar[n];                    // &1, gramRule
                break;
            }
            int rn = altNr + this.ntToRule[n];
            if ((FL_R & this.trc) != 0){
                Trc.out.println("ruleNr: " +
                    (int)this.ntToRule[n] + " " + altNr);
            }
            if ((altNr < 0) ||
                (altNr >= this.ruleToNt.length) ||
                (this.ruleToNt[rn] != n)){
                rn = -1;
            }
            return rn;
        }
    }

    /**
     * Deliver the term number of the specified occurrence of the
     * specified symbol in the specified rule.
     *
     * @param      ruleNr number of the rule
     * @param      symNr number of the symbol
     * @param      symOcc number of the occurrence
     * @return     term number
     * @exception  IllegalArgumentException if there is no such symbol
     *             or occurrence or rule
     */

    public int termNr(int ruleNr, int symNr, int symOcc){
        int start = getRule(ruleNr);                 // start of rule
        if ((symNr < 0) ||
            (this.numOfSyms <= symNr)){
            throw new IllegalArgumentException(
                Integer.toString(symNr));            // out of range
        }
        if (symOcc < 0){
            throw new IllegalArgumentException(
                Integer.toString(symOcc));
        }
        int occ = symOcc;
        int res = 0;
        for (int i = start;                          // gramRule
            this.grammar[i] < this.ruleBase; i++){   // scan the rule
            int n = this.grammar[i];
            if (n >= this.tokBase){                  // token
                int tn = n - this.tokBase;           // token number
                if (tn == symNr){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            } else {                                 // nonterminal
                n += this.numOfToks;                 // symbol number
                if (n == symNr){
                    if (occ-- == 0){                 // n-th occurrence
                        res = i;
                        break;
                    }
                }
            }
        }
        if (res > 0) return res - start;             // found
        String s;
        if (occ < symOcc){                           // symOcc too large
            s = Integer.toString(symOcc);
        } else {                                     // not found
            s = Integer.toString(symNr);
        }
        throw new IllegalArgumentException(s);
    }

    /**
     * Deliver the index of the specified rule in the grammar.
     *
     * @param      ruleNr number of the rule
     * @return     index
     * @exception  IllegalArgumentException if there is no such rule
     */

    int getRule(int ruleNr){
        if ((ruleNr < 0) ||
            (this.numOfRules <= ruleNr)){
            throw new IllegalArgumentException(
                Integer.toString(ruleNr));           // out of range
        }
        return this.ruleIndex[ruleNr];
    }

    /**
     * Deliver a string representing the specified set of tokens.
     *
     * @param      s set of tokens
     * @return     string
     */

    String tokSetToString(BitSet s){
        String res = "";
        if (s == null) return res;
        int len = s.length();
        for (int i = 0; i < len; i++){
            if (!s.get(i)) continue;
            if (res.length() > 0) res += " ";
            res += this.tokLitName(i);
        }
        return "{" + res + "}";
    }

    /**
     * Tell if the specified nonterminal has more than one rule.
     *
     * @param      nt nonterminal
     * @return     <code>true</code> if it has, <code>false</code> otherwise
     * @exception  IllegalArgumentException if there is no such rule
     */

    boolean hasSeveralRules(int nt){
        int rule1 = this.ntToRule[nt];
        if (rule1+1 < this.ruleToNt.length &&
            this.ruleToNt[rule1+1] == nt){     // has several rules
            return true;
        }
        return false;
    }
}
