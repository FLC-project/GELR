/*
 * @(#)ParserHtmlLex.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;
import lbj.ParserLex;

/**
 * The <code>ParserHtmlLex</code> represents lexical analyzer for html.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

class ParserHtmlLex extends ParserLex {

    public ParserHtmlLex(){
       super();
    }
    public ParserHtmlLex(ParserTables au, Object inp, int size){
       super();
       lx = new ParserHtmlLexer(inp);
       this.stream = lx.stream;
    }

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_W = 1 << ('w'-0x60);

    private int state;
    private int subState;
    private int prev;
    private ParserHtmlLexer lx;
    Str s = new Str();

    int tokStr;
    int tokNameStr;
    int tokNqStr;
    int tokPCDATA;
    int tokScript;
    int tokStyle;
    int tokScriptBody;
    int tokStyleBody;
    int tokDelimiter;
    int tokEquals;

    public int lex(){
        if (this.lx == null){
            this.lx = new ParserHtmlLexer(this.stream);
        }
        if (this.aut != null){
            if (this.tokStr == 0){           // initialise
                this.tokStr = this.aut.symNr("string");
                this.tokNameStr = this.aut.symNr("namestring");
                this.tokNqStr = this.aut.symNr("nonquoted string");
                this.tokPCDATA = this.aut.symNr("#PCDATA");
                this.tokScript = this.aut.symNr('t',"<SCRIPT");
                this.tokStyle = this.aut.symNr('t',"<STYLE");
                this.tokScriptBody = this.aut.symNr("script-token");
                this.tokStyleBody = this.aut.symNr("style-token");
                this.tokDelimiter = this.aut.symNr("delimiter");
                this.tokEquals = this.aut.symNr('t',"=");
            }
        }
        int res = 0;
        int kind = 0;
        boolean found = false;
        doit: for(;;){
            if ((FL_W & lx.trc) != 0){
                Trc.out.println("loop state: " + this.state +
                    " " + this.subState + " " + lx.getLineNr());
            }
            if (lx.getProcInstr(s)) continue;
            switch (this.state){
            case 0:                              // element contents or tags
                switch (this.subState){
                case 0:                          // element contents or tags
                    if (lx.getUpToTag(s)){       // if something got, then pcdata
                        res = this.tokPCDATA;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        found = true;
                        break doit;
                    }
                    break doit;
                case 1:                          // script contents
                    if (lx.getUpToCloseTag(s)){
                        res = this.tokScriptBody;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    break doit;
                case 2:                          // style contents
                    if (lx.getUpToCloseTag(s)){
                        res = this.tokStyleBody;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    if (lx.getTagName(s)){       // nothing got, try with a tag
                        kind = 1;
                        this.state = 1;
                        this.subState = 0;
                        found = true;
                        break doit;
                    }
                    break doit;
                }
            default:                             // attributes
                if (lx.gdel("/>") ||
                    lx.gdel('>')){
                    this.state = 0;
                    kind = 2;
                    found = true;
                    break doit;
                }
                if (lx.getStr(s)){
                    res = this.tokStr;
                    found = true;
                    break doit;
                }
                if (lx.getNamestr(s)){
                    res = this.tokNameStr;
                    if (this.prev != this.tokEquals){  // if not after = it is a keyword
                        kind = 2;
                    }
                    found = true;
                    break doit;
                }
                if (lx.getNqStr(s)){
                    res = this.tokNqStr;
                    found = true;
                    break doit;
                }
                if (lx.gdel('=')){
                    kind = 2;
                    found = true;
                    break doit;
                }
                break doit;
            }
        }
        this.stream.cursor = lx.cursor;
        this.stream.end = lx.end;
        if (found){
            String tokenString = "";
            if ((this.stream.markPos >= 0) &&
                (this.stream.cursor > this.stream.markPos)){
                tokenString = toString();
            }
            if ((this.aut != null) && (tokenString.length() > 0)){
                if (kind == 1){
                    tokenString = tokenString.toUpperCase();
                } else if (kind == 2){
                    tokenString = tokenString.toLowerCase();
                }
                if ((kind == 1) || (kind == 2)){
                    int res1 = this.aut.symNr('t',tokenString);
                    if (res1 >= 0){
                        res = res1;
                    }
                    if (res == this.tokScript){
                        this.subState = 1;
                    } else if (res == this.tokStyle){
                        this.subState = 2;
                    }
                }
                this.aut.tokLists[1][0] = (char)res;
                if ((FL_W & lx.trc) != 0){
                    Trc.out.println("found " + tokenString + " " +
                        res + " " + this.aut.tokLitName(res) + " " +
                        this.aut.tokSetToString(1));
                }
                this.prev = res;
                res = 1;
            }
        }
        if ((FL_W & lx.trc) != 0){
            Trc.out.println("return " + res);
        }
        return res;
    }

}
