/*
 * @(#)ParserPool.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;

/**
 * The <code>ParserPool</code> represents a compact pool of strings.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

/*
 * This class allows to:
 *
 *    - store a set of strings in which no deletion is allowed, but
 *      insertion and search (intermixed)
 *    - be efficient in space and time
 *    - store strings which collectively occupy at most 2**31-1 chars
 *      (roughly)
 *    - it is suited for strings which are not extremely large.
 *
 * To store strings efficiently, instead of using Strings or char[] objects
 * for each strings, blocks of char[] are used, in which strings are placed.
 * Strings then have indexes instead of references. To access a string given
 * its index, a field of bytes is taken as block number, a pool directory
 * accessed to get the reference to the block in which the string lies,
 * and the remaining bits of the index taken as the offset in the block
 * where the string is.
 * Strings are stored with no gaps between them and without crossing blocks
 * (and thus leaving holes between blocks). The pool is homogeneous: strings
 * can be identified by scanning it (which is needed to rehash them).
 * It is difficult to release this constraint.
 *
 * To save space, identical strings are stored only once. A special hash table
 * saves a lot of space.
 * Chains of the hash table could be implemented as blocks in which all
 * strings which have the same hash value are stored. In so doing, no links
 * would be stored. When a block is not sufficient, more would be allocated.
 * To do it, chains would be made of objects with a link and a char[] as block.
 * However, chains are supposed to be short, which means that there would be
 * much memory wasted in scraps in blocks. Storing entire chains in blocks
 * requires also to resize them.
 * Moreover, there is a need for an easy rehashing since it is not possible
 * to fix the size of the hash table from the very beginning.
 * Therefore, the hash table is implemented as chains of elements which are
 * linked (which allows to rehash them by changing the links only and not
 * moving the elements).
 *
 * There is a need to store the characters, the lengths, and the links.
 * This can be done by using blocks ("pool") in which hash entries are stored
 * as:
 *
 *        link, length, characters
 *
 * This takes less memory than what would be needed if each entry were an
 * object because the latter needs an internal field for its class, another
 * as a reference to a char[] and the char[] needs an internal field as well.
 * Moreover, it is also possible to represent most lenghts on 16 bits (to store
 * longer strings, when the length has the highest bit set, then two characters
 * are used).
 * To compress lengths in one or two characters (or even as 1..4 bytes if
 * blocks of bytes were used), if the first one has the MSB set, then that
 * bit is descarded, and the second character taken as the bits 7..14 of
 * the length. This allows to represent all non-negative integer values
 * which is the range of lengths).
 *
 * Since hash elements are stored in char[] blocks, links cannot be stored
 * as references, but they need to be represented in chars, which ultimately
 * are integer values. Links are then represented as integers denoting
 * block+offset numbers.
 * Links are stored efficiently, i.e. 1..2 chars by reserving 1 char for all
 * elements which are placed in the first 64K of the pool, and 2 chars
 * for the others and by not reversing the chains when rehashing.
 * With an average string length of 10, 10% of space would be saved and
 * there is no time increase.
 * In so doing, elements over 64K would be able to refer to all elements while
 * the ones below it would refer only to elements below it.
 * In order to do it, when searching for space, the 64K is not crossed.
 * I.e. if the block at which search starts is above 64K, search does not
 * go below 64K.
 * When the hash chains become longer on average than the configured load
 * factor, rehasing is done. I do not know of any technique which avoids
 * this. It could be possible to perform it over time instead of in one
 * shot, but eventually it would be done.
 * Rehashing improves performance: on average the gain in the overall time
 * spent in seaching is 30%.
 * To rehash, the blocks are processed in sequence, not chains because a
 * chain can contain strings over 64K, followed by chains which have strings
 * below 64K, which should be re-chained after the ones above 64K.
 * The hash function used is similar to the one used in Java String.
 * The ones used in minimal hashing (e.g. first+middle+last+length) are
 * not easily applicable when the keys are not known all in advance since
 * they need to be tuned on the keys.
 *
 * A string has an index which is that of its link.
 *
 * A maximum of 2**31-1 chars are stored, which means that pool indexes
 * and lengths can be represented with an int.
 *
 * There is a problem when strings must be stored whose length is greater
 * than the block size since not even a new block can store it.
 * A solution could be to store strings across blocks, but that complicates
 * access since it would not be possible to return a reference to the
 * block, an offset and a length, and instead a method which would allocate
 * an array or string and store the string in it would be needed.
 * Another solution is to allocate a large block containing a long string
 * and treat it as if it were a normal one: what is important is to seek
 * the block number and offset of the start of elements, no matter how
 * much they extend after it, and since such a string would start at the
 * beginning of the block, its index would be computed in the normal way.
 * The reasons to break long strings in segments are: to save space,
 * and to make memory management easier (since it is more efficient to
 * allocate blocks rather than large arrays). If strings are not split
 * across blocks, the waste of space is around 5%, which is negligible.
 * The reason not to break is that the implementation becomes significantly
 * more complex.
 * Moreover, large strings occur seldom, which means that the second
 * solution is better.
 * A block which has an oversized string in it has an offset of the first
 * unused character equal to the maximum block size. This similates a
 * full block. Note that is would not be possible to store in a char
 * an offset larger than 64K.
 *
 * The characters of strings can be represented in UTF8.
 * The implementation becomes more complex. Strings have to be encoded
 * in a temporary byte buffer so as not to redo the operation several
 * times when searching hash chains and when storing. Decoding should also
 * be done on a temporary buffer. Moreover, if characters are compressed,
 * then it is not possible to provide direct access to them, but toString(),
 * or toCharArray() must be used instead. Direct access is not provided,
 * but for a different reason, i.e. to allow to change the way strings
 * are stored.
 * The net result is that it becomes 2..3 times slower (making a benchmark
 * with also a call to toString()), and uses 30% more memory with a random
 * text, while it takes less with Ascii texts. For this reason, it is not done.
 *
 * In pool blocks the first value is the offset in the block of the first
 * free element.
 * To find a place to store a string, the last blocks of the pool are searched 
 * backwards so that the last one (which is the one less full) is taken first.
 * If no space is found in it, a limited number of blocks is visited since
 * there is little chance to find some space if none has been found in some
 * blocks.
 *
 * The problem with a large pool is that the pool directory can become quite
 * large. If a small block size is chosen, then little space is wasted for
 * blocks, but then a large directory is needed. To be realistic, a large
 * text can contain 10 Mbytes of lexemes, which need 24 bits, i.e.
 * 4094 blocks of 4096 characters. A pool directory long 256 would allow
 * to hold 1 Mbyte, and half with blocks long 2048.
 * It is also possible to double each time the pool directory to decrease
 * resizing.
 * Blocks are currently configured to 2048 chars.
 *
 * It requires 380 msec/Mchar for insertion with no rehashing, 430 with
 * rehashing, 840 for insertion and extraction, and it takes 1.3 bytes
 * per inserted char for an input with 50% repeatitiveness.
 * This class it is slightly slower than HashTbl on HP (but 2 times slower
 * on PC).
 * However, to cater for inputs which are repetitive (i.e. add operations
 * which have strings that are similar to each other), the hash function
 * needs to scan most of the characters. This increases the time required
 * to 630 msec/Mchar (i.e. 1.5 Mchar/sec).
 *
 * To use space in a more linear way, the hash directory and pool initial
 * sizes are kept small.
 * To grow even in a more linear way when there are few strings, it would be
 * possible to allocate a 512 chars block zero. When full, it can be extended
 * to 1024, and then to the max block size.
 * However, treating all cases of small and large strings with first block
 * undersised and not requires so much code that the gain is little or null.
 * E.g. there is a need to treat block zero as resizable only when it is
 * undersized or when a string larger than the block size need be stored.
 * This need be done all the times space is looked for, and not only when
 * block zero it the only one present.
 *
 * The compression obtained with hashing reduces the time needed to
 * manage memory (enlarge directories, allocate new blocks, etc.).
 * The results for storing 1 M chars are:
 *
 *    % elements hashed   memory Mbytes  time msec
 *
 *         0 %              2.4            650
 *        30 %              2.0            550
 *        60 %              1.7            510
 *       100 %              1.2            440
 *
 * I.e. hashing less elements saves time in searching hash tables, but
 * spends much more time in allocating, leading to a net result which is
 * worse than with hashing. These results have been obtained with an
 * insertion of 50% duplicated elements. With 30% (i.e. an input which
 * is less repeatitive) the results are not much different, and become
 * more flat for non-repetitive inputs.
 * Since hasing pays off, or at worst is not influent, there is no need
 * to adjust dynamically the ratio of elements which are hashed to inprove
 * performance adapting to the repeatitiveness of the input.
 * Repeatitiveness is the number of hits divided by the number of insertions
 * (repeatitiveness) in percentage.
 */

class ParserPool {

    /** The hash directory. */
    private int[] hdir;

    /** The maximum average number of elements per chain. */
    private float loadFactor;

    /** The number of elements bejond which rehash is done. */
    private int threshold;

    /** The number of elements. */
    private int elemNr;

    /** The directory of blocks. */
    private char[][] poolDir;

    /** The length of the hash directory. */
    private static final int HASH_DIR = 512;

    /** The length of the directory of blocks. */
    private static final int POOL_DIR = 64;

    /** The number of bits of the block offset. */
    private static int POOL_SHIFT = 11;

    /** The block length. */
    private static int POOL_SIZE = 1 << POOL_SHIFT;

    /** The mask to extract the block offset from an string index. */
    private static int POOL_MASK = POOL_SIZE - 1;

    /** The number of the last block. */
    private int lastBlock;

    /** The number of times an add has found the string in the pool. */
    private int hits;

    /** The number of times strings have been added. */
    private int accesses;

    /** The number of times the pool has been rehashed. */
    private int rehashed;

    /** The hash rate: percentage of insertions hashed. */
    long incoming;

    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    b   basic trace
     *    p   add operations
     *    q   block details
     *    r   rehash details
     * </pre></blockquote><p>
     */

    static final int FL_B = 1 << ('b'-0x60);
    static final int FL_P = 1 << ('p'-0x60);
    static final int FL_Q = 1 << ('q'-0x60);
    static final int FL_R = 1 << ('r'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a string pool.
     *
     * @param      cap length of the hash directory
     */

    ParserPool(int cap){
        this.hdir = new int[cap];
        this.loadFactor = 2;
        this.threshold = (int)(this.hdir.length * this.loadFactor);
        this.poolDir = new char[POOL_DIR][];       // initial pool dir size
        this.elemNr = 0;
        this.lastBlock = -1;
    }

    /**
     * Construct a string pool.
     */

    ParserPool(){
        this(HASH_DIR);
    }

    /**
     * Add the specified string to this pool.
     *
     * @param      buf array that holds the string
     * @param      off offset in it
     * @param      len length of the string
     * @return     index of the string, always > 0
     */

    /* The returned index is always > 0 since the first index of each
     * block is reserved.
     */

    int addUnique(char[] buf, int off, int len){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("add: " + len + " chars");
        }
        if ((FL_P & this.trc) != 0){
            Trc.out.print("add: ");
            literalize(buf,off,len);
            Trc.out.println();
        }
        this.accesses++;                       // one access more
        this.incoming += len;
        char[] blk;
        int bn;                                // block number
        int blkOff;                            // offset in it
        int e = 0;                             // index in chain

        int hvalue = 0;                        // determine hash value
        if (len > 0){
            //hvalue = buf[off] + buf[off + (len >> 1)] +
            //  buf[off + len - 1] + len;
            e = off + len;
            for (int i = off; i < e; i += 2){
                hvalue = 31*hvalue + buf[i];
            }
        }
        hvalue = (hvalue & 0x7FFFFFFF) % this.hdir.length;
        sea: for (e = this.hdir[hvalue];
            e != 0;){                          // scan the chain
            bn = e >>> POOL_SHIFT;
            blk = this.poolDir[bn];
            blkOff = e & POOL_MASK;            // offset in block
            int next = blk[blkOff++];          // link to next
            if (e >= 0x10000){                 // on 2 chars
                next |= blk[blkOff++] << 16;
            }
            cmp: {                             // compare strings
                int lt = blk[blkOff++];        // length
                if (lt >= 0x8000){             // on 2 chars
                    lt &= ~0x8000;
                    lt |= blk[blkOff++] << 15;
                }
                if (lt != len) break cmp;      // different lenghts
                int i = off + len;
                lt += blkOff;
                while (--lt >= blkOff){        // compare contents
                    if (blk[lt] != buf[--i]){
                        break cmp;
                    }
                }

                this.hits++;
                if ((FL_B & this.trc) != 0){
                    Trc.out.println("added");
                }
                return e;                      // same code: found
            }
            e = next;
        }

        // not found
        // insert
        
        seek: {
            int eLen = 3 + len;                // 2 for link, 1 for length
            if (len >= 0x8000) eLen++;         // long length
            bn = this.lastBlock;               // find free space in last
            int bEnd = bn - 7;                 // .. blocks (7) from end
            if (bEnd < 0) bEnd = 0;
            if ((bn << POOL_SHIFT) >= 0x10000){
                int bmin = 0x10000 >> POOL_SHIFT;
                if (bEnd < bmin) bEnd = bmin;  // once past 64K, never before
            }
            for (; bn >= bEnd; bn--){
                blk = this.poolDir[bn];
                blkOff = blk[0];
                int l = blk.length;            // long blocks show up as full
                if (l > POOL_SIZE) l = POOL_SIZE;
                if (eLen < l - blkOff){
                    break seek;
                }
            }
            int size = POOL_SIZE;              // not found
            if (eLen > size - 1){              // string larger than block
                size = eLen + 1;
            }
            bn = enlargePool(size);            // allocate or enlarge it
            blk = this.poolDir[bn];
            blkOff = 1;                        // leave space for free
        }
        e = (bn << POOL_SHIFT) | blkOff;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("ins blk: " + bn +
                " at: " + blkOff + " idx: " + e);
        }

        //checkPool("before");

        int head = this.hdir[hvalue];
        blk[blkOff++] = (char)head;            // insert on top chain
        if (e >= 0x10000){                     // long link
            blk[blkOff++] = (char)(head >>> 16);
        }
        this.hdir[hvalue] = e;                 // link to last
        blk[blkOff++] = (char)len;
        if (len >= 0x8000){                    // store now the string
            blk[blkOff-1] |= 0x8000;
            blk[blkOff++] = (char)(len >>> 15);
        }
        int end = blkOff + len;
        while (blkOff < end){
            blk[blkOff++] = buf[off++];
        }
        if (blkOff >= 0x10000){                // block larger than standard
            blkOff = (char)POOL_SIZE;          // simulate block full
        }
        blk[0] = (char)blkOff;

        //if (this.elemNr == Integer.MAX_VALUE){
        //    throw new OutOfMemoryError();    // never occurs
        //}
        this.elemNr++;
        if (this.elemNr > this.threshold){     // directory too crowded
            rehash((int)(this.hdir.length * 1.5F));
        }
        //checkPool("after");
        if ((FL_B & this.trc) != 0){
            Trc.out.println("added");
        }
        return e;
    }

    /**
     * Enlarge the pool by the specified number of characters.
     *
     * @param      size number of characters
     */

    private int enlargePool(int size){
        if ((FL_B & this.trc) != 0){
            Trc.out.println("enlargePool: " + size);
        }
        int bn = ++this.lastBlock;             // next block number
        if (bn == this.poolDir.length){        // resize directory
            if (bn > (~POOL_MASK >>> POOL_SHIFT)){
                throw new OutOfMemoryError();  // block out of range
            }
            int newlen = (int)(this.poolDir.length * 1.5F); 
            if (newlen < 0){
                throw new OutOfMemoryError();
            }
            char[][] np = new char[newlen][];
            System.arraycopy(this.poolDir,0,np,0,this.poolDir.length);
            this.poolDir = np;
            if ((FL_B & this.trc) != 0){
                Trc.out.println("pool dir resized: " + newlen);
            }
        }
        char[] blk = new char[size];           // allocate a block
        this.poolDir[bn] = blk;
        if ((FL_B & this.trc) != 0){
            Trc.out.println("new block: " + bn);
        }
        return bn;
    }

    /**
     * Reduce the pool by resizing the directory or the last block when
     * the unused space higher than 20% of the total one to the strictly
     * needed size. Remove the hash directory. After this operation, no
     * strings can be stored.
     */

    public void reducePool(){
        if (this.lastBlock < 0){                         // nothing allocated
            this.hdir = null;
            return;
        }
        int free = this.poolDir.length - this.lastBlock - 1;
        if (((free * 100) / this.poolDir.length) > 20){  // resize it
            char[][] np = new char[this.lastBlock + 1][];
            System.arraycopy(this.poolDir,0,
                np,0,np.length);
            this.poolDir = np;
        }
        int size = this.poolDir[this.lastBlock].length;
        free = size - this.poolDir[this.lastBlock][0];
        if (((free * 100) / size) > 20){                 // resize it
            int len = size - free;
            char[] np = new char[len];
            System.arraycopy(this.poolDir[this.lastBlock],0,
                np,0,len);
            this.poolDir[this.lastBlock] = np;
        }
        this.hdir = null;
    }

    /**
     * Check the consistency of the pool.
     *
     * @param      str string to be printed in front of error messages
     */

    /*
    private void checkPool(String str){
        int elems = 0;
        int ai = 0;
        int dl = this.hdir.length;
        for (int row = 0; row < dl; row++){       // scan all chains
            int e = this.hdir[row];
            while (e != 0){                       // scan the chain
                elems++;
                int bn = e >>> POOL_SHIFT;
                if (bn > this.poolDir.length){
                    Trc.out.println(str + " bn out " +
                        bn + " " + this.poolDir.length);
                    System.exit(1);
                }
                char[] blk = this.poolDir[bn];
                if (blk == null){
                    Trc.out.println(str + " blk null " + bn);
                    System.exit(1);
                }
                int blkOff = e & POOL_MASK;       // offset in block
                if (blkOff > blk.length){
                    Trc.out.println(str + " off out " +
                        bn + " " + blkOff +  " " + blk.length);
                    System.exit(1);
                }
                int free = blk[0];
                if (blkOff > free){
                    Trc.out.println(str + " off free " +
                        bn + " " + blkOff +  " " + free);
                    System.exit(1);
                }
                int next = blk[blkOff++];         // save pointer to next
                if (e >= 0x10000){                // on 2 chars
                    next |= blk[blkOff++] << 16;
                }
                int lt = blk[blkOff++];           // length
                if (lt >= 0x8000){
                    lt &= ~0x8000;
                    lt |= blk[blkOff++] << 15;
                }
                int end = blkOff + lt;
                if (end > blk.length){
                    Trc.out.println(str + " end out " +
                        bn + " " + blkOff + " " + lt +
                        " " + blk.length + " " + e);
                    System.exit(1);
                }
                if ((end > free) &&
                    (blk.length < POOL_SIZE)){
                    Trc.out.println(str + " end free " +
                        bn + " " + end + " " + free);
                    System.exit(1);
                }
                e = next;                        // step to next chain
            }
        }
        if (elems != this.elemNr){
            Trc.out.println(str + " elems " +
                elems + " " + this.elemNr);
        }
    }
    */

    /**
     * Rehash the hash table.
     *
     * @param      ln new length of the hash directory
     */

    void rehash(int ln){
        if ((FL_P & this.trc) != 0){
            Trc.out.println("rehash");
        }
        int[] newDir = new int[ln];
        for (int bn = 0; bn <= this.lastBlock; bn++){
            char blk[] = this.poolDir[bn];
            if ((FL_R & this.trc) != 0){
                Trc.out.println("rehash block: " + bn);
            }
            int blkOff = 1;
            int last = blk[0];
            int base = bn << POOL_SHIFT;
            while (blkOff < last){
                int e = base | blkOff;
                int off = blkOff;
                blkOff++;                         // skip link
                if (e >= 0x10000) blkOff++;       // on 2 chars
                int lt = blk[blkOff++];
                if ((lt & 0x8000) != 0){
                    lt &= ~0x8000;
                    lt |= blk[blkOff++] << 15;
                }
                int hvalue = 0;
                if (lt > 0){
                    //hvalue = blk[blkOff] + blk[blkOff + (lt >> 1)] +
                    //   blk[blkOff + lt - 1] + lt;
                    int eoff = blkOff + lt;
                    for (int i = blkOff; i < eoff; i += 2){
                        hvalue = 31*hvalue + blk[i];
                    }
                }
                hvalue = (hvalue & 0x7FFFFFFF) % newDir.length;
                blkOff += lt;
                int head = newDir[hvalue];
                blk[off++] = (char)head;          // insert on top
                if (e >= 0x10000){
                    blk[off] = (char)(head >>> 16);
                }
                newDir[hvalue] = e;               // link to last
                if ((FL_R & this.trc) != 0){
                    Trc.out.print("rehashed: ");
                    literalize(blk,blkOff-lt,lt);
                    Trc.out.println();
                }
            }
        }

        this.hdir = newDir;                       // store the new directory
        this.threshold = (int)(ln * this.loadFactor);
        this.rehashed++;
        //checkPool("rehash");
        if ((FL_P & this.trc) != 0){
            Trc.out.println("end rehash");
        }
    }

    /**
     * Copies a string from the pool into the specified array.
     *
     * @param      a array
     * @param      e index of string
     * @return     reference to the (possibly enlarged) array
     */

    private char[] toCharArray(char[] a, int e){
        int bn = e >>> POOL_SHIFT;
        char[] blk = this.poolDir[bn];
        int blkOff = e & POOL_MASK;      // offset in block
        blkOff++;                        // skip link
        if (e >= 0x10000) blkOff++;      // on 2 chars
        int len = blk[blkOff++];         // length
        if (len >= 0x8000){
            len &= ~0x8000;
            len |= blk[blkOff++] << 15;
        }
        if ((a == null) || (a.length < len)){
            a = new char[len];           // enlarge array
        }
        int i = 0;                       // copy string
        int end = blkOff + len;
        while (blkOff < end){
            a[i++] = blk[blkOff++];
        }
        return a;
    }

    /**
     * Deliver the index of the element which is next in the hash
     * chain to this one.
     *
     * @return     index
     */

    private int next(int e){
        int bn = e >>> POOL_SHIFT;
        char[] blk = this.poolDir[bn];
        int blkOff = e & POOL_MASK;      // offset in block
        int next = blk[blkOff++];        // save pointer to next
        if (e >= 0x10000){               // on 2 chars
            next |= blk[blkOff++] << 16;
        }
        return next;
    }

    /**
     * Deliver the length of the specified string
     *
     * @param      e index of the string
     * @return     length
     */

    public int length(int e){
        int bn = e >>> POOL_SHIFT;
        int blkOff = e & POOL_MASK;       // offset in block
        char[] blk = this.poolDir[bn];
        blkOff++;                         // skip link
        if (e >= 0x10000) blkOff++;       // on 2 chars
        int len = blk[blkOff++];          // length
        if (len >= 0x8000){
            len &= ~0x8000;
            len |= blk[blkOff++] << 15;
        }
        return len;
    }

    /**
     * Deliver the specified string.
     *
     * @param      e index of the string
     * @return     string
     */

    public String toString(int e){
        int bn = e >>> POOL_SHIFT;
        int blkOff = e & POOL_MASK;       // offset in block
        char[] blk = this.poolDir[bn];
        blkOff++;                         // skip link
        if (e >= 0x10000) blkOff++;       // on 2 chars
        int len = blk[blkOff++];          // length
        if (len >= 0x8000){
            len &= ~0x8000;
            len |= blk[blkOff++] << 15;
        }
        return String.valueOf(blk,blkOff,len);
    }

    /**
     * Deliver all strings of this pool as an array.
     *
     * @return     array of Strings
     */

    public Object[] toArray(){
        Object[] a = new Object[this.elemNr];
        return toArray(a);
    }

    /**
     * Deliver all strings of this pool into the specified array.
     *
     * @return     a array
     * @return     (possibly enlarged) array
     */

    public Object[] toArray(Object[] a){
        if (a.length < this.elemNr){
            a = new Object[this.elemNr];
        }
        int ai = 0;
        int dl = this.hdir.length;
        for (int row = 0; row < dl; row++){      // scan all chains
            int e = this.hdir[row];
            while (e != 0){                      // scan the chain
                a[ai++] = toString(e);
                e = next(e);                     // step to next chain
            }
        }
        return a;
    }

    /**
     * Deliver the number of strings stored in this pool.
     *
     * @return     number of strings
     */

    public int length(){
        return this.elemNr;
    }

    /**
     * Trace this pool.
     */

    void trace(){
        trace(this.lastBlock);
    }

    /**
     * Trace this pool.
     *
     * @param      n highest number of block to trace, 0 to trace
     *             all, -1 to trace none
     */

    void trace(int n){
        statistics(Trc.wrt);
        if (n < 0) return;
        int bmax = this.lastBlock;
        if ((n > 0) && (bmax > n)) bmax = n;
        for (int bn = 0; bn <= bmax; bn++){
            char blk[] = this.poolDir[bn];
            int blkOff = 1;
            int free = blk[0];
            Trc.out.println("pool block: " + bn +
                " free: " + free);
            int base = bn << POOL_SHIFT;
            while (blkOff < free){
                int e = base | blkOff;
                int next = blk[blkOff++];             // link to next
                if (e >= 0x10000){
                    next |= blk[blkOff++] << 16;
                }
                int len = blk[blkOff++];
                if ((len & 0x8000) != 0){
                    len &= ~0x8000;
                    len |= blk[blkOff++] << 15;
                }
                Trc.out.print(e + " link: " + next + " len: " + len + " ");
                literalize(blk,blkOff,len);
                Trc.out.println();
                blkOff += len;
            }
            if ((FL_Q & this.trc) != 0){
                for (int j = 0; j < free; j++){
                    Trc.out.println("blk[" + j + "]: " +
                        (int)blk[j] + " " + Integer.toHexString(blk[j]));
                }
            }
        }

        if (this.hdir == null) return;
        int dl = this.hdir.length;
        for (int row = 0; row < dl; row++){      // scan all chains
            int nr = 0;                          // nr of elements in the chain
            int e = this.hdir[row];
            while (e != 0){                      // scan the chain
                if (nr == 0){
                    Trc.out.println("---chain nr: " + row);
                }
                nr++;                            // count elements in chain
                char[] a = toCharArray(null,e);
                literalize(a,0,a.length);
                Trc.out.println();
                e = next(e);                     // step to next chain
            }
        }
    }

    /**
     * Trace a string compressing it if too long.
     *
     * @param      buf array that holds the string
     * @param      off offset in it
     * @param      len length of the string
     */

    private static void literalize(char[] buf, int off, int len){
        if (len > 20){
            Trc.literalize(buf,off,20);
            Trc.out.print("...");
            Trc.literalize(buf,off+len-3,3);
        } else {
            Trc.literalize(buf,off,len);
        }
    }

    /**
     * Deliver the size in bytes occupied by this pool.
     *
     * @return     size
     */

    public long size(){
        long mem = 0;
        if (this.hdir != null){
            mem += 4 + this.hdir.length * 4;     // size of hash directory
        }
        mem += 4 + this.poolDir.length * 4;      // size of blocks
        for (int i = 0; i < this.poolDir.length; i++){
            char[] blk = this.poolDir[i];
            if (blk == null) break;
            mem += 4 + blk.length * 2;
        }
        return mem;
    }

    /**
     * Print the statistics of this pool.
     *
     * @param      trc trace stream
     */

    public void statistics(PrintWriter trc){
        trc.println("elements: " + this.elemNr +
            " blocks: " + (this.lastBlock+1) +
            " threshold: " + this.threshold +
            " hash dir: " + (this.hdir == null ? 0 : this.hdir.length) +
            " pool dir: " + this.poolDir.length);
        trc.println("rehased: " + this.rehashed + " times");
        int tot  = 0;
        int spare = 0;
        int totChars = 0;
        for (int bn = 0; bn <= this.lastBlock; bn++){
            char blk[] = this.poolDir[bn];
            int blkOff = 1;
            int free = blk[0];
            tot += blk.length;
            spare += blk.length - free;
            int base = bn << POOL_SHIFT;
            while (blkOff < free){
                int e = base | blkOff;
                int next = blk[blkOff++];             // link to next
                if (e >= 0x10000){
                    next |= blk[blkOff++] << 16;
                }
                int len = blk[blkOff++];
                if ((len & 0x8000) != 0){
                    len &= ~0x8000;
                    len |= blk[blkOff++] << 15;
                }
                totChars += len;
                blkOff += len;
            }
        }
        long mem = size();
        trc.println("pool memory: " + mem + " bytes");
        tot *= 2;
        spare *= 2;
        float ratio = 0.0F;
        if (tot > 0){
            ratio = (((float)tot - (float)spare)/(float)tot)*100;
        }
        trc.println("tot string space: " + tot +
            " unused: " + spare + " fill ratio: (" + ratio + "%)");
        ratio = 0.0F;
        if (this.accesses > 0){
            ratio = ((float)this.hits/(float)this.accesses)*100;
        }
        trc.println("accesses: " + this.accesses +
            " hits: " + this.hits + " (" + ratio + "%)");
        ratio = 0.0F;
        if (totChars > 0){
            ratio = (float)mem/(float)totChars;
        }
        trc.println("store ratio: " + ratio + " bytes/char");
        ratio = 0.0F;
        if (this.elemNr > 0){
            ratio = (float)totChars/(float)this.elemNr;
        }
        trc.println("average string length: " + ratio);
        ratio = 0.0F;
        if (this.incoming > 0){
            ratio = ((float)totChars/(float)this.incoming)*100;
        }
        trc.println("input chars: " + this.incoming +
            " stored: " + totChars + " " + ratio + "% of input");
    }
}
