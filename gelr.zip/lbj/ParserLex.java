/*
 * @(#)ParserLex.java       1.0 2000/01/29
 *
 * Copyright (c) 1998-2020 Angelo Borsotti. All Rights Reserved.
 *
 */

package lbj;

import java.io.*;
import java.util.*;

/**
 * The <code>ParserLex</code> represents lexical analyzers.
 *
 * @author  Angelo Borsotti
 * @version 1.0   29 Jan 2000
 */

class ParserLex {

    /** The reference to the automaton. */
    ParserTables aut;

    /** The reference to the input object. */
    Object inp;

    /** The reference to the input stream. */
    BufReader stream;

    /** The default block size for reading input. */
    private static final int BLOCK_SIZE = 2048;

    // Vaues kept here to speed up lex()

    /* The category map of the automa. */
    char[][] catMap;

    /* The category map of the first 256 characters of the automa. */
    char[] catMap0;

    /* The transition table of the automa. */
    char[][] transTable;

    /* The comb-vector transition table of the automa. */
    int[] tabMerged;

    /* The state attributes of the automa. */
    int[] stateAttrs;

    /* The initial state of the automa. */
    char initialState;


    int err;          // error code

    private static final int  lex_end_err = 1;  // terminated input
    private static final int  lex_rep_err = 2;  // reposition error
    private static final int  lex_ios_err = 3;  // io error


    /** The trace flags. */
    int trc;

    /*
     * Internal constants for trace flags
     */

    /**
     * The following trace flags are used:
     * <p><blockquote><pre>
     *    a   input operations trace
     *    b   input operations detail
     * </pre></blockquote><p>
     */

    static final int FL_A = 1 << ('a'-0x60);
    static final int FL_B = 1 << ('b'-0x60);

    /**
     * Set the trace flags which are specified in the argument.
     * The string must contain only lowercase letters.
     * Upon return <code>trc</code> is the powerset of flags augmented
     * with the ones specified.
     *
     * @param      s string of flags
     */

    public void settrc(String s){
        this.trc = 0;
        for (int i = 0; i < s.length(); i++){
            this.trc |= 1 << (s.charAt(i) - 0x60);
        }
    }

    /**
     * Construct a lexing engine.
     */

    public ParserLex(){
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
     */

    public ParserLex(ParserTables au){
        this.aut = au;
        this.catMap = this.aut.catMap;
        this.catMap0 = this.aut.catMap0;
        this.transTable = this.aut.transTable;
        this.tabMerged = this.aut.tabMerged;
        this.stateAttrs = this.aut.stateAttrs;
        this.initialState = this.aut.initialState;
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
     * @param      inp input object
     * @param      size size of the input buffer
     */

    public ParserLex(ParserTables au, Object inp, int size){
        this(au,new BufReader(inp,size));
    }

    /**
     * Construct a lexing engine.
     *
     * @param      au automaton
     * @param      inp input object
     */

    public ParserLex(ParserTables au, Object inp){
        this(au);
        if (inp != null){
            if (inp instanceof BufReader){
                this.stream = (BufReader)inp;
            } else {
                this.stream = new BufReader(inp,BLOCK_SIZE);
            }
        }
    }

    /** 
     * Trace the state of this lexer.
     */

    void trace(){
        Trc.out.println("index: " + index());
    }

    /**
     * The number of bits to shift a character to obtain the block
     * number in the category table.
     */
    protected static final int CAT_SHIFT = ParserTables.CAT_BLK_BITS;

    /**
     * The mask to obtain the offset in the block of the category table
     * for a character.
     */
    protected static final int CAT_MASK = (1 << CAT_SHIFT) - 1;

    /**
     * Deliver the next lexeme.
     *
     * @param      ???????????? kind of lexeme, set of lexemes ....
     * @return     code of the set of the lexemes recognised, 0 if none
     *             recognized
     */

    /*
     * The cursor runs a couple of characters ahead because when the last
     * character of a lexeme is scanned, the cursor is autoincremented, which
     * means that it refers to the character after the last. Then, since
     * scanning continues until no more transitions are possible, the next
     * character is taken (the one which does not belong to the lexeme), and
     * the cursor autoincremented. However, since the cursor is recorded at
     * every final state, it is taken back to its correct position.
     * This in order to spare a statement which increments it after.
     *
     * The test on the state made at the beginning of the loop allows to
     * recognize also the empty string, which is not strictly necessary, but
     * makes it more complete. Moreover, it allows to spare a while (true) at
     * the end of the loop.
     *
     * When a ParserLex is built, the BufReader is built as well. The
     * initial values of cursor and end are known to be zero. Therefore,
     * the initial index can be computed, and the mark set as well.
     * However, when scanning is resumed after some other method took
     * over processing, cursor is equal to end, but not known. Thus, to
     * set the mark (which is used here as start index as well), a mark()
     * is done, which sets the mark to the first unscanned character whatever
     * its position is.
     *
     * The index of the first character of the lexeme is:
     *
     *     this.stream.index - end + cursor;
     *
     * computed when cursor denoted the first character. Likewise, it
     * is the index of the end of the lexeme if computed at the end,
     */

    public int lex(){
        char[][] catMap = this.catMap;           // place references into
        char[] catMap0 = this.catMap0;           // .. variables to speed up
        int[] tabMerged = this.tabMerged;

        char[] buffer = this.stream.buffer;
        int cursor = this.stream.cursor;
        int end = this.stream.end;

        int acceptAttrs = 0;                     // last recongnized lexemes
        char state = this.initialState;          // initial state
        int lastPos = 0;                         // last position matched
        if (cursor == end){
            this.stream.mark();
        } else {
            this.stream.markPos = cursor;        // mark start of lexeme
        }
        int elem;
        loop: do {
            char ch;
            char cat;
            int attrs;
            if ((attrs = tabMerged[state-2]) < 0){           // special
                if ((attrs & ParserTables.LOOPING) != 0){    // looping
                    if ((attrs &= ParserTables.FINAL) != 0){
                        acceptAttrs = attrs;
                    }
                    char loopstate = state;
                    do {
                        if (cursor == end){                  // get symbol, no data
                            int n = this.stream.readBlock(); // get next block
                            cursor = this.stream.cursor;     // reload indexes
                            end = this.stream.end;
                            buffer = this.stream.buffer;
                            if (n < 0){                      // no symbol, eof
                                if (attrs != 0){             // remember it
                                    lastPos = cursor - this.stream.markPos;
                                }
                                cursor++;                    // cater for cursor-- below
                                break loop;                  // no more characters
                            }
                        }
                        ch = buffer[cursor++];               // get symbol and advance
                        cat =
                            (ch <= 0xff) ? catMap0[ch] :
                            ((catMap == null) ? 0 : catMap[ch >> CAT_SHIFT][ch & CAT_MASK]);
                        if ((char)(elem = tabMerged[state+cat]) != state){
                            state = (char)(tabMerged[state-1] >> 16);
                            if ((char)(elem = tabMerged[state+cat]) != state){
                                if (attrs != 0){             // remember it
                                    lastPos = cursor - this.stream.markPos - 1;
                                }
                                break loop;
                            }
                        }
                    } while ((state = (char)(elem >> ParserTables.NSHIFT)) == loopstate);
                    if (attrs != 0){             // remember it
                        lastPos = cursor - this.stream.markPos - 1;
                    }
                    continue loop;
                }
                if ((attrs &= ParserTables.FINAL) != 0){     // remember it
                    lastPos = cursor - this.stream.markPos;
                    acceptAttrs = attrs;
                }
            }
            if (cursor == end){                  // get symbol, no data
                int n = this.stream.readBlock(); // get next block
                cursor = this.stream.cursor;     // reload indexes
                end = this.stream.end;
                buffer = this.stream.buffer;
                if (n < 0){                      // no symbol, eof
                    cursor++;                    // cater for cursor-- below
                    break;                       // no more characters
                }
            }
            ch = buffer[cursor++];               // get symbol and advance
            cat =
                (ch <= 0xff) ? catMap0[ch] :
                ((catMap == null) ? 0 : catMap[ch >> CAT_SHIFT][ch & CAT_MASK]);
            if ((char)(elem = tabMerged[state+cat]) != state){
                state = (char)(tabMerged[state-1] >> 16);
                if ((char)(elem = tabMerged[state+cat]) != state) break;
            }
        } while ((state = (char)(elem >> ParserTables.NSHIFT)) > 0);
        if (acceptAttrs > 0){                    // recognized
            this.stream.cursor = lastPos + this.stream.markPos;
        } else {                                 // no match, back to wrong char
            this.stream.cursor = --cursor;
        }
        return acceptAttrs >> ParserTables.TOKCODE_SHIFT;
    }


    /** 
     * Deliver the string of the lexeme delivered by the last lexing operation.
     * It delivers no string if the last lexing operation delivered no lexeme.
     *
     * @return     string
     */

    public String toString(){
        if (this.stream.cursor == this.stream.markPos){
            return "";
        }
        return String.valueOf(this.stream.buffer,this.stream.markPos,
            this.stream.cursor - this.stream.markPos);
    }

    /** 
     * Store the string of the lexeme delivered by the last lexing operation
     * in the specified array.  It stores no string if the last lexing
     * operation delivered no lexeme.
     *
     * @param      buf buffer
     * @param      off index of the element at which the string is stored
     * @return     length of the string
     */

    public int toChars(char[] buf, int off){
        int len = this.stream.cursor - this.stream.markPos;
        System.arraycopy(this.stream.buffer,this.stream.markPos,
            buf,off,len);
        return len;
    }

    /** 
     * Deliver the length of the lexeme delivered by the last lexing
     * operation. It delivers zero if the last lexing operation delivered
     * no lexeme.
     *
     * @return     length
     */

    public int length(){
        return this.stream.cursor - this.stream.markPos;
    }

    /** 
     * Deliver the index in the stream of the current lexing position
     * (which is the index of the first character past the last delivered
     * lexeme).
     *
     * @return     index
     */

    public long index(){
        return this.stream.index - this.stream.end + this.stream.cursor;
    }

    /** 
     * Reposition the stream to allow other methods to take over scanning.
     */

    public void reposition(){
        this.stream.markPos = this.stream.cursor;
        this.stream.cursor = this.stream.end = 0;
        this.stream.reset(0);
        this.stream.markPos = -1;
    }

    /** 
     * Tell if the last lexing operation occurred at end of file.
     *
     * @return     <code>true</code> if it is at the eof
     */

    /* Note that this does not tell whether the lexer is at the eof,
     * which can occur when a lexeme has been delivered and the lexer had
     * to go past it an in doing that it stuck the eof. It is the same
     * as any read operations, which can deliver data and reach the end
     * of the file. The correct condition returned is that an operation
     * delivered no data, but the eof.
     */

    public boolean eof(){
        int len = this.stream.cursor - this.stream.markPos;
        return (len == 0) && this.stream.eof();
    }

    /** 
     * Terminate lexing and close the stream.
     */

    /* The stream can be closed separately, and then the lexer terminated.
     * This spares to know it.
     */

    public void close() throws IOException {
        this.aut = null;                  // release memory
        this.stream.close();
        this.stream = null;
    }
}
